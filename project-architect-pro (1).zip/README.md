# SYAHRUL GUNAWAN — Personal Profile, Portfolio & CMS

Aplikasi web profil personal, portofolio editorial, manajemen konten, catatan privat, dan brankas rahasia terenkripsi untuk **Syahrul Gunawan**. Dibangun dengan gaya desain **Quiet Editorial / Serene Studio**, ditenagai oleh **React, TypeScript, Vite, Tailwind CSS, Firebase Authentication, Firebase Firestore, Supabase PostgreSQL, dan Supabase Storage**.

---

## 🌟 Fitur Utama

### 1. Area Pengunjung (Publik)
- **Hero & Profil Editorial**: Nama resmi Syahrul Gunawan, gelar, profesi Creative Director & Tech Strategist, status ketersediaan kolaborasi, serta foto studio autentik.
- **Tentang Saya & Biodata Terstruktur**: Data diri lengkap (domisili, tempat/tgl lahir, pendidikan Magister Desain ITB, aktivitas Founder Studio Karsa, keahlian UI/UX).
- **Hobi & Minat**: Kartu humanis (Fotografi Analog, Kopi Seduh Manual, Bersepeda Jarak Jauh).
- **Prestasi & Rekam Jejak**: Linimasa vertikal dengan filter kategori (Penghargaan, Pembicara, Proyek, Karier).
- **Kurasi Musik Favorit**: Pemutar audio interaktif dengan simulasi osilator harmonik relaksasi (Web Audio API), visualisasi equalizer, scrubber waktu, kontrol volume, dan pemutar mengambang mini di bagian atas layar.
- **Gerbang Donasi (Dukung Saya)**: Dukungan sukarela melalui nominal preset, tautan Saweria / Trakteer, dan modal pindai QRIS statis nasional.
- **Koneksi Sosial (Temukan Saya)**: Tautan resmi Instagram, TikTok, LinkedIn, dan GitHub yang divalidasi dengan aman (`rel="noopener noreferrer"`).

### 2. Area Pengelola (Admin CMS)
- **Otentikasi & Otorisasi**: Proteksi rute dengan Firebase Auth, validasi kredensial, toggle sandi, remember me, dan pemulihan kata sandi.
- **Ringkasan Dashboard**: Statistik riil dari database (jumlah prestasi, musik, tautan, catatan privat, brankas terenkripsi, status sinkronisasi, dan pratinjau situs).
- **Edit Profil & Biodata**: Sunting identitas, username, domisili, narasi diri, ganti foto profil via Supabase Storage, dan simpan/terbitkan draf.
- **Kelola Prestasi**: Operasi CRUD lengkap dengan modal tambah/edit terpadu, unggah piagam, atur tanggal dan kategori, serta konfirmasi hapus.
- **Kelola Musik**: Tambah/edit trek lagu, atur urutan, sumber audio, dan uji coba pemutaran langsung di panel.
- **Koleksi Tautan**: CRUD tautan sosial dengan validasi HTTPS dan tombol "Uji Tautan".
- **Catatan Pribadi**: Aplikasi jurnal & catatan privat dengan filter kategori, editor Markdown, ekspor ke format `.md` dan `.txt`, print/PDF, serta autosave. Catatan tidak pernah terekspos ke publik!
- **Brankas Rahasia (Secure Vault)**: Enkripsi sisi klien tingkat tinggi menggunakan **Web Crypto API (AES-GCM 256-bit + PBKDF2 dengan 100.000 iterasi & salt acak)**. Kunci brankas dengan Master Passphrase, buka/tutup rahasia, salin ke clipboard, buat sandi acak kuat, dan kunci brankas seketika.
- **Pengaturan Donasi**: Aktifkan/nonaktifkan gerbang donasi, ganti kode QRIS, ubah tautan Saweria, dan pratinjau kartu beranda.
- **Keamanan & Akun**: Kelola kredensial akun, perbarui kata sandi dengan meter kekuatan sandi, pantau riwayat sesi perangkat aktif, dan fitur pemutusan sesi.

---

## 🛠️ Konfigurasi Environment Variables

Salin `.env.example` menjadi `.env.local` di direktori utama, lalu lengkapi nilai yang belum tersedia:

```bash
# Firebase Client Configuration (Auth & Realtime Firestore)
VITE_FIREBASE_API_KEY=(sudah diisi di .env.example)
VITE_FIREBASE_AUTH_DOMAIN=ayung-76.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=ayung-76
VITE_FIREBASE_APP_ID=1:431476157485:web:76d04ed14e8b63ff2bdca4
VITE_FIREBASE_STORAGE_BUCKET=(isi jika Storage digunakan)

# Supabase Client Configuration (PostgreSQL & Storage)
VITE_SUPABASE_URL=https://stfgoakbqhlkfqxwypsg.supabase.co
VITE_SUPABASE_ANON_KEY=(isi publishable/anon public key dari Supabase)
```

> **Penting**: Tanpa Supabase public key dan migrasi SQL, database Supabase belum aktif dan perubahan CMS tidak akan tersimpan ke database online. Jangan mengandalkan fallback localStorage untuk data produksi.

---

## 🗄️ Database & Storage Setup

### 1. Supabase PostgreSQL Migration
Jalankan `supabase/migrations/001_initial_schema.sql`, lalu `supabase/migrations/002_admin_access_hardening.sql` pada SQL Editor dashboard Supabase Anda. File ini otomatis membuat:
- Tabel: `profiles`, `profile_details`, `achievements`, `hobbies`, `music_tracks`, `social_links`, `private_notes`, `vault_items`, `donations`, `app_settings`
- Indeks performa query
- Row Level Security (RLS) policies untuk pemisahan data publik dan privat
- Bucket Storage Supabase (`profile-media`, `achievement-media`, `music-media`, `donation-media`)

### 2. Firebase Firestore Rules
Terapkan file `firebase/firestore.rules` pada Firebase Console Anda untuk memastikan aturan keamanan real-time sinkronisasi hanya dapat diubah oleh administrator terotentikasi.

---

## 🔐 Akun Administrator dan Keamanan

Tidak ada kata sandi default yang disediakan di kode. Buat akun administrator dengan email `ayungnew768@gmail.com` di Firebase Authentication **dan** Supabase Authentication. Gunakan kata sandi yang sama untuk kedua layanan karena panel login memverifikasi kedua sesi. Setelah membuat akun Supabase, jalankan migrasi `002_admin_access_hardening.sql` agar role admin diberikan melalui `app_metadata`. Jangan pernah menyimpan kata sandi di GitHub.

Untuk konfigurasi, salin `.env.example` ke `.env.local`, isi `VITE_SUPABASE_ANON_KEY`, lalu jalankan build ulang. Panduan lengkap ada di `SECURITY_NOTES.md`.

---

## 🐙 Cara Mengirim Kode ke GitHub (Push to GitHub)

Setelah konfigurasi environment disiapkan, buat repositori GitHub dan unggah source. Jangan commit `.env.local`; untuk build di CI, atur variabel `VITE_*` pada GitHub Actions/hosting. Ikuti langkah mudah berikut:

### 1. Buat Repositori Baru di GitHub
1. Buka [github.com/new](https://github.com/new).
2. Beri nama repositori (misalnya `syahrul-gunawan-profile-cms`).
3. Biarkan opsi *"Initialize this repository with a README"* **tidak dicentang** (kosongkan).
4. Klik **Create repository**.

### 2. Hubungkan Remote & Push ke GitHub
Jalankan perintah berikut di terminal:

```bash
# Tambahkan alamat repositori GitHub kamu (ganti USERNAME dan REPO_NAME)
git remote add origin https://github.com/<USERNAME>/<REPO_NAME>.git

# Pastikan di branch main
git branch -M main

# Kirim semua kode ke GitHub
git push -u origin main
```

Jika nanti kamu melakukan perubahan tambahan di masa mendatang:
```bash
git add .
git commit -m "Update konten profil dan fitur"
git push
```

---

## 💻 Cara Menjalankan Proyek di Komputer Lokal

```bash
# 1. Clone repositori
git clone https://github.com/<USERNAME>/<REPO_NAME>.git
cd <REPO_NAME>

# 2. Pasang dependensi
npm install

# 3. Buat file environment lokal (opsional, sistem fallback otomatis aktif)
cp .env.example .env

# 4. Jalankan server pengembangan
npm run dev

# 5. Build untuk produksi
npm run build
```

