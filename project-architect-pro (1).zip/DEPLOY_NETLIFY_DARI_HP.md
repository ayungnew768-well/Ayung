# Deploy Ayung di Netlify dari HP

## Penting
ZIP ini adalah KODE SUMBER React/Vite, bukan folder hasil build `dist`. Jangan gunakan menu `Dropped files` untuk menerbitkan ZIP kode sumber. Hubungkan repository GitHub ke Netlify supaya Netlify menjalankan build.

## Konfigurasi yang sudah disediakan
- Build command: `npm run build`
- Publish directory: `dist`
- Node.js: 22
- Konfigurasi produksi **tidak disimpan dalam ZIP atau Git**. Masukkan variabel `VITE_*` di Netlify: Site configuration > Environment variables. Nilai `VITE_*` akan masuk ke bundle browser saat build, jadi hanya gunakan Firebase Web config dan Supabase anon/publishable key. Jangan masukkan password, service-role key, atau secret.

## Langkah
1. Buat repository GitHub baru, misalnya `ayung-company-profile`.
2. Ekstrak ZIP ini terlebih dahulu. Unggah isi folder `Ayung-main` ke repository sehingga `package.json`, `netlify.toml`, `src/`, `public/`, dan `.env.example` berada di root repository (bukan folder bersarang `Ayung-main/Ayung-main`).
3. Di Netlify pilih Add new project > Import an existing project > GitHub, lalu pilih repository.
4. Di Netlify > Site configuration > Environment variables, isi: `VITE_ADMIN_EMAIL`, `VITE_FIREBASE_API_KEY`, `VITE_FIREBASE_AUTH_DOMAIN`, `VITE_FIREBASE_PROJECT_ID`, `VITE_FIREBASE_APP_ID`, `VITE_SUPABASE_URL`, dan `VITE_SUPABASE_ANON_KEY`. Ambil nilainya dari Firebase/Supabase project milikmu. Jangan isi service-role key.
5. Build command `npm run build`, publish directory `dist`, Node version `22` (konfigurasi juga ada di `netlify.toml`).
6. Deploy. Setiap perubahan kode akan memicu build baru.
7. Jika login Firebase masih gagal, buka Firebase Console > Authentication > Settings > Authorized domains dan tambahkan domain Netlify situs (contoh `nama-situs.netlify.app`). Jangan menebak domain; salin domain yang benar dari Netlify.

## Catatan pemeriksaan
Keberhasilan deployment bukan bukti semua fitur sudah berfungsi. Setelah build, uji login admin, reset password, CRUD konten, upload foto, Supabase tables/RLS, dan Storage. Build perlu berhasil tanpa error pada tab Deploys sebelum dinyatakan siap.
