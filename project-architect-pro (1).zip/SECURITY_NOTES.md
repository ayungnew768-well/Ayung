# Security and database setup notes

This project uses Firebase Authentication/Firestore and Supabase PostgreSQL/Storage. The browser must only use Firebase Web config and the Supabase publishable/anon key. Never put Firebase Admin SDK credentials, Supabase `service_role`, or Supabase secret keys in the frontend or GitHub repository.

## Firebase
- `VITE_ADMIN_EMAIL` and `firebase/firestore.rules` are set to `ayungnew768@gmail.com`.
- Create/enable this exact email in Firebase Authentication with Email/Password enabled.
- Deploy `firebase/firestore.rules` through Firebase Console or Firebase CLI; uploading the file to GitHub alone does not deploy rules.
- The Firebase API key is a client identifier, not an admin secret. Restrict it in Google Cloud API key settings to the APIs and website referrers you use.
- `VITE_FIREBASE_STORAGE_BUCKET` is intentionally blank because the correct bucket name must be copied from Firebase Project settings; it is not guessed.

## Supabase
- Use the Project URL `https://stfgoakbqhlkfqxwypsg.supabase.co` (root URL, not `/rest/v1/`).
- The supplied Supabase anon public key is configured in `.env.production` and `.env.example`. This key is intended for browser clients; keep RLS policies enabled and never replace it with a service-role/secret key.
- Run `supabase/migrations/001_initial_schema.sql` first, then `supabase/migrations/002_admin_access_hardening.sql` in Supabase SQL Editor.
- Create the administrator user in Supabase Authentication with email `ayungnew768@gmail.com` and the same password as the Firebase Authentication account. The frontend login intentionally requires both services.
- Migration 002 assigns `app_metadata.role = admin` to that email if the user already exists. If the user was created after running the migration, run the UPDATE statement at the top of migration 002 again. Do not assign admin via `user_metadata`.
- Verify RLS and Storage policies after applying migrations. Public media buckets are public for reading; uploads/updates/deletes are restricted to the Supabase Auth admin role.

## Local and GitHub setup
- Copy `.env.example` to `.env.local` for local development and fill in `VITE_SUPABASE_ANON_KEY`.
- For GitHub Actions/hosted builds, configure the same `VITE_*` variables as repository/environment secrets or build variables. Vite variables are embedded in the public client bundle; only public client values belong there.
- Do not commit `.env.local`. It is ignored by `.gitignore`.

## Verification required
This ZIP has not been connected to the live databases or deployed. After configuration, test public pages, admin login, CMS create/edit/delete, image uploads, private notes, vault access, and cross-device persistence. Back up existing database data before applying schema changes.

## Netlify deployment notes
- `netlify.toml` and `public/_redirects` configure the Vite build (`npm run build`, publish `dist`) and React Router SPA fallback.
- Configure the `VITE_*` variables in Netlify Site configuration before deployment. Client Firebase web config and the Supabase anon/publishable key are browser-visible by design; never add a Supabase service-role/secret key or Firebase Admin credentials.
- The current password-reset flow sends Firebase reset instructions only. Because the app also signs in to Supabase Auth with the same email/password, resetting Firebase alone does not reset Supabase. Synchronize both passwords before logging in again. A single coordinated reset requires a trusted server-side flow; do not put privileged keys in the browser.
- Session-management controls in the security page are UI placeholders and do not revoke actual Firebase/Supabase sessions. They are now labelled honestly in their alerts; do not rely on them as a security control.
- Build/deployment and end-to-end button behavior still must be verified in the target environment before production use.
