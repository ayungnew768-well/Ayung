# Deploy Ayung to InfinityFree (React + Vite)

## Important hosting limitation
InfinityFree free hosting runs PHP and serves static files; it does not run Node.js/Express. Build this Vite app on another machine/build service first, then upload the **contents of `dist/`** to `htdocs/`.

## 1. Configure Firebase and Supabase before building
1. Copy `.env.example` to `.env.local` (or `.env.production` for a production build).
2. Fill in the real web/client configuration values:
   - `VITE_ADMIN_EMAIL`
   - `VITE_FIREBASE_API_KEY`
   - `VITE_FIREBASE_AUTH_DOMAIN`
   - `VITE_FIREBASE_PROJECT_ID`
   - `VITE_FIREBASE_APP_ID`
   - `VITE_FIREBASE_STORAGE_BUCKET` (if used)
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
3. Do not use a Supabase `service_role` key, Firebase Admin SDK credentials, passwords, or other server secrets in any `VITE_*` variable. Vite embeds `VITE_*` values in browser files.
4. Ensure Supabase RLS policies and Firebase Security Rules are configured securely. A client/anon key is not a replacement for database access rules.

## 2. Build the website
Run in the project folder on a computer or build environment with Node.js supported:

```sh
npm install
npm run build
```

The build must finish successfully and create `dist/`. If it fails, fix the reported errors before uploading.

## 3. Upload to InfinityFree
1. Open InfinityFree Client Area and launch the hosting Control Panel.
2. Open File Manager (or connect with FTP).
3. Open the website's `htdocs/` directory.
4. Upload **everything inside `dist/`**, including `index.html`, the `assets/` folder, and `.htaccess`. Do not upload the source project as the live website.
5. If replacing an existing site, back it up first. Remove/replace old generated assets to avoid stale files, but do not delete unrelated files belonging to other sites.
6. Enable/confirm HTTPS for the domain after DNS/SSL is ready.

## 4. Test after deployment
- Open the homepage in a private/incognito tab.
- Open a nested route directly and refresh it; `.htaccess` should send app routes to `index.html`.
- Test admin login with the existing account. Do not put passwords in source files.
- Edit profile data, reload, then check the same profile from another device/browser.
- In the admin connection status, confirm Firebase and Supabase are connected.
- Check browser developer console/network requests for permission errors, missing tables, CORS errors, or failed writes.
- Confirm the app reports a failed save if the database rejects a write; never assume local cache proves remote persistence.

## 5. Database setup reminders
- Apply the SQL migration files in `supabase/migrations/` to the intended Supabase project in order, unless you have already applied them. Review policies before applying to a live project.
- Verify the Firebase project has Authentication providers and Firestore enabled, and deploy appropriate Firestore Security Rules.
- Verify the admin account exists in the auth provider(s) required by the app. Creating an email in source code does not create an authentication account.

## Troubleshooting
- Blank page: inspect browser console; confirm `index.html` and `assets/` are uploaded at the `htdocs/` root and the build used the right env values.
- Login rejected: verify the account/password in the required auth service(s), allowed auth providers, and authorized domain settings.
- Data only appears on one device: inspect Supabase table permissions/RLS and the write/read requests; localStorage is device/browser-specific.
- Direct refresh returns 404: check that `.htaccess` was uploaded and Apache rewrite rules are supported/enabled.

This guide does not claim a successful build or live database connection. Those must be tested with the actual project configuration and deployed website.
