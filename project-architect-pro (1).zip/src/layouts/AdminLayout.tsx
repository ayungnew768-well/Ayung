import React, { useState } from 'react';
import { NavLink, Outlet, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard,
  UserCheck,
  Trophy,
  Headphones,
  Link2,
  FileText,
  Lock,
  Heart,
  ShieldCheck,
  LogOut,
  Menu,
  X,
  ExternalLink,
  CloudCheck,
  Database,
  User as UserIcon,
  ChevronRight
} from 'lucide-react';

export const AdminLayout: React.FC = () => {
  const { isAdmin, logout, adminInfo, isLoading } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const navigate = useNavigate();

  // Route protection
  React.useEffect(() => {
    if (!isLoading && !isAdmin) {
      navigate('/login');
    }
  }, [isAdmin, isLoading, navigate]);

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  interface NavItem {
    path: string;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    exact?: boolean;
  }

  interface NavGroup {
    group: string;
    items: NavItem[];
  }

  const navItems: NavGroup[] = [
    {
      group: 'DASHBOARD',
      items: [
        { path: '/admin', label: 'Ringkasan Dashboard', icon: LayoutDashboard, exact: true }
      ]
    },
    {
      group: 'KONTEN PUBLIK',
      items: [
        { path: '/admin/profile', label: 'Profil & Biodata', icon: UserCheck },
        { path: '/admin/achievements', label: 'Kelola Prestasi', icon: Trophy },
        { path: '/admin/music', label: 'Musik Favorit', icon: Headphones },
        { path: '/admin/links', label: 'Koleksi Tautan', icon: Link2 },
        { path: '/admin/donations', label: 'Pengaturan Donasi', icon: Heart }
      ]
    },
    {
      group: 'PRIVASI',
      items: [
        { path: '/admin/privacy-hub', label: 'Catatan & Brankas', icon: ShieldCheck },
        { path: '/admin/notes', label: 'Catatan Pribadi', icon: FileText },
        { path: '/admin/vault', label: 'Brankas Rahasia', icon: Lock }
      ]
    },
    {
      group: 'PENGATURAN',
      items: [
        { path: '/admin/security', label: 'Keamanan & Akun', icon: ShieldCheck }
      ]
    }
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-surface flex flex-col items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-surface text-on-surface flex flex-col font-sans selection:bg-secondary-container selection:text-on-secondary-container">
      {/* Mobile Top Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-surface-container-low border-b border-outline-variant/30 z-50 px-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-1.5 rounded-lg text-on-surface hover:bg-surface-container transition-colors"
            aria-label="Buka Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          <span className="font-editorial text-lg text-on-surface font-medium truncate">
            Syahrul Gunawan
          </span>
        </div>

        <div className="flex items-center gap-2">
          <Link
            to="/"
            target="_blank"
            className="p-1.5 rounded-lg text-secondary hover:text-primary transition-colors"
            title="Pratinjau Situs Publik"
          >
            <ExternalLink className="w-4 h-4" />
          </Link>
          <button
            onClick={handleLogout}
            className="p-1.5 rounded-lg text-error hover:bg-error-container transition-colors"
            title="Keluar"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Sidebar Drawer on Mobile / Fixed on Desktop */}
      <aside
        className={`fixed top-0 bottom-0 left-0 w-64 bg-surface-container-low border-r border-outline-variant/30 z-50 flex flex-col justify-between py-4 transition-transform duration-300 lg:translate-x-0 ${
          mobileMenuOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full overflow-y-auto">
          {/* Admin Identity Header */}
          <div className="px-5 pb-5 mb-2 border-b border-outline-variant/20">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-on-primary shrink-0 shadow-xs">
                <UserIcon className="w-5 h-5" />
              </div>
              <div className="flex flex-col min-w-0">
                <span className="font-editorial text-base text-on-surface font-semibold truncate">
                  {adminInfo.name}
                </span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="bg-surface text-primary px-2 py-0.5 rounded-full text-[10px] font-sans font-bold uppercase tracking-wider">
                    Panel Pengelola
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Navigation Groups */}
          <nav className="flex-1 px-3 space-y-4">
            {navItems.map((group) => (
              <div key={group.group} className="space-y-1">
                <span className="px-3 text-[10px] font-mono tracking-widest text-secondary uppercase font-semibold block">
                  {group.group}
                </span>
                <div className="space-y-0.5">
                  {group.items.map((item) => {
                    const Icon = item.icon;
                    return (
                      <NavLink
                        key={item.path}
                        to={item.path}
                        end={item.exact}
                        onClick={() => setMobileMenuOpen(false)}
                        className={({ isActive }) =>
                          `flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-sans font-medium transition-all ${
                            isActive
                              ? 'bg-primary-container text-on-primary-container font-semibold shadow-xs'
                              : 'text-on-surface-variant hover:bg-surface-container-high hover:text-on-surface'
                          }`
                        }
                      >
                        <Icon className="w-4 h-4 shrink-0" />
                        <span className="truncate">{item.label}</span>
                      </NavLink>
                    );
                  })}
                </div>
              </div>
            ))}
          </nav>

          {/* Bottom Sidebar Status & Logout */}
          <div className="px-4 pt-3 mt-2 border-t border-outline-variant/20 flex flex-col gap-2">
            <div className="flex items-center gap-2 px-2 py-1 text-[11px] text-secondary">
              <span className="w-2 h-2 rounded-full bg-primary-container animate-pulse"></span>
              <span className="font-mono uppercase tracking-wider">Sistem Online &amp; Terenkripsi</span>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-error hover:bg-error-container hover:text-on-error-container transition-colors w-full text-left"
            >
              <LogOut className="w-4 h-4" />
              <span>Keluar dari Panel</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="lg:pl-64 flex flex-col flex-1">
        {/* Desktop Top Header Bar */}
        <header className="hidden lg:flex fixed top-0 left-64 right-0 h-16 bg-surface/85 backdrop-blur-xl border-b border-outline-variant/30 z-40 items-center justify-between px-8">
          <div className="flex items-center gap-2 text-xs text-secondary">
            <span>Admin</span>
            <ChevronRight className="w-3.5 h-3.5 text-outline" />
            <span className="text-on-surface font-semibold font-sans">Ruang Kurasi</span>
          </div>

          <div className="flex items-center gap-5">
            <div className="flex items-center gap-1.5 text-xs text-secondary">
              <CloudCheck className="w-4 h-4 text-primary" />
              <span className="font-sans">Tersinkron Real-Time</span>
            </div>

            <Link
              to="/"
              target="_blank"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-surface-container hover:bg-surface-container-high text-on-surface text-xs font-semibold transition-colors shadow-xs"
            >
              <span>Pratinjau Situs</span>
              <ExternalLink className="w-3.5 h-3.5 text-secondary" />
            </Link>

            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-on-primary shrink-0">
              <UserIcon className="w-4 h-4" />
            </div>
          </div>
        </header>

        {/* Page Content Viewport */}
        <main className="w-full pt-16 flex-1 px-4 md:px-8 py-8 bg-surface">
          <div className="max-w-6xl mx-auto w-full">
            <Outlet />
          </div>
        </main>
      </div>

      {/* Mobile Backdrop */}
      {mobileMenuOpen && (
        <div
          onClick={() => setMobileMenuOpen(false)}
          className="fixed inset-0 bg-on-surface/30 backdrop-blur-xs z-40 lg:hidden"
        />
      )}
    </div>
  );
};
