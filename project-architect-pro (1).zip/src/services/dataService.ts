import { supabase, isSupabaseConfigured, testSupabaseConnection } from '../lib/supabase';
import { db, isFirebaseConfigured, testFirebaseConnection } from '../lib/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import {
  Profile,
  ProfileDetail,
  Achievement,
  Hobby,
  MusicTrack,
  SocialLink,
  PrivateNote,
  VaultItem,
  DonationSettings,
  ConnectionStatus
} from '../types';
import { getYouTubeThumbnail } from '../lib/youtube';
import { encryptSecret, decryptSecret } from '../lib/crypto';

// ============================================================================
// INITIAL SEED DATA FOR SYAHRUL GUNAWAN (REALISTIC PRODUCTION-GRADE EDITORIAL)
// ============================================================================

const SEED_PROFILE: Profile = {
  id: '00000000-0000-4000-8000-000000000001',
  firebase_uid: 'syahrul-admin-uid-001',
  display_name: 'Syahrul Gunawan',
  username: 'syahrulgunawan',
  headline: 'Creative Director & Tech Strategist based in Jakarta',
  biography: 'Fokus pada persimpangan antara estetika fungsional, arsitektur informasi, dan pertumbuhan produk jangka panjang.',
  birth_date: '1995-08-14',
  location: 'Jakarta Selatan, Indonesia',
  profile_photo_path: '/assets/syahrul_portrait.png',
  email_public: 'halo@syahrulgunawan.com',
  created_at: new Date().toISOString(),
  updated_at: new Date().toISOString()
};

const SEED_PROFILE_DETAILS: ProfileDetail[] = [];
const SEED_HOBBIES: Hobby[] = [];
const SEED_ACHIEVEMENTS: Achievement[] = [
  {
    id: '00000000-0000-4000-8000-000000000020',
    profile_id: '00000000-0000-4000-8000-000000000001',
    title: 'Finalis Karya Solusi Digital Kreatif',
    description: 'Penghargaan atas perancangan arsitektur antarmuka pengguna berbasis editorial web yang efisien dan responsif.',
    category: 'Penghargaan',
    institution: 'National Digital Innovation Forum',
    achievement_date: '2024-11-20',
    is_published: true,
    display_order: 1,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];
const SEED_MUSIC: MusicTrack[] = [
  {
    id: '00000000-0000-4000-8000-000000000010',
    profile_id: '00000000-0000-4000-8000-000000000001',
    title: 'Midnight Focus — Deep Ambient',
    artist: 'Syahrul Gunawan Audio Lab',
    audio_source_type: 'ambient',
    audio_url: 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3',
    duration: '03:48',
    cover_path: '/assets/syahrul_portrait.png',
    display_order: 1,
    is_published: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];
const SEED_LINKS: SocialLink[] = [
  {
    id: '00000000-0000-4000-8000-000000000030',
    profile_id: '00000000-0000-4000-8000-000000000001',
    title: 'GitHub Resmi',
    label: 'GitHub Resmi',
    url: 'https://github.com',
    category: 'Sosmed',
    platform: 'github',
    description: 'Repositori open-source dan eksplorasi kode',
    icon: 'github',
    display_order: 1,
    is_published: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: '00000000-0000-4000-8000-000000000031',
    profile_id: '00000000-0000-4000-8000-000000000001',
    title: 'LinkedIn Profesional',
    label: 'LinkedIn Profesional',
    url: 'https://linkedin.com',
    category: 'Sosmed',
    platform: 'linkedin',
    description: 'Jejaring karier dan publikasi profesional',
    icon: 'linkedin',
    display_order: 2,
    is_published: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];
const SEED_NOTES: PrivateNote[] = [];
const SEED_VAULT_ITEMS: VaultItem[] = [];

const SEED_DONATIONS: DonationSettings = {
  id: '00000000-0000-4000-8000-000000000002',
  profile_id: '00000000-0000-4000-8000-000000000001',
  enabled: true,
  title: 'Dukung Riset & Portofolio',
  description: 'Jika kamu menikmati karya, audio kurasi, atau eksplorasi teknologi ini, kamu dapat memberikan apresiasi secara langsung.',
  qris_image_path: '/assets/qris_syahrul_official.png',
  donation_url: 'https://saweria.co/syahrulgunawan',
  display_order: 1,
  updated_at: new Date().toISOString()
};

// ============================================================================
// LOCAL STORAGE KEYS & CACHE
// ============================================================================
const STORAGE_PREFIX = 'syahrul_cms_';
const WIPE_EMPTY_KEY = 'syahrul_cms_wiped_empty_v8';

// Automatically purge any previous dummy/sample data when loaded
if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
  if (!localStorage.getItem(WIPE_EMPTY_KEY)) {
    const keysToWipe = [
      'profile',
      'profile_details',
      'hobbies',
      'achievements',
      'music_tracks',
      'social_links',
      'private_notes',
      'vault_items',
      'donations'
    ];
    for (const k of keysToWipe) {
      localStorage.removeItem(STORAGE_PREFIX + k);
    }
    localStorage.setItem(WIPE_EMPTY_KEY, 'true');
  }
}

function getLocal<T>(key: string, defaultValue: T): T {
  try {
    const val = localStorage.getItem(STORAGE_PREFIX + key);
    return val ? JSON.parse(val) : defaultValue;
  } catch (e) {
    return defaultValue;
  }
}

function setLocal<T>(key: string, value: T): void {
  try {
    localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value));
  } catch (e) {
    console.error('LocalStorage write error:', e);
  }
}

// Supabase schema uses UUID primary keys. Do not prepend labels to UUIDs,
// otherwise inserts/upserts fail PostgreSQL UUID validation.
export function generateUniqueId(_prefix: string = 'id'): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  // RFC 4122 UUID v4 fallback for older browser environments.
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });
}

export function deduplicateById<T extends { id?: string }>(items: T[]): T[] {
  if (!Array.isArray(items)) return [];
  const seen = new Set<string>();
  const result: T[] = [];
  for (const item of items) {
    if (!item) continue;
    if (item.id && !seen.has(item.id)) {
      seen.add(item.id);
      result.push(item);
    } else if (item.id && seen.has(item.id)) {
      const newId = `${item.id}-${Math.random().toString(36).substring(2, 8)}`;
      seen.add(newId);
      result.push({ ...item, id: newId });
    } else {
      const newId = generateUniqueId('item');
      seen.add(newId);
      result.push({ ...item, id: newId });
    }
  }
  return result;
}

// ============================================================================
// DATA SERVICE IMPLEMENTATION
// ============================================================================

export const dataService = {
  /**
   * Status Check
   */
  async getConnectionStatus(): Promise<ConnectionStatus> {
    const fbStatus = await testFirebaseConnection();
    const sbStatus = await testSupabaseConnection();

    return {
      firebaseConfigured: isFirebaseConfigured(),
      firebaseConnected: fbStatus.success,
      supabaseConfigured: isSupabaseConfigured(),
      supabaseConnected: sbStatus.success,
      tablesMissing: sbStatus.tablesMissing,
      storageBucketsReady: isSupabaseConfigured(),
      lastChecked: new Date().toISOString(),
      message: sbStatus.message
    };
  },

  /**
   * PROFILES & DETAILS
   */
  async getProfile(): Promise<Profile> {
    if (isSupabaseConfigured() && supabase) {
      try {
        const { data, error } = await supabase.from('profiles').select('*').limit(1).maybeSingle();
        if (!error && data) {
          const sanitized: Profile = {
            ...SEED_PROFILE,
            ...data,
            display_name: data.display_name ?? 'Syahrul Gunawan',
            username: data.username ?? 'syahrulgunawan',
            headline: data.headline ?? '',
            biography: data.biography ?? '',
            birth_date: data.birth_date ?? '',
            location: data.location ?? '',
            profile_photo_path: data.profile_photo_path || '/assets/syahrul_portrait.png',
            email_public: data.email_public ?? ''
          };
          setLocal('profile', sanitized);
          return sanitized;
        }
      } catch (err) {
        console.warn('Supabase profile fetch error:', err);
      }
    }
    return getLocal<Profile>('profile', SEED_PROFILE);
  },

  async updateProfile(profile: Partial<Profile>): Promise<Profile> {
    const current = await this.getProfile();
    const updated: Profile = {
      ...current,
      ...profile,
      updated_at: new Date().toISOString()
    };

    if (isSupabaseConfigured() && supabase) {
      const { error } = await supabase.from('profiles').upsert(updated);
      if (error) {
        console.error('Supabase profile update failed:', error);
        throw new Error(`Profil gagal disimpan ke database: ${error.message}`);
      }
    } else {
      throw new Error('Database Supabase belum dikonfigurasi. Perubahan profil tidak dapat disinkronkan ke perangkat lain.');
    }

    if (isFirebaseConfigured() && db) {
      try {
        await setDoc(doc(db, 'app_config', 'profile_status'), {
          last_updated: updated.updated_at,
          headline: updated.headline
        }, { merge: true });
      } catch (err) {
        console.warn('Firestore sync note:', err);
      }
    }

    setLocal('profile', updated);
    return updated;
  },

  async getProfileDetails(): Promise<ProfileDetail[]> {
    if (isSupabaseConfigured() && supabase) {
      try {
        const { data, error } = await supabase
          .from('profile_details')
          .select('*')
          .order('display_order', { ascending: true });
        if (!error && data && data.length > 0) {
          setLocal('profile_details', data);
          return data;
        }
      } catch (e) {}
    }
    return getLocal<ProfileDetail[]>('profile_details', SEED_PROFILE_DETAILS);
  },

  async updateProfileDetails(details: ProfileDetail[]): Promise<ProfileDetail[]> {
    if (isSupabaseConfigured() && supabase) {
      try {
        await supabase.from('profile_details').upsert(details);
      } catch (e) {}
    }
    setLocal('profile_details', details);
    return details;
  },

  /**
   * HOBBIES
   */
  async getHobbies(publicOnly: boolean = false): Promise<Hobby[]> {
    if (isSupabaseConfigured() && supabase) {
      try {
        let q = supabase.from('hobbies').select('*').order('display_order', { ascending: true });
        if (publicOnly) q = q.eq('is_published', true);
        const { data, error } = await q;
        if (!error && data && data.length > 0) return data;
      } catch (e) {}
    }
    const list = getLocal<Hobby[]>('hobbies', SEED_HOBBIES);
    return publicOnly ? list.filter((h) => h.is_published) : list;
  },

  async saveHobby(hobby: Partial<Hobby>): Promise<Hobby> {
    const list = await this.getHobbies();
    let saved: Hobby;
    if (hobby.id) {
      const idx = list.findIndex((h) => h.id === hobby.id);
      saved = { ...list[idx], ...hobby } as Hobby;
      if (idx !== -1) list[idx] = saved;
      else list.push(saved);
    } else {
      saved = {
        id: generateUniqueId('hobby'),
        profile_id: '00000000-0000-4000-8000-000000000001',
        name: hobby.name || 'Hobi Baru',
        description: hobby.description || '',
        icon: hobby.icon || 'star',
        display_order: list.length + 1,
        is_published: hobby.is_published ?? true,
        ...hobby
      };
      list.push(saved);
    }
    if (isSupabaseConfigured() && supabase) {
      try {
        await supabase.from('hobbies').upsert(saved);
      } catch (e) {}
    }
    const clean = deduplicateById(list);
    setLocal('hobbies', clean);
    return saved;
  },

  async deleteHobby(id: string): Promise<void> {
    if (isSupabaseConfigured() && supabase) {
      try {
        await supabase.from('hobbies').delete().eq('id', id);
      } catch (e) {}
    }
    const list = (await this.getHobbies()).filter((h) => h.id !== id);
    const clean = deduplicateById(list);
    setLocal('hobbies', clean);
  },

  /**
   * ACHIEVEMENTS
   */
  async getAchievements(publicOnly: boolean = false): Promise<Achievement[]> {
    if (isSupabaseConfigured() && supabase) {
      try {
        let q = supabase.from('achievements').select('*').order('display_order', { ascending: true });
        if (publicOnly) q = q.eq('is_published', true);
        const { data, error } = await q;
        if (!error && data && data.length > 0) return deduplicateById(data);
      } catch (e) {}
    }
    const list = getLocal<Achievement[]>('achievements', SEED_ACHIEVEMENTS);
    const clean = deduplicateById(list);
    return publicOnly ? clean.filter((a) => a.is_published) : clean;
  },

  async saveAchievement(ach: Partial<Achievement>): Promise<Achievement> {
    const list = await this.getAchievements(false);
    let saved: Achievement;

    if (ach.id) {
      const idx = list.findIndex((a) => a.id === ach.id);
      saved = {
        ...list[idx],
        ...ach,
        updated_at: new Date().toISOString()
      } as Achievement;
      if (idx !== -1) list[idx] = saved;
      else list.push(saved);
    } else {
      saved = {
        id: generateUniqueId('ach'),
        profile_id: '00000000-0000-4000-8000-000000000001',
        title: ach.title || '',
        description: ach.description || '',
        category: ach.category || 'Penghargaan',
        institution: ach.institution || '',
        achievement_date: ach.achievement_date || new Date().toISOString().split('T')[0],
        image_path: ach.image_path || '',
        is_published: ach.is_published ?? true,
        display_order: list.length + 1,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      list.push(saved);
    }

    if (isSupabaseConfigured() && supabase) {
      const { error } = await supabase.from('achievements').upsert(saved);
      if (error) {
        console.error('Supabase achievements upsert error:', error);
        throw new Error(`Gagal menyimpan ke database Supabase: ${error.message}`);
      }
    }

    const clean = deduplicateById(list);
    setLocal('achievements', clean);
    return saved;
  },

  async deleteAchievement(id: string): Promise<void> {
    if (isSupabaseConfigured() && supabase) {
      const { error } = await supabase.from('achievements').delete().eq('id', id);
      if (error) {
        console.error('Supabase achievements delete error:', error);
        throw new Error(`Gagal menghapus dari database Supabase: ${error.message}`);
      }
    }
    const list = (await this.getAchievements(false)).filter((a) => a.id !== id);
    const clean = deduplicateById(list);
    setLocal('achievements', clean);
  },

  /**
   * MUSIC TRACKS
   */
  async getMusicTracks(publicOnly: boolean = false): Promise<MusicTrack[]> {
    if (isSupabaseConfigured() && supabase) {
      try {
        let q = supabase.from('music_tracks').select('*').order('display_order', { ascending: true });
        if (publicOnly) q = q.eq('is_published', true);
        const { data, error } = await q;
        if (!error && data && data.length > 0) return deduplicateById(data);
      } catch (e) {}
    }
    const list = getLocal<MusicTrack[]>('music_tracks', SEED_MUSIC);
    const clean = deduplicateById(list);
    return publicOnly ? clean.filter((m) => m.is_published) : clean;
  },

  async saveMusicTrack(track: Partial<MusicTrack>): Promise<MusicTrack> {
    const list = await this.getMusicTracks(false);
    let saved: MusicTrack;

    const computedCover = track.cover_path || (track.youtube_url ? getYouTubeThumbnail(track.youtube_url) : '');

    if (track.id) {
      const idx = list.findIndex((m) => m.id === track.id);
      saved = {
        ...list[idx],
        ...track,
        cover_path: computedCover || list[idx]?.cover_path,
        updated_at: new Date().toISOString()
      } as MusicTrack;
      if (idx !== -1) list[idx] = saved;
      else list.push(saved);
    } else {
      saved = {
        id: generateUniqueId('music'),
        profile_id: '00000000-0000-4000-8000-000000000001',
        title: track.title || 'Lagu Baru',
        artist: track.artist || 'Syahrul Gunawan',
        audio_source_type: track.audio_source_type || 'ambient',
        duration: track.duration || '03:48',
        youtube_url: track.youtube_url || '',
        cover_path: computedCover,
        display_order: list.length + 1,
        is_published: track.is_published ?? true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        ...track
      };
      if (computedCover) saved.cover_path = computedCover;
      list.push(saved);
    }

    if (isSupabaseConfigured() && supabase) {
      const { error } = await supabase.from('music_tracks').upsert(saved);
      if (error) {
        console.error('Supabase music_tracks upsert error:', error);
        throw new Error(`Gagal menyimpan trek musik ke Supabase: ${error.message}`);
      }
    }

    const clean = deduplicateById(list);
    setLocal('music_tracks', clean);
    return saved;
  },

  async deleteMusicTrack(id: string): Promise<void> {
    if (isSupabaseConfigured() && supabase) {
      const { error } = await supabase.from('music_tracks').delete().eq('id', id);
      if (error) {
        console.error('Supabase music_tracks delete error:', error);
        throw new Error(`Gagal menghapus trek musik dari Supabase: ${error.message}`);
      }
    }
    const list = (await this.getMusicTracks(false)).filter((m) => m.id !== id);
    const clean = deduplicateById(list);
    setLocal('music_tracks', clean);
  },

  /**
   * SOCIAL LINKS / BOOKMARK LINKS
   */
  async getSocialLinks(publicOnly: boolean = false): Promise<SocialLink[]> {
    if (isSupabaseConfigured() && supabase) {
      try {
        let q = supabase.from('social_links').select('*').order('display_order', { ascending: true });
        if (publicOnly) q = q.eq('is_published', true);
        const { data, error } = await q;
        if (!error && data && data.length > 0) {
          // Normalize fields
          const mapped = data.map((d: any) => ({
            ...d,
            title: d.title || d.label,
            category: d.category || 'Web'
          }));
          const clean = deduplicateById(mapped);
          setLocal('social_links', clean);
          return clean;
        }
      } catch (e) {}
    }
    const list = getLocal<SocialLink[]>('social_links', SEED_LINKS);
    const clean = deduplicateById(list);
    return publicOnly ? clean.filter((l) => l.is_published) : clean;
  },

  async saveSocialLink(link: Partial<SocialLink>): Promise<SocialLink> {
    const list = await this.getSocialLinks(false);
    let saved: SocialLink;

    const titleToUse = link.title || link.label || 'Tautan Baru';
    const now = new Date().toISOString();

    if (link.id) {
      const idx = list.findIndex((l) => l.id === link.id);
      saved = {
        ...list[idx],
        ...link,
        title: titleToUse,
        label: titleToUse,
        updated_at: now
      } as SocialLink;
      if (idx !== -1) list[idx] = saved;
      else list.push(saved);
    } else {
      saved = {
        id: generateUniqueId('link'),
        profile_id: '00000000-0000-4000-8000-000000000001',
        title: titleToUse,
        label: titleToUse,
        url: link.url || 'https://',
        category: link.category || 'Web',
        platform: link.platform || 'website',
        description: link.description || '',
        icon: link.icon || 'link',
        display_order: list.length + 1,
        is_published: link.is_published ?? true,
        created_at: now,
        updated_at: now
      };
      list.push(saved);
    }

    if (isSupabaseConfigured() && supabase) {
      const { error } = await supabase.from('social_links').upsert(saved);
      if (error) {
        console.error('Supabase social_links upsert error:', error);
        throw new Error(`Gagal menyimpan tautan ke Supabase: ${error.message}`);
      }
    }

    const clean = deduplicateById(list);
    setLocal('social_links', clean);
    return saved;
  },

  async deleteSocialLink(id: string): Promise<void> {
    if (isSupabaseConfigured() && supabase) {
      const { error } = await supabase.from('social_links').delete().eq('id', id);
      if (error) {
        console.error('Supabase social_links delete error:', error);
        throw new Error(`Gagal menghapus tautan dari Supabase: ${error.message}`);
      }
    }
    const list = (await this.getSocialLinks(false)).filter((l) => l.id !== id);
    const clean = deduplicateById(list);
    setLocal('social_links', clean);
  },

  /**
   * PRIVATE NOTES (STRICTLY PRIVATE / OWNER ONLY)
   */
  async getPrivateNotes(): Promise<PrivateNote[]> {
    if (isSupabaseConfigured() && supabase) {
      try {
        const { data, error } = await supabase
          .from('private_notes')
          .select('*')
          .order('updated_at', { ascending: false });
        if (!error && data && data.length > 0) {
          const clean = deduplicateById(data);
          setLocal('private_notes', clean);
          return clean;
        }
      } catch (e) {}
    }
    const raw = getLocal<PrivateNote[]>('private_notes', SEED_NOTES);
    const clean = deduplicateById(raw);
    setLocal('private_notes', clean);
    return clean;
  },

  async savePrivateNote(note: Partial<PrivateNote>): Promise<PrivateNote> {
    const list = deduplicateById(await this.getPrivateNotes());
    let saved: PrivateNote;
    const now = new Date().toISOString();

    if (note.id) {
      const idx = list.findIndex((n) => n.id === note.id);
      saved = {
        ...(idx !== -1 ? list[idx] : {}),
        ...note,
        id: note.id,
        updated_at: now
      } as PrivateNote;
      if (idx !== -1) list[idx] = saved;
      else list.unshift(saved);
    } else {
      const uniqueId = generateUniqueId('note');
      saved = {
        id: uniqueId,
        owner_uid: 'syahrul-admin-uid-001',
        title: note.title || 'Catatan Baru',
        content: note.content || '',
        category: note.category || 'Ide Desain',
        is_private: true,
        is_archived: false,
        created_at: now,
        updated_at: now
      };
      list.unshift(saved);
    }

    if (isSupabaseConfigured() && supabase) {
      const { error } = await supabase.from('private_notes').upsert(saved);
      if (error) {
        console.error('Supabase private_notes upsert error:', error);
        throw new Error(`Gagal menyimpan catatan ke Supabase: ${error.message}`);
      }
    }

    const clean = deduplicateById(list);
    setLocal('private_notes', clean);
    return saved;
  },

  async deletePrivateNote(id: string): Promise<void> {
    if (isSupabaseConfigured() && supabase) {
      const { error } = await supabase.from('private_notes').delete().eq('id', id);
      if (error) {
        console.error('Supabase private_notes delete error:', error);
        throw new Error(`Gagal menghapus catatan dari Supabase: ${error.message}`);
      }
    }
    const list = (await this.getPrivateNotes()).filter((n) => n.id !== id);
    const clean = deduplicateById(list);
    setLocal('private_notes', clean);
  },

  /**
   * VAULT ITEMS (CLIENT ENCRYPTED / AES-GCM)
   */
  async getVaultItems(): Promise<VaultItem[]> {
    if (isSupabaseConfigured() && supabase) {
      try {
        const { data, error } = await supabase
          .from('vault_items')
          .select('*')
          .order('created_at', { ascending: false });
        if (!error && data && data.length > 0) {
          const clean = deduplicateById(data);
          setLocal('vault_items', clean);
          return clean;
        }
      } catch (e) {}
    }
    const list = getLocal<VaultItem[]>('vault_items', SEED_VAULT_ITEMS);
    return deduplicateById(list);
  },

  async saveVaultItem(item: Partial<VaultItem>): Promise<VaultItem> {
    const list = await this.getVaultItems();
    let saved: VaultItem;
    const now = new Date().toISOString();

    if (item.id) {
      const idx = list.findIndex((v) => v.id === item.id);
      saved = {
        ...list[idx],
        ...item,
        updated_at: now
      } as VaultItem;
      if (idx !== -1) list[idx] = saved;
      else list.push(saved);
    } else {
      saved = {
        id: generateUniqueId('vault'),
        owner_uid: 'syahrul-admin-uid-001',
        title: item.title || 'Item Brankas Baru',
        category: item.category || 'Web',
        identity_type: item.identity_type || 'Email',
        identity_value: item.identity_value || '',
        credential_type: item.credential_type || 'Password',
        encrypted_payload: item.encrypted_payload || '',
        encryption_version: 'AES-GCM-PBKDF2-v1',
        secret_value: item.secret_value || '',
        notes: item.notes || '',
        created_at: now,
        updated_at: now
      };
      list.unshift(saved);
    }

    if (isSupabaseConfigured() && supabase) {
      // Only push ciphertext and metadata to cloud database
      const payloadOnly = {
        id: saved.id,
        owner_uid: saved.owner_uid,
        title: saved.title,
        category: saved.category,
        identity_type: saved.identity_type,
        identity_value: saved.identity_value,
        credential_type: saved.credential_type,
        encrypted_payload: saved.encrypted_payload,
        encryption_version: saved.encryption_version,
        notes: saved.notes,
        updated_at: saved.updated_at
      };
      const { error } = await supabase.from('vault_items').upsert(payloadOnly);
      if (error) {
        console.error('Supabase vault_items upsert error:', error);
        throw new Error(`Gagal menyimpan brankas ke Supabase: ${error.message}`);
      }
    }

    setLocal('vault_items', list);
    return saved;
  },

  async deleteVaultItem(id: string): Promise<void> {
    if (isSupabaseConfigured() && supabase) {
      const { error } = await supabase.from('vault_items').delete().eq('id', id);
      if (error) {
        console.error('Supabase vault_items delete error:', error);
        throw new Error(`Gagal menghapus item brankas dari Supabase: ${error.message}`);
      }
    }
    const list = (await this.getVaultItems()).filter((v) => v.id !== id);
    setLocal('vault_items', list);
  },

  /**
   * CHANGE VAULT MASTER PASSPHRASE
   * Re-encrypts all vault items using the new master passphrase.
   * Verifies the old passphrase against existing payloads and/or stored verifier.
   */
  async changeVaultMasterPassphrase(
    oldPassphrase: string,
    newPassphrase: string
  ): Promise<{ success: boolean; reEncryptedCount: number; message: string }> {
    if (!oldPassphrase?.trim()) {
      throw new Error('Kata sandi master saat ini (lama) wajib diisi.');
    }
    if (!newPassphrase || newPassphrase.length < 6) {
      throw new Error('Kata sandi master brankas baru minimal harus 6 karakter.');
    }
    if (oldPassphrase === newPassphrase) {
      throw new Error('Kata sandi brankas baru tidak boleh sama dengan kata sandi saat ini.');
    }

    const items = await this.getVaultItems();

    // 1. Check verifier token if exists in local or cloud storage
    let verifier = getLocal<string | null>('vault_verifier', null);
    if (!verifier && isSupabaseConfigured() && supabase) {
      try {
        const { data } = await supabase
          .from('app_settings')
          .select('setting_value')
          .eq('setting_key', 'vault_passphrase_verifier')
          .maybeSingle();
        if (data?.setting_value?.payload) {
          verifier = data.setting_value.payload;
          setLocal('vault_verifier', verifier);
        }
      } catch {}
    }

    if (verifier) {
      try {
        await decryptSecret(verifier, oldPassphrase);
      } catch {
        throw new Error('Kata sandi master brankas saat ini (lama) salah.');
      }
    }

    // 2. Decrypt all existing items to verify old passphrase and extract plaintext
    const decryptedItems: { item: VaultItem; plainSecret: string }[] = [];
    for (const item of items) {
      if (item.encrypted_payload) {
        try {
          const plain = await decryptSecret(item.encrypted_payload, oldPassphrase);
          decryptedItems.push({ item, plainSecret: plain });
        } catch {
          throw new Error('Kata sandi master brankas saat ini (lama) tidak cocok dengan isi brankas.');
        }
      } else if (item.secret_value) {
        decryptedItems.push({ item, plainSecret: item.secret_value });
      }
    }

    // 3. Re-encrypt all items with new passphrase
    for (const entry of decryptedItems) {
      const newEncryptedPayload = await encryptSecret(entry.plainSecret, newPassphrase);
      await this.saveVaultItem({
        ...entry.item,
        encrypted_payload: newEncryptedPayload,
        encryption_version: 'AES-GCM-PBKDF2-v1',
        secret_value: entry.plainSecret,
        updated_at: new Date().toISOString()
      });
    }

    // 4. Create and persist new verifier token
    const newVerifier = await encryptSecret(
      JSON.stringify({ check: 'VAULT_MASTER_OK', updatedAt: new Date().toISOString() }),
      newPassphrase
    );
    setLocal('vault_verifier', newVerifier);

    if (isSupabaseConfigured() && supabase) {
      try {
        await supabase.from('app_settings').upsert(
          {
            setting_key: 'vault_passphrase_verifier',
            setting_value: { payload: newVerifier, updatedAt: new Date().toISOString() },
            owner_uid: 'syahrul-admin-uid-001'
          },
          { onConflict: 'setting_key' }
        );
      } catch (err) {
        console.warn('Could not store verifier to app_settings:', err);
      }
    }

    const count = decryptedItems.length;
    return {
      success: true,
      reEncryptedCount: count,
      message:
        count > 0
          ? `Kata sandi master brankas berhasil diubah! Sebanyak ${count} item rahasia telah dienkripsi ulang dengan kunci baru.`
          : 'Kata sandi master brankas berhasil diperbarui! Kunci enkripsi baru siap digunakan.'
    };
  },

  /**
   * DONATIONS
   */
  async getDonationSettings(): Promise<DonationSettings> {
    if (isSupabaseConfigured() && supabase) {
      try {
        const { data, error } = await supabase.from('donations').select('*').limit(1).maybeSingle();
        if (!error && data) {
          const sanitized: DonationSettings = {
            ...SEED_DONATIONS,
            ...data,
            title: data.title ?? '',
            description: data.description ?? '',
            donation_url: data.donation_url ?? '',
            qris_image_path: data.qris_image_path || '/assets/qris_syahrul_official.png'
          };
          setLocal('donations', sanitized);
          return sanitized;
        }
      } catch (e) {}
    }
    return getLocal<DonationSettings>('donations', SEED_DONATIONS);
  },

  async updateDonationSettings(settings: Partial<DonationSettings>): Promise<DonationSettings> {
    const current = await this.getDonationSettings();
    const updated: DonationSettings = {
      ...current,
      ...settings,
      updated_at: new Date().toISOString()
    };

    if (isSupabaseConfigured() && supabase) {
      const { error } = await supabase.from('donations').upsert(updated);
      if (error) {
        console.error('Supabase donations upsert error:', error);
        throw new Error(`Gagal menyimpan pengaturan donasi ke Supabase: ${error.message}`);
      }
    }

    setLocal('donations', updated);
    return updated;
  },

  /**
   * MEDIA UPLOAD (SUPABASE STORAGE + CLIENT OBJECT FALLBACK)
   */
  async uploadMedia(
    file: File,
    bucket: 'profile-media' | 'achievement-media' | 'music-media' | 'donation-media'
  ): Promise<{ path: string; url: string }> {
    const maxSize = bucket === 'music-media' ? 25 * 1024 * 1024 : 5 * 1024 * 1024;
    if (file.size > maxSize) {
      throw new Error(`Ukuran berkas melebihi batas maksimal (${maxSize / (1024 * 1024)}MB).`);
    }

    const fileExt = file.name.split('.').pop()?.toLowerCase() || 'png';
    const fileName = `${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${fileExt}`;

    if (isSupabaseConfigured() && supabase) {
      try {
        const { data, error } = await supabase.storage.from(bucket).upload(fileName, file, {
          cacheControl: '3600',
          upsert: true
        });

        if (error) {
          console.warn(`Supabase storage bucket '${bucket}' upload error:`, error.message);
          if (error.message.toLowerCase().includes('bucket not found') || error.message.toLowerCase().includes('not found')) {
            throw new Error(`Bucket '${bucket}' belum dibuat di Supabase Storage. Silakan buat bucket publik '${bucket}' di menu Storage dashboard Supabase Anda.`);
          }
          throw new Error(`Gagal mengunggah media ke Supabase Storage: ${error.message}`);
        }

        if (data) {
          const { data: publicUrlData } = supabase.storage.from(bucket).getPublicUrl(fileName);
          return {
            path: data.path,
            url: publicUrlData.publicUrl
          };
        }
      } catch (err: any) {
        if (err.message && err.message.includes('Supabase Storage')) {
          throw err;
        }
        console.warn('Supabase storage upload fallback:', err);
      }
    }

    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = reader.result as string;
        resolve({
          path: fileName,
          url: dataUrl
        });
      };
      reader.onerror = () => reject(new Error('Gagal membaca berkas.'));
      reader.readAsDataURL(file);
    });
  },

  /**
   * PURGE / RESET ALL DATA TO CLEAN STATE
   */
  async clearAllData(): Promise<void> {
    const emptyProfile: Profile = {
      ...SEED_PROFILE,
      updated_at: new Date().toISOString()
    };
    setLocal('profile', emptyProfile);
    setLocal('profile_details', []);
    setLocal('hobbies', []);
    setLocal('achievements', []);
    setLocal('music_tracks', []);
    setLocal('social_links', []);
    setLocal('private_notes', []);
    setLocal('vault_items', []);
    setLocal('donations', SEED_DONATIONS);

    if (isSupabaseConfigured() && supabase) {
      try {
        const nilUuid = '00000000-0000-0000-0000-000000000000';
        await Promise.allSettled([
          supabase.from('profiles').upsert(emptyProfile),
          supabase.from('donations').upsert(SEED_DONATIONS),
          supabase.from('private_notes').delete().neq('id', nilUuid),
          supabase.from('vault_items').delete().neq('id', nilUuid),
          supabase.from('music_tracks').delete().neq('id', nilUuid),
          supabase.from('achievements').delete().neq('id', nilUuid),
          supabase.from('hobbies').delete().neq('id', nilUuid),
          supabase.from('social_links').delete().neq('id', nilUuid),
          supabase.from('profile_details').delete().neq('id', nilUuid)
        ]);
      } catch (e) {
        console.warn('Supabase clear warning:', e);
      }
    }
  }
};
