import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import { MusicTrack } from '../types';
import { dataService } from '../services/dataService';
import { parseDurationToSeconds, extractYouTubeId } from '../lib/youtube';

interface AudioPlayerContextType {
  tracks: MusicTrack[];
  currentTrack: MusicTrack | null;
  currentTrackIndex: number;
  isPlaying: boolean;
  isVisible: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  audioError: string | null;
  playTrack: (track: MusicTrack) => void;
  togglePlay: () => void;
  playNext: () => void;
  playPrev: () => void;
  setVolume: (vol: number) => void;
  seekTo: (timePercent: number) => void;
  closePlayer: () => void;
  openPlayer: () => void;
  reloadTracks: () => Promise<void>;
  setIsPlayingState: (playing: boolean) => void;
}

const AudioPlayerContext = createContext<AudioPlayerContextType | undefined>(undefined);

export const AudioPlayerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tracks, setTracks] = useState<MusicTrack[]>([]);
  const [currentTrack, setCurrentTrack] = useState<MusicTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isVisible, setIsVisible] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(225); // default 03:45 in seconds
  const [volume, setVolumeState] = useState<number>(0.8);
  const [audioError, setAudioError] = useState<string | null>(null);

  // Web Audio Synth references
  const audioContextRef = useRef<AudioContext | null>(null);
  const oscillatorIntervalRef = useRef<any>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  // HTML5 Audio element for direct audio/url
  const htmlAudioRef = useRef<HTMLAudioElement | null>(null);

  // Progress ticker for non-HTML5 (YouTube / Synth)
  const progressTimerRef = useRef<any>(null);

  const loadTracks = useCallback(async () => {
    try {
      const data = await dataService.getMusicTracks(true);
      setTracks(data);
      if (data.length > 0 && !currentTrack) {
        setCurrentTrack(data[0]);
        setDuration(parseDurationToSeconds(data[0].duration));
      }
    } catch (e) {
      console.error('Failed to load music tracks:', e);
    }
  }, [currentTrack]);

  useEffect(() => {
    loadTracks();
  }, [loadTracks]);

  // Clean up Web Audio Synth
  const stopAmbientSynth = useCallback(() => {
    if (oscillatorIntervalRef.current) {
      clearInterval(oscillatorIntervalRef.current);
      oscillatorIntervalRef.current = null;
    }
  }, []);

  // Web Audio ambient synthesizer (only for ambient audio source)
  const startAmbientSynth = useCallback(() => {
    stopAmbientSynth();
    try {
      if (!audioContextRef.current) {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        audioContextRef.current = new AudioCtx();
      }
      const ctx = audioContextRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      if (!gainNodeRef.current) {
        gainNodeRef.current = ctx.createGain();
        gainNodeRef.current.connect(ctx.destination);
      }
      gainNodeRef.current.gain.setValueAtTime(volume * 0.12, ctx.currentTime);

      const notes = [261.63, 293.66, 329.63, 392.00, 440.00, 523.25, 587.33];
      let noteIndex = 0;

      oscillatorIntervalRef.current = setInterval(() => {
        if (!ctx) return;
        const freq = notes[noteIndex % notes.length];
        noteIndex = (noteIndex + 1) % notes.length;

        const osc = ctx.createOscillator();
        const noteGain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime);

        noteGain.gain.setValueAtTime(0, ctx.currentTime);
        noteGain.gain.linearRampToValueAtTime(0.06 * volume, ctx.currentTime + 0.4);
        noteGain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 3.0);

        osc.connect(noteGain);
        noteGain.connect(gainNodeRef.current || ctx.destination);

        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 3.2);
      }, 1400);
    } catch (e) {
      console.warn('Web Audio synthesis error:', e);
    }
  }, [volume, stopAmbientSynth]);

  // Stop HTML5 Audio
  const stopHtmlAudio = useCallback(() => {
    if (htmlAudioRef.current) {
      htmlAudioRef.current.pause();
      htmlAudioRef.current.src = '';
      htmlAudioRef.current = null;
    }
  }, []);

  // Handle Play / Pause / Track changes
  useEffect(() => {
    if (!currentTrack) {
      stopAmbientSynth();
      stopHtmlAudio();
      clearInterval(progressTimerRef.current);
      return;
    }

    const isYouTube =
      currentTrack.audio_source_type === 'youtube' ||
      Boolean(currentTrack.youtube_url && extractYouTubeId(currentTrack.youtube_url));

    const isDirectAudio =
      (currentTrack.audio_source_type === 'url' || currentTrack.audio_source_type === 'upload') &&
      Boolean(currentTrack.audio_url);

    if (isPlaying) {
      setAudioError(null);

      if (isYouTube) {
        // Stop background synth and HTML5 audio so YouTube plays cleanly without collision
        stopAmbientSynth();
        stopHtmlAudio();

        // Run progress ticker based on duration
        clearInterval(progressTimerRef.current);
        progressTimerRef.current = setInterval(() => {
          setCurrentTime((prev) => {
            if (prev >= duration) {
              return duration;
            }
            return prev + 1;
          });
        }, 1000);
      } else if (isDirectAudio) {
        // Direct HTML5 audio stream
        stopAmbientSynth();
        clearInterval(progressTimerRef.current);

        if (!htmlAudioRef.current) {
          const audio = new Audio(currentTrack.audio_url);
          audio.volume = volume;
          audio.ontimeupdate = () => setCurrentTime(Math.floor(audio.currentTime));
          audio.onloadedmetadata = () => {
            if (audio.duration && !isNaN(audio.duration)) {
              setDuration(Math.floor(audio.duration));
            }
          };
          audio.onerror = () => {
            setAudioError('Berkas audio tidak dapat diputar atau alamat tidak dapat diakses.');
            setIsPlaying(false);
          };
          htmlAudioRef.current = audio;
        }

        htmlAudioRef.current.play().catch((err) => {
          console.warn('Audio play request failed:', err);
          setAudioError('Gagal memutar audio. Pastikan peramban mengizinkan pemutaran.');
          setIsPlaying(false);
        });
      } else {
        // Ambient synthesizer
        stopHtmlAudio();
        startAmbientSynth();

        clearInterval(progressTimerRef.current);
        progressTimerRef.current = setInterval(() => {
          setCurrentTime((prev) => {
            if (prev >= duration) {
              return 0;
            }
            return prev + 1;
          });
        }, 1000);
      }
    } else {
      // Paused
      stopAmbientSynth();
      if (htmlAudioRef.current) {
        htmlAudioRef.current.pause();
      }
      clearInterval(progressTimerRef.current);
    }

    return () => {
      stopAmbientSynth();
      clearInterval(progressTimerRef.current);
    };
  }, [isPlaying, currentTrack, duration, volume, startAmbientSynth, stopAmbientSynth, stopHtmlAudio]);

  // Adjust volume
  useEffect(() => {
    if (gainNodeRef.current && audioContextRef.current) {
      gainNodeRef.current.gain.setValueAtTime(volume * 0.12, audioContextRef.current.currentTime);
    }
    if (htmlAudioRef.current) {
      htmlAudioRef.current.volume = volume;
    }
  }, [volume]);

  const playTrack = useCallback((track: MusicTrack) => {
    // Stop any ongoing playback before switching
    stopAmbientSynth();
    stopHtmlAudio();
    clearInterval(progressTimerRef.current);

    setCurrentTrack(track);
    const durSecs = parseDurationToSeconds(track.duration);
    setDuration(durSecs);
    setCurrentTime(0);
    setAudioError(null);
    setIsPlaying(true);
    setIsVisible(true);
  }, [stopAmbientSynth, stopHtmlAudio]);

  const togglePlay = useCallback(() => {
    if (!currentTrack && tracks.length > 0) {
      playTrack(tracks[0]);
      return;
    }
    setIsPlaying((prev) => !prev);
    setIsVisible(true);
  }, [currentTrack, tracks, playTrack]);

  const currentTrackIndex = currentTrack
    ? tracks.findIndex((t) => t.id === currentTrack.id)
    : 0;

  const playNext = useCallback(() => {
    if (tracks.length === 0) return;
    const currentIdx = tracks.findIndex((t) => t.id === currentTrack?.id);
    const nextIdx = (currentIdx + 1) % tracks.length;
    playTrack(tracks[nextIdx]);
  }, [tracks, currentTrack, playTrack]);

  const playPrev = useCallback(() => {
    if (tracks.length === 0) return;
    const currentIdx = tracks.findIndex((t) => t.id === currentTrack?.id);
    const prevIdx = (currentIdx - 1 + tracks.length) % tracks.length;
    playTrack(tracks[prevIdx]);
  }, [tracks, currentTrack, playTrack]);

  const setVolume = useCallback((val: number) => {
    setVolumeState(val);
  }, []);

  const seekTo = useCallback((percent: number) => {
    const targetSeconds = Math.floor(percent * duration);
    setCurrentTime(targetSeconds);
    if (htmlAudioRef.current) {
      htmlAudioRef.current.currentTime = targetSeconds;
    }
  }, [duration]);

  const closePlayer = useCallback(() => {
    setIsPlaying(false);
    setIsVisible(false);
    stopAmbientSynth();
    stopHtmlAudio();
  }, [stopAmbientSynth, stopHtmlAudio]);

  const openPlayer = useCallback(() => {
    setIsVisible(true);
  }, []);

  const setIsPlayingState = useCallback((playing: boolean) => {
    setIsPlaying(playing);
  }, []);

  return (
    <AudioPlayerContext.Provider
      value={{
        tracks,
        currentTrack,
        currentTrackIndex: Math.max(0, currentTrackIndex),
        isPlaying,
        isVisible,
        currentTime,
        duration,
        volume,
        audioError,
        playTrack,
        togglePlay,
        playNext,
        playPrev,
        setVolume,
        seekTo,
        closePlayer,
        openPlayer,
        reloadTracks: loadTracks,
        setIsPlayingState
      }}
    >
      {children}
    </AudioPlayerContext.Provider>
  );
};

export const useAudioPlayer = () => {
  const context = useContext(AudioPlayerContext);
  if (!context) {
    throw new Error('useAudioPlayer must be used within an AudioPlayerProvider');
  }
  return context;
};
