import React, { createContext, useContext, useState, useEffect } from 'react';
import { auth, isFirebaseConfigured } from '../lib/firebase';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import {
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail,
  User
} from 'firebase/auth';

interface AuthContextType {
  user: User | null;
  isAdmin: boolean;
  isLoading: boolean;
  login: (identifier: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ success: boolean; error?: string }>;
  adminInfo: { name: string; email: string; role: string };
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);
const ADMIN_EMAIL = (import.meta.env.VITE_ADMIN_EMAIL || 'ayungnew768@gmail.com').trim().toLowerCase();

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const adminInfo = {
    name: 'Syahrul Gunawan',
    email: ADMIN_EMAIL,
    role: 'Pengelola Utama / Pemilik'
  };

  useEffect(() => {
    if (!isFirebaseConfigured() || !auth) {
      setUser(null);
      setIsAdmin(false);
      setIsLoading(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
      // Client-side UI gate only. Firestore rules must independently enforce admin access.
      setIsAdmin(Boolean(firebaseUser?.email && firebaseUser.email.toLowerCase() === ADMIN_EMAIL));
      setIsLoading(false);
    });
    return unsubscribe;
  }, []);

  const login = async (identifier: string, password: string): Promise<{ success: boolean; error?: string }> => {
    if (!isFirebaseConfigured() || !auth) {
      return { success: false, error: 'Login belum tersedia karena konfigurasi Firebase belum lengkap.' };
    }

    setIsLoading(true);
    const cleanId = identifier.trim();
    const emailToUse = cleanId.includes('@') ? cleanId.toLowerCase() :
      (cleanId.toLowerCase() === 'admin' || cleanId.toLowerCase() === 'syahrulgunawan'
        ? ADMIN_EMAIL
        : `${cleanId}@syahrulgunawan.com`);

    try {
      if (emailToUse !== ADMIN_EMAIL) {
        return { success: false, error: 'Gunakan email administrator yang sudah ditetapkan.' };
      }
      if (!isSupabaseConfigured() || !supabase) {
        return { success: false, error: 'Supabase belum lengkap. Isi VITE_SUPABASE_ANON_KEY dan deploy ulang sebelum login admin.' };
      }

      // CMS writes require a separate Supabase Auth session as well as Firebase Auth.
      const { error: supabaseError } = await supabase.auth.signInWithPassword({ email: emailToUse, password });
      if (supabaseError) {
        const sbMsg = supabaseError.message.toLowerCase();
        let helpfulMsg = `Login Supabase gagal: ${supabaseError.message}.`;
        if (sbMsg.includes('invalid login credentials')) {
          helpfulMsg = 'Kredensial Supabase tidak cocok. Pastikan akun email ' + ADMIN_EMAIL + ' sudah dibuat di menu Authentication Supabase dengan kata sandi yang sesuai.';
        } else if (sbMsg.includes('email not confirmed')) {
          helpfulMsg = 'Email akun di Supabase belum dikonfirmasi. Konfirmasi email atau aktifkan "Auto Confirm" di Supabase Auth Settings.';
        }
        return { success: false, error: helpfulMsg };
      }

      try {
        const userCred = await signInWithEmailAndPassword(auth, emailToUse, password);
        if (userCred.user.email?.toLowerCase() !== ADMIN_EMAIL) {
          await signOut(auth);
          await supabase.auth.signOut();
          setUser(null);
          setIsAdmin(false);
          return { success: false, error: 'Akun ini tidak memiliki hak akses administrator.' };
        }
        setUser(userCred.user);
        setIsAdmin(true);
        return { success: true };
      } catch (firebaseError: any) {
        await supabase.auth.signOut();
        const code = firebaseError?.code || '';
        let fbMsg = 'Login Firebase Authentication gagal.';
        if (code === 'auth/invalid-credential' || code === 'auth/wrong-password') {
          fbMsg = 'Kata sandi akun Firebase tidak cocok. Pastikan kata sandi sama dengan akun di Supabase.';
        } else if (code === 'auth/user-not-found') {
          fbMsg = `Akun ${ADMIN_EMAIL} belum dibuat di Firebase Authentication. Tambahkan pengguna di Firebase Console > Authentication > Users.`;
        } else if (code === 'auth/too-many-requests') {
          fbMsg = 'Terlalu banyak percobaan gagal. Silakan tunggu beberapa saat atau reset kata sandi.';
        } else {
          fbMsg = `Login Firebase gagal: ${firebaseError?.message || code}`;
        }
        return { success: false, error: fbMsg };
      }
    } catch (err: any) {
      return { success: false, error: 'Login gagal. Periksa konfigurasi Firebase, Supabase, dan koneksi internet.' };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async (): Promise<void> => {
    if (auth) await signOut(auth);
    if (supabase) await supabase.auth.signOut();
    setUser(null);
    setIsAdmin(false);
  };

  const resetPassword = async (email: string): Promise<{ success: boolean; error?: string }> => {
    if (!isFirebaseConfigured() || !auth) {
      return { success: false, error: 'Pemulihan kata sandi membutuhkan konfigurasi Firebase.' };
    }
    try {
      await sendPasswordResetEmail(auth, email.trim());
      return { success: true };
    } catch (err: any) {
      return { success: false, error: 'Gagal mengirim email pemulihan. Periksa alamat email dan pengaturan Firebase.' };
    }
  };

  return (
    <AuthContext.Provider value={{ user, isAdmin, isLoading, login, logout, resetPassword, adminInfo }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
