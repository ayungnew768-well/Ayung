import { createClient, SupabaseClient } from '@supabase/supabase-js';

const rawSupabaseUrl = (import.meta.env.VITE_SUPABASE_URL || '').trim();
// Clean up URL: remove /rest/v1 or trailing slashes in case user pasted the REST API URL
const cleanSupabaseUrl = rawSupabaseUrl.replace(/\/rest\/v1\/?$/, '').replace(/\/+$/, '');
const supabaseAnonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY || '').trim();

export const isSupabaseConfigured = (): boolean => {
  return !!(
    cleanSupabaseUrl &&
    supabaseAnonKey &&
    (cleanSupabaseUrl.startsWith('https://') || cleanSupabaseUrl.startsWith('http://'))
  );
};


export const supabase: SupabaseClient | null = isSupabaseConfigured()
  ? createClient(cleanSupabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true
      }
    })
  : null;

/**
 * Tests real connection to Supabase PostgreSQL and Storage.
 */
export async function testSupabaseConnection(): Promise<{
  success: boolean;
  message: string;
  tablesMissing?: boolean;
  bucketsFound?: string[];
}> {
  if (!isSupabaseConfigured() || !supabase) {
    return {
      success: false,
      message: 'Kredensial Supabase (URL & Anon Key) belum diisi pada file .env.'
    };
  }

  try {
    // 1. Test database ping
    const { error: dbError } = await supabase.from('profiles').select('id').limit(1);

    if (dbError && dbError.code !== 'PGRST116') {
      if (
        dbError.message.includes('relation "public.profiles" does not exist') ||
        dbError.message.includes('schema cache')
      ) {
        return {
          success: true,
          tablesMissing: true,
          message: 'Terhubung ke Supabase! Tabel belum dibuat di PostgreSQL. Jalankan migrasi SQL di Supabase SQL Editor.'
        };
      }
      return {
        success: false,
        message: `Koneksi database gagal: ${dbError.message}`
      };
    }

    // 2. Test storage buckets safely
    let bucketNames: string[] = [];
    try {
      const { data: buckets } = await supabase.storage.listBuckets();
      bucketNames = buckets?.map((b) => b.name) || [];
    } catch {
      // Bucket listing permission might be restricted to admin only, which is fine
    }

    return {
      success: true,
      tablesMissing: false,
      message: 'Terhubung ke Supabase PostgreSQL & Storage secara aktif.',
      bucketsFound: bucketNames
    };
  } catch (err: any) {
    return {
      success: false,
      message: err?.message || 'Gagal menghubungi Supabase.'
    };
  }
}
