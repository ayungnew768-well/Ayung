/**
 * Client-Side Cryptographic Vault Engine
 * Implements military-grade AES-GCM (256-bit) and PBKDF2 with random salts using Web Crypto API.
 * Never leaks plaintext secrets to server logs or network payloads.
 */

export interface EncryptedPackage {
  v: string; // Version
  s: string; // Base64 Salt
  iv: string; // Base64 IV
  ct: string; // Base64 Ciphertext
}

/**
 * Derives an AES-GCM 256-bit key from a user master passphrase and salt using PBKDF2.
 */
async function deriveKey(passphrase: string, salt: Uint8Array): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(passphrase),
    { name: 'PBKDF2' },
    false,
    ['deriveBits', 'deriveKey']
  );

  return window.crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: salt as BufferSource,
      iterations: 100000,
      hash: 'SHA-256'
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

/**
 * Encrypts a plaintext secret with a user master passphrase.
 * Returns a JSON serialized string containing version, salt, iv, and ciphertext.
 */
export async function encryptSecret(plaintext: string, masterPassphrase: string): Promise<string> {
  const salt = window.crypto.getRandomValues(new Uint8Array(16));
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(masterPassphrase, salt);

  const enc = new TextEncoder();
  const encodedPlaintext = enc.encode(plaintext);

  const encryptedBuffer = await window.crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv: iv as BufferSource
    },
    key,
    encodedPlaintext
  );

  const pkg: EncryptedPackage = {
    v: 'AES-GCM-PBKDF2-v1',
    s: uint8ArrayToBase64(salt),
    iv: uint8ArrayToBase64(iv),
    ct: arrayBufferToBase64(encryptedBuffer)
  };

  return JSON.stringify(pkg);
}

/**
 * Decrypts an encrypted package with the user master passphrase.
 * Throws an error if the passphrase is incorrect or data has been tampered with.
 */
export async function decryptSecret(payloadJson: string, masterPassphrase: string): Promise<string> {
  try {
    const pkg: EncryptedPackage = JSON.parse(payloadJson);
    if (!pkg.s || !pkg.iv || !pkg.ct) {
      throw new Error('Format brankas terenkripsi tidak valid.');
    }

    const salt = base64ToUint8Array(pkg.s);
    const iv = base64ToUint8Array(pkg.iv);
    const ciphertext = base64ToArrayBuffer(pkg.ct);

    const key = await deriveKey(masterPassphrase, salt);

    const decryptedBuffer = await window.crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: iv as BufferSource
      },
      key,
      ciphertext
    );

    const dec = new TextDecoder();
    return dec.decode(decryptedBuffer);
  } catch (err) {
    throw new Error('Kata sandi master brankas salah atau data rusak.');
  }
}

/**
 * Generates a cryptographically strong random password.
 */
export function generateStrongPassword(
  length: number = 20,
  options: { numbers?: boolean; symbols?: boolean; uppercase?: boolean } = { numbers: true, symbols: true, uppercase: true }
): string {
  let chars = 'abcdefghijklmnopqrstuvwxyz';
  if (options.uppercase) chars += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  if (options.numbers) chars += '0123456789';
  if (options.symbols) chars += '!@#$%^&*()_+-=[]{}|;:,.<>?';

  const randomValues = new Uint32Array(length);
  window.crypto.getRandomValues(randomValues);

  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars[randomValues[i] % chars.length];
  }
  return result;
}

// Base64 helper utilities
function uint8ArrayToBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
}

function base64ToUint8Array(base64: string): Uint8Array {
  const binary = window.atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  return uint8ArrayToBase64(new Uint8Array(buffer));
}

function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binary = window.atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer.slice(0);
}
