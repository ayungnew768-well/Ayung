import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { getFirestore, Firestore, doc, getDoc, setDoc } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET
};

export const isFirebaseConfigured = (): boolean => {
  return !!(
    firebaseConfig.apiKey &&
    firebaseConfig.authDomain &&
    firebaseConfig.projectId &&
    firebaseConfig.appId
  );
};

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;

if (isFirebaseConfigured()) {
  try {
    app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
    auth = getAuth(app);
    db = getFirestore(app);
  } catch (error) {
    console.warn('Firebase initialization error:', error);
  }
}

export { app, auth, db };

/**
 * Tests the real connection to Firebase by checking auth state and Firestore ping.
 */
export async function testFirebaseConnection(): Promise<{ success: boolean; message: string }> {
  if (!isFirebaseConfigured()) {
    return {
      success: false,
      message: 'Kredensial Firebase belum dikonfigurasi di file .env.'
    };
  }

  try {
    if (!db) throw new Error('Firestore tidak terinisialisasi');
    const testDocRef = doc(db, 'app_config', 'health_check');
    await getDoc(testDocRef);
    return {
      success: true,
      message: 'Terhubung ke Firebase Firestore & Auth secara aktif.'
    };
  } catch (err: any) {
    // If the server responded with permission-denied, the Firebase project, API key,
    // and Firestore database are reachable and active, but protected by Security Rules.
    if (err?.code === 'permission-denied') {
      return {
        success: true,
        message: 'Terhubung ke Firebase Firestore & Auth. Aturan keamanan (Security Rules) aktif melindungi data.'
      };
    }
    return {
      success: false,
      message: err?.message || 'Gagal terhubung ke Firebase.'
    };
  }
}

