import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { EditorialMusicPlayer } from '../../components/EditorialMusicPlayer';
import { useAuth } from '../../context/AuthContext';
import {
  Menu,
  X,
  Lock,
  Home,
  Trophy,
  Headphones,
  Link2,
  Heart,
  Palette,
  ArrowLeft
} from 'lucide-react';

export const MusicPlayerPage: React.FC = () => {
  const { isAdmin } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  return (
    <div className="min-h-screen bg-surface text-on-surface flex flex-col font-sans selection:bg-secondary-container selection:text-on-secondary-container">
      {/* Top Editorial Header matching Gambar Pertama */}
      <header className="sticky top-0 z-40 bg-surface/90 backdrop-blur-md border-b border-outline-variant/30">
        <div className="max-w-xl mx-auto px-4 h-16 flex items-center justify-between">
          {/* Identity: Avatar + Name + Subtitle */}
          <Link to="/" className="flex items-center gap-3 group text-left">
            <div className="w-10 h-10 rounded-full overflow-hidden bg-surface-container p-0.5 ring-1 ring-outline-variant/40 shadow-xs shrink-0">
              <img
                src="/assets/syahrul_portrait.png"
                alt="Syahrul Gunawan"
                className="w-full h-full object-cover rounded-full"
              />
            </div>
            <div className="min-w-0">
              <h1 className="font-sans font-bold text-sm tracking-tight text-on-surface group-hover:text-primary transition-colors uppercase truncate">
                SYAHRUL GUNAWAN
              </h1>
              <p className="text-[11px] text-secondary truncate">
                The Best Goodlane
              </p>
            </div>
          </Link>

          {/* Right Action Icons */}
          <div className="flex items-center gap-2">
            <Link
              to="/"
              className="p-2 rounded-xl text-secondary hover:text-on-surface hover:bg-surface-container transition-colors"
              title="Kembali ke Portofolio"
            >
              <Home className="w-5 h-5" />
            </Link>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl text-on-surface hover:bg-surface-container transition-colors"
              aria-label="Buka Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Main Music Player Content Viewport */}
      <main className="flex-1 max-w-xl mx-auto w-full px-4 py-6">
        <EditorialMusicPlayer />
      </main>

      {/* Footer */}
      <footer className="py-6 border-t border-outline-variant/20 text-center text-xs text-secondary">
        <div className="max-w-xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <span>&copy; {new Date().getFullYear()} Syahrul Gunawan • Ruang Kurasi</span>
          <Link
            to={isAdmin ? '/admin/music' : '/login'}
            className="text-primary hover:underline text-[11px] font-medium flex items-center gap-1"
          >
            <Lock className="w-3 h-3" />
            <span>{isAdmin ? 'Kelola Musik di Admin' : 'Login Admin'}</span>
          </Link>
        </div>
      </footer>

      {/* Slide-out Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 bg-on-surface/30 backdrop-blur-xs flex justify-end animate-in fade-in">
          <div className="w-72 bg-surface-container-lowest h-full p-6 shadow-2xl flex flex-col justify-between border-l border-outline-variant/30">
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-outline-variant/20">
                <span className="font-editorial text-lg text-on-surface font-semibold">
                  Navigasi
                </span>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1 rounded-lg text-secondary hover:text-on-surface"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <nav className="space-y-1">
                <Link
                  to="/"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-secondary hover:text-on-surface hover:bg-surface-container transition-colors"
                >
                  <Home className="w-4 h-4 text-primary" />
                  <span>Beranda Profil</span>
                </Link>
                <Link
                  to="/#prestasi"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-secondary hover:text-on-surface hover:bg-surface-container transition-colors"
                >
                  <Trophy className="w-4 h-4 text-primary" />
                  <span>Prestasi &amp; Rekam Jejak</span>
                </Link>
                <Link
                  to="/music"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium bg-primary/10 text-primary font-semibold"
                >
                  <Headphones className="w-4 h-4 text-primary" />
                  <span>Pemutar Musik</span>
                </Link>
                <Link
                  to="/#kontak"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-secondary hover:text-on-surface hover:bg-surface-container transition-colors"
                >
                  <Link2 className="w-4 h-4 text-primary" />
                  <span>Tautan Resmi</span>
                </Link>
              </nav>
            </div>

            <div className="pt-4 border-t border-outline-variant/20">
              <Link
                to={isAdmin ? '/admin' : '/login'}
                onClick={() => setMobileMenuOpen(false)}
                className="w-full py-2.5 px-4 rounded-xl bg-surface-container hover:bg-surface-container-high text-xs font-semibold text-primary flex items-center justify-center gap-2 transition-colors"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>{isAdmin ? 'Dashboard Pengelola' : 'Login Admin'}</span>
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
