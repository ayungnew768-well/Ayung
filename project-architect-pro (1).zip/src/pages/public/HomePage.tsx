import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { dataService } from '../../services/dataService';
import {
  Profile,
  ProfileDetail,
  Achievement,
  Hobby,
  MusicTrack,
  SocialLink,
  DonationSettings
} from '../../types';
import { EditorialMusicPlayer } from '../../components/EditorialMusicPlayer';
import { useAudioPlayer } from '../../context/AudioPlayerContext';
import { useAuth } from '../../context/AuthContext';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  Heart,
  Lock,
  ExternalLink,
  Copy,
  Check,
  CheckCircle,
  Disc,
  QrCode,
  Share2,
  Camera,
  Coffee,
  Bike,
  Sparkles,
  ArrowUpRight,
  ShieldCheck,
  Music,
  Headphones
} from 'lucide-react';

export const HomePage: React.FC = () => {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [details, setDetails] = useState<ProfileDetail[]>([]);
  const [hobbies, setHobbies] = useState<Hobby[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [tracks, setTracks] = useState<MusicTrack[]>([]);
  const [links, setLinks] = useState<SocialLink[]>([]);
  const [donation, setDonation] = useState<DonationSettings | null>(null);

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');
  const [showDonationDrawer, setShowDonationDrawer] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);

  const {
    currentTrack,
    isPlaying,
    currentTime,
    duration,
    volume,
    playTrack,
    togglePlay,
    playNext,
    playPrev,
    setVolume,
    seekTo
  } = useAudioPlayer();

  const { isAdmin } = useAuth();

  useEffect(() => {
    async function loadData() {
      try {
        setIsLoading(true);
        const [profData, detData, hobData, achData, musData, lnkData, donData] =
          await Promise.all([
            dataService.getProfile(),
            dataService.getProfileDetails(),
            dataService.getHobbies(true),
            dataService.getAchievements(true),
            dataService.getMusicTracks(true),
            dataService.getSocialLinks(true),
            dataService.getDonationSettings()
          ]);

        setProfile(profData);
        setDetails(detData);
        setHobbies(hobData);
        setAchievements(achData);
        setTracks(musData);
        setLinks(lnkData);
        setDonation(donData);
      } catch (err) {
        console.error('Failed to load public data:', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadData();
  }, []);

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = Math.floor(secs % 60);
    return `${mins.toString().padStart(2, '0')}:${rem.toString().padStart(2, '0')}`;
  };

  const handleCopyDonationUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const categories = ['Semua', ...Array.from(new Set(achievements.map((a) => a.category)))];
  const filteredAchievements =
    selectedCategory === 'Semua'
      ? achievements
      : achievements.filter((a) => a.category === selectedCategory);

  const getHobbyIcon = (iconName: string) => {
    switch (iconName.toLowerCase()) {
      case 'photo_camera':
      case 'camera':
        return <Camera className="w-5 h-5 text-primary" />;
      case 'local_cafe':
      case 'coffee':
        return <Coffee className="w-5 h-5 text-primary" />;
      case 'directions_bike':
      case 'bike':
        return <Bike className="w-5 h-5 text-primary" />;
      default:
        return <Sparkles className="w-5 h-5 text-primary" />;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-surface flex flex-col items-center justify-center">
        <div className="w-10 h-10 border-2 border-primary border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="font-editorial text-lg text-secondary">Memuat Ruang Kurasi Syahrul Gunawan...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-surface text-on-surface flex flex-col selection:bg-secondary-container selection:text-on-secondary-container">
      {/* Editorial Header */}
      <header className="fixed top-0 left-0 right-0 z-40 bg-surface/90 backdrop-blur-md border-b border-outline-variant/30">
        <div className="h-16 max-w-4xl mx-auto px-4 md:px-8 flex items-center justify-between">
          <a href="#" className="flex items-center gap-1.5 group">
            <span className="font-editorial text-xl font-medium tracking-tight text-on-surface group-hover:text-primary transition-colors">
              {profile?.display_name || 'Syahrul Gunawan'}
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-primary inline-block"></span>
          </a>

          <div className="flex items-center gap-3 md:gap-6">
            <nav className="hidden sm:flex items-center gap-4 text-xs font-sans tracking-wide text-secondary">
              <a href="#tentang" className="hover:text-primary transition-colors">
                Tentang
              </a>
              <a href="#prestasi" className="hover:text-primary transition-colors">
                Prestasi
              </a>
              <a href="#musik" className="hover:text-primary transition-colors">
                Musik
              </a>
              <a href="#kontak" className="hover:text-primary transition-colors">
                Tautan
              </a>
              {donation?.enabled && (
                <a href="#donasi" className="hover:text-primary transition-colors">
                  Donasi
                </a>
              )}
            </nav>

            <Link
              to={isAdmin ? '/admin' : '/login'}
              className="text-xs font-sans font-semibold text-primary border border-outline-variant/60 hover:bg-surface-container px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{isAdmin ? 'Dashboard Admin' : 'Login Admin'}</span>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="w-full pt-16 flex-1">
        <div className="max-w-4xl mx-auto px-4 md:px-8 py-8 md:py-16">
          {/* Section 1: Hero Profile Introduction */}
          <section className="py-8 md:py-16">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-8 md:gap-12">
              {/* Profile Image Viewport */}
              <div className="relative shrink-0">
                <div className="w-48 h-48 sm:w-56 sm:h-56 md:w-64 md:h-64 rounded-full overflow-hidden bg-surface-container p-1.5 ring-1 ring-outline-variant/40 shadow-sm">
                  <img
                    src={profile?.profile_photo_path || '/assets/syahrul_portrait.png'}
                    alt={profile?.display_name || 'Syahrul Gunawan'}
                    className="w-full h-full object-cover rounded-full"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src =
                        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80';
                    }}
                  />
                </div>
                {/* Active Status Beacon */}
                <div
                  className="absolute bottom-2 right-2 md:bottom-3 md:right-3 bg-surface p-1 rounded-full shadow-sm"
                  title="Aktif & Terbuka untuk Kolaborasi"
                >
                  <span className="flex h-3.5 w-3.5 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-60"></span>
                    <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-primary"></span>
                  </span>
                </div>
              </div>

              {/* Editorial Intro Typography */}
              <div className="flex-1 flex flex-col items-start">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-surface-container text-primary text-xs font-sans font-semibold tracking-wider uppercase mb-3">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
                  Tersedia untuk kolaborasi terpilih
                </div>

                <div className="flex items-baseline gap-2 mb-1">
                  <h1 className="font-editorial text-4xl sm:text-5xl md:text-6xl text-on-surface tracking-tight font-normal">
                    {profile?.display_name || 'Syahrul Gunawan'}
                  </h1>
                  <span className="font-sans text-xs text-outline tracking-widest font-normal uppercase hidden sm:inline-block">
                    [S.Kom., M.Ds.]
                  </span>
                </div>

                {profile?.headline && (
                  <p className="font-editorial text-lg md:text-xl text-primary mb-4 font-medium italic">
                    {profile.headline}
                  </p>
                )}

                {profile?.biography && (
                  <p className="font-sans text-sm md:text-base text-on-surface-variant max-w-xl leading-relaxed mb-6">
                    {profile.biography}
                  </p>
                )}

                <div className="flex flex-wrap items-center gap-3">
                  {donation?.enabled && (
                    <a
                      href="#donasi"
                      className="bg-primary text-on-primary font-sans font-medium text-xs md:text-sm px-5 py-2.5 rounded-lg hover:bg-primary-container transition-colors inline-flex items-center gap-2 shadow-sm"
                    >
                      <Heart className="w-4 h-4" />
                      <span>Dukung Portofolio</span>
                    </a>
                  )}
                  <a
                    href="#tentang"
                    className="border border-outline-variant/60 text-on-surface font-sans font-medium text-xs md:text-sm px-5 py-2.5 rounded-lg hover:bg-surface-container-low transition-colors"
                  >
                    Eksplorasi Profil
                  </a>
                </div>
              </div>
            </div>
          </section>

          {/* Hairline Divider */}
          <div className="w-full h-px bg-outline-variant/30 my-8"></div>

          {/* Section 2: Tentang Saya & Data Diri Terstruktur */}
          <section className="py-8 md:py-14" id="tentang">
            <div className="flex flex-col gap-6">
              <div className="flex flex-col gap-1">
                <span className="font-sans text-xs text-primary uppercase tracking-widest font-semibold">
                  Profil Pribadi
                </span>
                <h2 className="font-editorial text-3xl md:text-4xl text-on-surface tracking-tight">
                  Tentang Saya
                </h2>
                <p className="font-sans text-sm text-on-surface-variant max-w-2xl mt-1 leading-relaxed">
                  Fokus pada persimpangan antara estetika fungsional, arsitektur informasi, dan
                  pertumbuhan produk jangka panjang. Bekerja bersama tim lintas disiplin untuk
                  memecahkan persoalan digital nyata.
                </p>
              </div>

              {/* Key-Value Structured Data Table Grid */}
              {details.length === 0 ? (
                <div className="py-4 text-xs text-secondary italic">
                  Belum ada entri rincian data diri yang ditambahkan.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-0 text-on-surface border-t border-outline-variant/30 mt-2">
                  {details.map((detail, idx) => (
                    <div
                      key={`${detail.id || 'detail'}-${idx}`}
                      className={`flex items-start justify-between py-3.5 border-b border-outline-variant/30 ${
                        detail.section_type !== 'personal' ? 'col-span-1 md:col-span-2' : ''
                      }`}
                    >
                      <span className="font-sans text-xs uppercase tracking-wider text-secondary shrink-0 pt-0.5">
                        {detail.title}
                      </span>
                      <span className="font-sans text-sm text-on-surface font-medium text-right ml-4">
                        {detail.content}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>

          {/* Hairline Divider */}
          <div className="w-full h-px bg-outline-variant/30 my-8"></div>

          {/* Section 3: Hobi & Minat */}
          <section className="py-8 md:py-14">
            <div className="flex flex-col gap-6">
              <div className="flex flex-col gap-1">
                <span className="font-sans text-xs text-primary uppercase tracking-widest font-semibold">
                  Di Luar Pekerjaan
                </span>
                <h2 className="font-editorial text-3xl md:text-4xl text-on-surface tracking-tight">
                  Hobi &amp; Minat
                </h2>
                <p className="font-sans text-sm text-on-surface-variant max-w-xl">
                  Aktivitas yang memberi saya perspektif baru dan menjaga kejernihan berpikir di sela
                  kesibukan studio.
                </p>
              </div>

              {hobbies.length === 0 ? (
                <div className="py-4 text-xs text-secondary italic">
                  Belum ada entri hobi atau minat yang ditambahkan.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {hobbies.map((hobby, index) => (
                    <div
                      key={`${hobby.id || 'hobby'}-${index}`}
                      className="flex flex-col p-6 rounded-xl bg-surface-container-low/60 border border-outline-variant/30 hover:border-primary/40 transition-colors"
                    >
                      <div className="flex items-center justify-between mb-4">
                        <span className="font-mono text-xs text-outline">
                          0{index + 1}
                        </span>
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                          {getHobbyIcon(hobby.icon)}
                        </div>
                      </div>
                      <h3 className="font-editorial text-lg text-on-surface mb-2 font-medium">
                        {hobby.name}
                      </h3>
                      <p className="font-sans text-xs text-on-surface-variant leading-relaxed">
                        {hobby.description}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>

          {/* Hairline Divider */}
          <div className="w-full h-px bg-outline-variant/30 my-8"></div>

          {/* Section 4: Prestasi & Rekam Jejak (Vertical Timeline) */}
          <section className="py-8 md:py-14" id="prestasi">
            <div className="flex flex-col gap-6">
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
                <div>
                  <span className="font-sans text-xs text-primary uppercase tracking-widest font-semibold">
                    Rekam Jejak
                  </span>
                  <h2 className="font-editorial text-3xl md:text-4xl text-on-surface tracking-tight">
                    Prestasi &amp; Pencapaian
                  </h2>
                  <p className="font-sans text-sm text-on-surface-variant max-w-xl mt-1">
                    Milestone perjalanan karier profesional dan kontribusi di bidang desain serta inovasi digital.
                  </p>
                </div>

                {/* Filter Pills */}
                {categories.length > 2 && (
                  <div className="flex flex-wrap gap-1.5 bg-surface-container-low p-1 rounded-lg">
                    {categories.map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-3 py-1 text-xs font-sans rounded-md transition-colors ${
                          selectedCategory === cat
                            ? 'bg-surface-container-lowest text-primary font-semibold shadow-xs'
                            : 'text-secondary hover:text-on-surface'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Vertical Timeline */}
              {filteredAchievements.length === 0 ? (
                <div className="p-8 text-center bg-surface-container-low/40 rounded-xl border border-outline-variant/30 text-secondary text-sm">
                  Belum ada entri prestasi yang dipublikasikan pada kategori ini.
                </div>
              ) : (
                <div className="relative pl-6 md:pl-8 border-l border-outline-variant/40 space-y-8 ml-2 mt-4">
                  {filteredAchievements.map((item, idx) => (
                    <div key={`${item.id || 'ach'}-${idx}`} className="relative group">
                      {/* Timeline Dot */}
                      <div className="absolute -left-[31px] md:-left-[39px] top-1.5 w-3.5 h-3.5 rounded-full bg-surface-container-lowest border-2 border-primary"></div>
                      <div className="flex flex-col">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-mono text-xs font-semibold text-primary">
                            {item.achievement_date ? item.achievement_date.substring(0, 4) : '2024'}
                          </span>
                          <span className="text-outline text-xs">•</span>
                          <span className="font-sans text-xs text-secondary font-medium">
                            {item.institution}
                          </span>
                        </div>
                        <h3 className="font-editorial text-xl text-on-surface tracking-tight mb-1.5 font-normal">
                          {item.title}
                        </h3>
                        <p className="font-sans text-sm text-on-surface-variant max-w-2xl leading-relaxed">
                          {item.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>

          {/* Hairline Divider */}
          <div className="w-full h-px bg-outline-variant/30 my-8"></div>

          {/* Section 5: Musik Favorit (Pemutar Audio Nyata) */}
          <section className="py-8 md:py-14" id="musik">
            <div className="flex flex-col gap-6">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                <div>
                  <span className="font-sans text-xs text-primary uppercase tracking-widest font-semibold">
                    Kurasi Audio
                  </span>
                  <h2 className="font-editorial text-3xl md:text-4xl text-on-surface tracking-tight">
                    Musik Favorit
                  </h2>
                  <p className="font-sans text-sm text-on-surface-variant max-w-xl mt-1">
                    Lagu kurasi dan suara ambient yang menemani ritme kerja, eksplorasi desain, dan perancangan strategi.
                  </p>
                </div>

                <Link
                  to="/music"
                  className="px-3.5 py-1.5 rounded-xl border border-outline-variant/60 hover:bg-surface-container text-xs font-semibold text-primary flex items-center gap-1.5 transition-colors self-start sm:self-auto shrink-0 shadow-2xs"
                >
                  <Headphones className="w-4 h-4" />
                  <span>Tampilan Pemutar Musik Penuh</span>
                </Link>
              </div>

              {/* Enhanced Editorial Music Player matching Gambar Pertama */}
              <EditorialMusicPlayer />
            </div>
          </section>

          {/* Hairline Divider */}
          <div className="w-full h-px bg-outline-variant/30 my-8"></div>

          {/* Section 6: Donasi / Dukung Saya (Opsional jika diaktifkan admin) */}
          {donation?.enabled && (
            <section className="py-8 md:py-14" id="donasi">
              <div className="p-8 md:p-12 rounded-2xl bg-surface-container-low/70 border border-outline-variant/40 flex flex-col items-center text-center">
                <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-4">
                  <Heart className="w-6 h-6" />
                </div>
                <span className="font-sans text-xs text-primary uppercase tracking-widest font-semibold mb-1">
                  Apresiasi Karya
                </span>
                <h2 className="font-editorial text-3xl md:text-4xl text-on-surface tracking-tight mb-2">
                  {donation.title || 'Dukung Saya'}
                </h2>
                <p className="font-sans text-sm text-on-surface-variant max-w-lg leading-relaxed mb-6">
                  {donation.description ||
                    'Jika kamu menikmati karya, tulisan, atau proyek ini, kamu dapat memberikan apresiasi langsung secara digital.'}
                </p>

                {/* Preset Tip Pills */}
                <div className="flex flex-wrap items-center justify-center gap-2 mb-6">
                  <button
                    onClick={() => setShowDonationDrawer(true)}
                    className="border border-outline-variant/50 bg-surface px-4 py-1.5 rounded-full text-xs font-sans text-on-surface hover:border-primary transition-colors"
                  >
                    Rp 15.000 (Secangkir Kopi)
                  </button>
                  <button
                    onClick={() => setShowDonationDrawer(true)}
                    className="border border-outline-variant/50 bg-surface px-4 py-1.5 rounded-full text-xs font-sans text-on-surface hover:border-primary transition-colors"
                  >
                    Rp 50.000 (Buku Bacaan)
                  </button>
                  <button
                    onClick={() => setShowDonationDrawer(true)}
                    className="border border-outline-variant/50 bg-surface px-4 py-1.5 rounded-full text-xs font-sans text-on-surface hover:border-primary transition-colors"
                  >
                    Nominal Bebas
                  </button>
                </div>

                {/* Primary Action Button */}
                <button
                  onClick={() => setShowDonationDrawer((prev) => !prev)}
                  className="bg-primary text-on-primary font-sans font-semibold text-xs md:text-sm px-7 py-3 rounded-xl hover:bg-primary-container transition shadow-sm inline-flex items-center gap-2"
                >
                  <Coffee className="w-4 h-4" />
                  <span>{showDonationDrawer ? 'Tutup Saluran Donasi' : 'Kirim Donasi'}</span>
                </button>

                {/* Expandable QRIS / Info Box */}
                {showDonationDrawer && (
                  <div className="mt-8 w-full max-w-sm p-6 bg-surface-container-lowest border border-outline-variant/40 rounded-xl transition-all shadow-sm">
                    <div className="flex items-center justify-between pb-2 border-b border-outline-variant/20 mb-4">
                      <span className="font-sans text-xs uppercase tracking-wider text-secondary font-semibold">
                        QRIS &amp; Transfer Donasi
                      </span>
                    </div>

                    <div className="flex flex-col items-center py-2">
                      {/* Clean QR Representation */}
                      <div className="w-52 h-52 bg-white rounded-xl p-2.5 flex flex-col items-center justify-center border border-outline-variant/30 mb-3 text-center shadow-xs overflow-hidden">
                        <img
                          src={donation.qris_image_path || '/assets/qris_syahrul_official.png'}
                          alt="QRIS Donasi Resmi Syahrul Gunawan"
                          className="w-full h-full object-contain"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = '/assets/qris_syahrul_official.png';
                          }}
                        />
                      </div>

                      <p className="font-sans text-xs text-secondary text-center leading-normal mb-4">
                        Pindai kode QRIS di atas melalui GoPay, OVO, BCA, Dana, atau aplikasi perbankan digital.
                      </p>

                      <div className="w-full bg-surface-container-low p-2.5 rounded-lg flex items-center justify-between gap-2">
                        <span className="font-mono text-xs text-on-surface truncate">
                          {donation.donation_url || 'https://saweria.co/syahrulgunawan'}
                        </span>
                        <button
                          onClick={() =>
                            handleCopyDonationUrl(
                              donation.donation_url || 'https://saweria.co/syahrulgunawan'
                            )
                          }
                          className="text-xs text-primary font-semibold hover:underline flex items-center gap-1 shrink-0"
                        >
                          {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedLink ? 'Tersalin' : 'Salin'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </section>
          )}

          {/* Hairline Divider */}
          <div className="w-full h-px bg-outline-variant/30 my-8"></div>

          {/* Section 7: Temukan Saya / Media Sosial */}
          <section className="py-8 md:py-14" id="kontak">
            <div className="flex flex-col gap-6">
              <div className="flex flex-col gap-1">
                <span className="font-sans text-xs text-primary uppercase tracking-widest font-semibold">
                  Koneksi &amp; Jejaring
                </span>
                <h2 className="font-editorial text-3xl md:text-4xl text-on-surface tracking-tight">
                  Temukan Saya
                </h2>
                <p className="font-sans text-sm text-on-surface-variant max-w-md">
                  Terhubung lebih dekat untuk berdiskusi seputar desain, strategi produk, atau sekadar bertukar sapa.
                </p>
              </div>

              {/* Social Cards Grid */}
              {links.length === 0 ? (
                <div className="p-8 text-center bg-surface-container-low/40 rounded-xl border border-outline-variant/30 text-secondary text-xs">
                  Belum ada tautan media sosial yang dipublikasikan.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {links.map((link, idx) => (
                    <a
                      key={`${link.id || 'link'}-${idx}`}
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-between p-5 rounded-xl border border-outline-variant/40 bg-surface-container-lowest hover:border-primary/50 transition-all duration-150 group shadow-xs"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-11 h-11 rounded-xl bg-surface-container flex items-center justify-center text-on-surface group-hover:text-primary transition-colors">
                          <Share2 className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-editorial text-base text-on-surface font-medium group-hover:text-primary transition-colors">
                            {link.label}
                          </p>
                          <p className="font-sans text-xs text-secondary truncate max-w-[200px]">
                            {link.url}
                          </p>
                        </div>
                      </div>
                      <ArrowUpRight className="w-4 h-4 text-outline group-hover:text-primary transition-colors" />
                    </a>
                  ))}
                </div>
              )}
            </div>
          </section>
        </div>
      </main>

      {/* Editorial Footer */}
      <footer className="w-full py-8 border-t border-outline-variant/30 bg-surface-container-lowest">
        <div className="max-w-4xl mx-auto px-4 md:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-secondary text-xs font-sans">
          <div className="flex items-center gap-2">
            <span>© {new Date().getFullYear()} {profile?.display_name || 'Syahrul Gunawan'}</span>
            <span>•</span>
            <span className="tracking-wide">Quiet Editorial Portfolio &amp; CMS</span>
          </div>

          <div className="flex items-center gap-4 text-outline">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-primary" />
              <span>TLS 1.3 Terenkripsi</span>
            </span>
            <Link to={isAdmin ? '/admin' : '/login'} className="hover:text-primary transition-colors">
              Masuk Pengelola
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
};
