import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import {
  ArrowLeft,
  Mail,
  Lock,
  Eye,
  EyeOff,
  Shield,
  ArrowUpRight,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

export const AdminLogin: React.FC = () => {
  const { login, resetPassword, adminInfo } = useAuth();
  const navigate = useNavigate();

  const [identifier, setIdentifier] = useState<string>(adminInfo?.email || 'ayungnew768@gmail.com');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [rememberMe, setRememberMe] = useState<boolean>(true);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [showForgotModal, setShowForgotModal] = useState<boolean>(false);
  const [forgotEmail, setForgotEmail] = useState<string>(adminInfo?.email || 'ayungnew768@gmail.com');
  const [resetSuccess, setResetSuccess] = useState<boolean>(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setIsSubmitting(true);

    try {
      const res = await login(identifier, password);
      if (res.success) {
        navigate('/admin');
      } else {
        setErrorMsg(res.error || 'Autentikasi gagal. Silakan periksa kembali email dan kata sandi.');
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'Terjadi kesalahan sistem saat mencoba masuk.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail) return;
    const res = await resetPassword(forgotEmail);
    if (res.success) {
      setResetSuccess(true);
    } else {
      setErrorMsg(res.error || 'Gagal mengirim instruksi pemulihan kata sandi.');
    }
  };

  return (
    <div className="min-h-screen bg-surface font-sans text-on-surface flex flex-col justify-between selection:bg-secondary-container selection:text-on-secondary-container">
      {/* Editorial Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-surface/80 backdrop-blur-xl border-b border-outline-variant/30">
        <div className="h-16 max-w-6xl mx-auto px-4 md:px-8 flex items-center justify-between">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-on-surface-variant hover:text-primary transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Kembali ke Beranda / Syahrul Gunawan</span>
          </Link>
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono text-secondary uppercase tracking-widest hidden sm:inline-block">
              Studio Access v2.4
            </span>
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-on-primary">
              <Shield className="w-4 h-4" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Login Card Section */}
      <main className="w-full pt-16 flex-1 flex flex-col justify-center items-center py-12 px-4">
        {/* Soft Radial Ambient Glow */}
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center overflow-hidden">
          <div className="w-[500px] h-[500px] rounded-full bg-secondary-container/20 blur-3xl -translate-y-12"></div>
        </div>

        <div className="relative z-10 w-full max-w-md mx-auto flex flex-col items-center">
          <div className="w-full bg-surface-container-lowest rounded-2xl shadow-sm border border-outline-variant/40 p-8 sm:p-10 transition-all">
            {/* Top Badge */}
            <div className="flex items-center justify-between mb-6">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-secondary-container/60 rounded-full">
                <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></span>
                <span className="text-[11px] font-sans text-primary uppercase tracking-widest font-semibold">
                  PANEL KELOLA • KHUSUS PENGELOLA
                </span>
              </div>
              <span className="text-[11px] font-mono text-outline tracking-wider uppercase">
                PORTAL 01
              </span>
            </div>

            {/* Title & Subtitle */}
            <div className="mb-8">
              <h1 className="font-editorial text-3xl sm:text-4xl text-on-surface tracking-tight font-normal mb-2">
                Masuk Admin
              </h1>
              <p className="font-sans text-sm text-on-surface-variant leading-relaxed">
                Akses pengelolaan konten, artikel, kurasi musik, catatan privat, dan brankas rahasia Syahrul Gunawan.
              </p>
            </div>

            {/* Error Feedback Banner */}
            {errorMsg && (
              <div className="mb-6 p-3.5 bg-error-container/50 border border-error/30 rounded-xl flex items-start gap-2.5 text-error text-xs">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <p className="leading-relaxed">{errorMsg}</p>
              </div>
            )}

            {/* Login Form */}
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-1.5">
                <label className="block text-xs font-sans text-on-surface-variant uppercase tracking-wider font-semibold">
                  Email atau Username
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="nama@domain.com atau username"
                    required
                    className="w-full px-4 py-2.5 bg-surface-container-low text-on-surface text-sm rounded-lg placeholder:text-outline/70 border border-outline-variant/40 focus:outline-none focus:bg-surface-container-lowest focus:border-primary transition-all"
                  />
                  <Mail className="w-4 h-4 absolute right-3.5 top-3 text-outline pointer-events-none" />
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-sans text-on-surface-variant uppercase tracking-wider font-semibold">
                    Kata Sandi
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowForgotModal(true)}
                    className="text-xs text-primary hover:underline transition-colors tracking-wide"
                  >
                    Lupa sandi?
                  </button>
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    required
                    className="w-full px-4 py-2.5 bg-surface-container-low text-on-surface text-sm rounded-lg placeholder:text-outline/70 border border-outline-variant/40 focus:outline-none focus:bg-surface-container-lowest focus:border-primary transition-all pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-outline hover:text-on-surface p-0.5"
                    aria-label="Tampilkan atau sembunyikan kata sandi"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <label className="flex items-center gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 rounded text-primary focus:ring-primary accent-primary cursor-pointer"
                  />
                  <span className="text-xs text-on-surface-variant">
                    Ingat sesi di perangkat ini
                  </span>
                </label>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full h-11 bg-primary text-on-primary rounded-lg text-xs uppercase tracking-wider font-semibold flex items-center justify-center gap-2 hover:bg-primary-container active:scale-[0.99] transition-all shadow-sm disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {isSubmitting ? (
                  <>
                    <span className="w-4 h-4 border-2 border-on-primary border-t-transparent rounded-full animate-spin"></span>
                    <span>Mengautentikasi...</span>
                  </>
                ) : (
                  <>
                    <span>Masuk ke Panel Pengelola</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            {/* Security Notice */}
            <div className="mt-5 p-3.5 bg-surface-container-low rounded-lg flex items-start gap-2.5">
              <Shield className="w-4 h-4 text-outline mt-0.5 shrink-0" />
              <p className="text-xs text-on-surface-variant leading-relaxed">
                Akses terbatas dan tercatat. Pastikan Anda memiliki otorisasi keamanan sebelum melanjutkan ke sistem manajemen.
              </p>
            </div>
          </div>

          <div className="mt-6 text-center">
            <Link
              to="/"
              className="inline-flex items-center gap-1.5 text-xs text-secondary hover:text-primary transition-colors uppercase tracking-widest font-semibold"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Kembali ke situs utama Syahrul Gunawan</span>
            </Link>
          </div>
        </div>
      </main>

      {/* Forgot Password Modal */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 bg-on-surface/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-surface-container-lowest max-w-sm w-full rounded-2xl p-6 shadow-xl border border-outline-variant/40">
            <h3 className="font-editorial text-2xl text-on-surface mb-2">Pemulihan Kata Sandi</h3>
            <p className="text-xs text-secondary mb-4 leading-relaxed">
              Masukkan email admin untuk menerima tautan reset Firebase. Catatan: aplikasi juga memakai Supabase Auth, jadi kata sandi Supabase perlu disamakan sebelum login kembali.
            </p>

            {resetSuccess ? (
              <div className="p-4 bg-primary/10 border border-primary/30 rounded-xl text-primary text-xs flex flex-col gap-2">
                <div className="flex items-center gap-1.5 font-semibold">
                  <CheckCircle className="w-4 h-4" />
                  <span>Tautan Terkirim!</span>
                </div>
                <p>
                  Periksa email <strong>{forgotEmail}</strong> dan ikuti tautan Firebase. Setelah reset Firebase, samakan kata sandi di Supabase Auth agar login admin tetap berhasil.
                </p>
                <button
                  onClick={() => {
                    setShowForgotModal(false);
                    setResetSuccess(false);
                  }}
                  className="mt-2 w-full py-2 bg-primary text-on-primary rounded-lg font-semibold"
                >
                  Tutup
                </button>
              </div>
            ) : (
              <form onSubmit={handleForgotPassword} className="space-y-4">
                <input
                  type="email"
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  placeholder="ayungnew768@gmail.com"
                  required
                  className="w-full px-3.5 py-2.5 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                />
                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowForgotModal(false)}
                    className="px-4 py-2 text-xs text-secondary hover:text-on-surface"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs bg-primary text-on-primary rounded-lg font-semibold hover:bg-primary-container"
                  >
                    Kirim Instruksi
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="w-full py-6">
        <div className="max-w-6xl mx-auto px-4 md:px-8 flex flex-col sm:flex-row items-center justify-between gap-2 text-secondary text-xs">
          <span className="uppercase tracking-widest font-mono">
            © Syahrul Gunawan Studio — Private Curatorial Archive
          </span>
          <span className="text-outline">Sistem Terotentikasi • TLS 1.3</span>
        </div>
      </footer>
    </div>
  );
};
