import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import { dataService } from '../../services/dataService';
import {
  ShieldCheck,
  KeyRound,
  Eye,
  EyeOff,
  Laptop,
  Smartphone,
  Save,
  Check,
  AlertCircle,
  AlertTriangle,
  LogOut,
  User,
  ShieldAlert,
  Lock,
  ExternalLink
} from 'lucide-react';
import { ActiveSession } from '../../types';

export const SecurityPage: React.FC = () => {
  const { adminInfo, logout, resetPassword } = useAuth();
  const navigate = useNavigate();

  const [currentPassword, setCurrentPassword] = useState<string>('');
  const [newPassword, setNewPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);

  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [isUpdating, setIsUpdating] = useState<boolean>(false);

  // Vault Master Passphrase State
  const [oldVaultPassphrase, setOldVaultPassphrase] = useState<string>('');
  const [newVaultPassphrase, setNewVaultPassphrase] = useState<string>('');
  const [confirmVaultPassphrase, setConfirmVaultPassphrase] = useState<string>('');
  const [showOldVaultPw, setShowOldVaultPw] = useState<boolean>(false);
  const [showNewVaultPw, setShowNewVaultPw] = useState<boolean>(false);
  const [isUpdatingVault, setIsUpdatingVault] = useState<boolean>(false);
  const [vaultSuccessMsg, setVaultSuccessMsg] = useState<string>('');
  const [vaultErrorMsg, setVaultErrorMsg] = useState<string>('');
  const [vaultItemsCount, setVaultItemsCount] = useState<number>(0);

  useEffect(() => {
    dataService
      .getVaultItems()
      .then((items) => setVaultItemsCount(items.length))
      .catch(() => {});
  }, []);

  // Active Sessions
  const [sessions, setSessions] = useState<ActiveSession[]>([
    {
      id: 'sess-1',
      device_name: 'MacBook Pro 16"',
      browser: 'Chrome / Safari Desktop',
      location: 'Jakarta, Indonesia',
      ip_address: '182.253.112.44',
      last_active: 'Sesi Ini Aktif',
      is_current: true
    },
    {
      id: 'sess-2',
      device_name: 'iPhone 15 Pro',
      browser: 'Safari Mobile',
      location: 'Jakarta, Indonesia',
      ip_address: '114.124.201.8',
      last_active: 'Aktif 2 jam yang lalu',
      is_current: false
    }
  ]);

  // Password strength calculation
  const calculateStrength = (pw: string): { label: string; level: number } => {
    if (!pw) return { label: 'Kosong', level: 0 };
    let score = 0;
    if (pw.length >= 8) score++;
    if (pw.length >= 12) score++;
    if (/[A-Z]/.test(pw)) score++;
    if (/[0-9]/.test(pw)) score++;
    if (/[^A-Za-z0-9]/.test(pw)) score++;

    if (score <= 2) return { label: 'Lemah', level: 1 };
    if (score <= 3) return { label: 'Sedang', level: 2 };
    if (score <= 4) return { label: 'Kuat', level: 3 };
    return { label: 'Sangat Kuat (14+ karakter, simbol & angka)', level: 4 };
  };

  const strength = calculateStrength(newPassword);

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSaveSuccess(false);

    if (newPassword.length < 8) {
      setErrorMsg('Kata sandi baru minimal harus 8 karakter.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setErrorMsg('Konfirmasi kata sandi tidak cocok dengan kata sandi baru.');
      return;
    }

    setIsUpdating(true);
    try {
      // This app authenticates against both Firebase and Supabase. A reset email
      // changes neither password until the user follows its link, and changing
      // Firebase alone would leave the Supabase password out of sync. Do not
      // pretend the password has already changed.
      const result = await resetPassword(adminInfo.email);
      if (!result.success) {
        setErrorMsg(result.error || 'Gagal mengirim instruksi pemulihan kata sandi.');
        return;
      }
      setSaveSuccess(true);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => setSaveSuccess(false), 8000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Gagal memperbarui kata sandi.');
    } finally {
      setIsUpdating(false);
    }
  };

  const vaultStrength = calculateStrength(newVaultPassphrase);

  const handleVaultPassphraseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setVaultErrorMsg('');
    setVaultSuccessMsg('');

    if (!oldVaultPassphrase.trim()) {
      setVaultErrorMsg('Kata sandi master brankas saat ini (lama) wajib diisi.');
      return;
    }

    if (newVaultPassphrase.length < 6) {
      setVaultErrorMsg('Kata sandi master brankas baru minimal harus 6 karakter.');
      return;
    }

    if (newVaultPassphrase !== confirmVaultPassphrase) {
      setVaultErrorMsg('Konfirmasi kata sandi brankas baru tidak cocok.');
      return;
    }

    if (oldVaultPassphrase === newVaultPassphrase) {
      setVaultErrorMsg('Kata sandi brankas baru tidak boleh sama dengan kata sandi saat ini.');
      return;
    }

    setIsUpdatingVault(true);
    try {
      const res = await dataService.changeVaultMasterPassphrase(
        oldVaultPassphrase,
        newVaultPassphrase
      );
      setVaultSuccessMsg(res.message);
      setOldVaultPassphrase('');
      setNewVaultPassphrase('');
      setConfirmVaultPassphrase('');
      const updated = await dataService.getVaultItems();
      setVaultItemsCount(updated.length);
      setTimeout(() => setVaultSuccessMsg(''), 10000);
    } catch (err: any) {
      setVaultErrorMsg(err?.message || 'Gagal mengubah kata sandi master brankas.');
    } finally {
      setIsUpdatingVault(false);
    }
  };

  const [sessionNotice, setSessionNotice] = useState<string>('');

  const handleDisconnectSession = (id: string) => {
    setSessions((prev) => prev.filter((s) => s.id !== id));
    setSessionNotice('Daftar sesi pada antarmuka ini bersifat pratinjau lokal dan tidak memutus token autentikasi server. Untuk memutus sesi nyata, silakan gunakan tombol Keluar pada perangkat tersebut atau kelola melalui konsol Firebase / Supabase.');
  };

  const handleDisconnectAllOthers = () => {
    setSessions((prev) => prev.filter((s) => s.is_current));
    setSessionNotice('Daftar sesi telah disaring ke sesi saat ini. Sesi autentikasi server sebenarnya dikelola langsung melalui provider autentikasi.');
  };

  const handleLogoutCurrent = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="pb-2 border-b border-outline-variant/30">
        <h1 className="font-editorial text-3xl text-on-surface">
          Keamanan &amp; Akun Administrator
        </h1>
        <p className="text-xs text-secondary mt-1">
          Kelola akun administrator. Reset dari sini mengirim instruksi Firebase; perubahan kata sandi Supabase tetap perlu disamakan agar login dua layanan tetap berfungsi.
        </p>
      </div>

      {sessionNotice && (
        <div className="p-3.5 bg-secondary-container/40 border border-secondary/30 text-secondary text-xs rounded-xl flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 shrink-0 text-primary" />
            <span>{sessionNotice}</span>
          </div>
          <button onClick={() => setSessionNotice('')} className="text-secondary hover:text-on-surface font-semibold text-xs ml-2 cursor-pointer">
            Tutup
          </button>
        </div>
      )}

      {errorMsg && (
        <div className="p-3.5 bg-error-container/60 border border-error/30 text-error text-xs rounded-xl flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {saveSuccess && (
        <div className="p-3.5 bg-primary/10 border border-primary/30 text-primary text-xs rounded-xl flex items-center gap-2">
          <Check className="w-4 h-4 shrink-0" />
          <span>Instruksi reset Firebase telah dikirim. Kata sandi belum berubah. Karena login juga memakai Supabase, samakan kata sandi Supabase sebelum login kembali.</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Account Info & Password Update (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Section 01: Identitas Akun */}
          <section className="bg-surface-container-lowest rounded-2xl p-6 border border-outline-variant/30 shadow-xs">
            <div className="flex items-center gap-2 pb-3 mb-4 border-b border-outline-variant/20">
              <span className="text-[10px] font-mono uppercase tracking-widest text-secondary font-semibold">
                Bagian 01
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
              <h2 className="font-editorial text-xl text-on-surface font-semibold">
                Akun Pengelola Resmi
              </h2>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-lg bg-surface-container-low text-xs">
                <span className="text-secondary font-medium">Nama Pemilik</span>
                <span className="font-semibold text-on-surface">{adminInfo.name}</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-surface-container-low text-xs">
                <span className="text-secondary font-medium">Email Terdaftar</span>
                <span className="font-mono text-on-surface">{adminInfo.email}</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-surface-container-low text-xs">
                <span className="text-secondary font-medium">Peran / Otoritas</span>
                <span className="font-semibold text-primary">{adminInfo.role}</span>
              </div>
            </div>
          </section>

          {/* Section 02: Perbarui Kata Sandi */}
          <section className="bg-surface-container-lowest rounded-2xl p-6 border border-outline-variant/30 shadow-xs">
            <div className="flex items-center gap-2 pb-3 mb-4 border-b border-outline-variant/20">
              <span className="text-[10px] font-mono uppercase tracking-widest text-secondary font-semibold">
                Bagian 02
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
              <h2 className="font-editorial text-xl text-on-surface font-semibold">
                Perbarui Kata Sandi
              </h2>
            </div>

            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-secondary uppercase tracking-wider mb-1">
                  Kata Sandi Saat Ini
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    placeholder="Ketik kata sandi saat ini"
                    className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-secondary hover:text-on-surface"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-secondary uppercase tracking-wider mb-1">
                  Kata Sandi Baru
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Ketik kata sandi baru (minimal 8 karakter)"
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                />

                {/* Password Strength Indicator */}
                {newPassword && (
                  <div className="mt-2 space-y-1.5">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-secondary">Kekuatan Sandi:</span>
                      <span className="font-semibold text-primary">{strength.label}</span>
                    </div>
                    <div className="grid grid-cols-4 gap-1.5 h-1.5 w-full">
                      {[1, 2, 3, 4].map((bar) => (
                        <div
                          key={bar}
                          className={`rounded-full transition-colors ${
                            strength.level >= bar ? 'bg-primary' : 'bg-surface-container-high'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-secondary uppercase tracking-wider mb-1">
                  Konfirmasi Kata Sandi Baru
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Ulangi kata sandi baru"
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                />
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={isUpdating}
                  className="px-5 py-2 bg-primary text-on-primary hover:bg-primary-container rounded-lg text-xs font-semibold flex items-center gap-2 shadow-xs transition-colors disabled:opacity-50"
                >
                  {isUpdating ? (
                    <span className="w-4 h-4 border-2 border-on-primary border-t-transparent rounded-full animate-spin"></span>
                  ) : (
                    <Save className="w-4 h-4" />
                  )}
                  <span>Perbarui Kata Sandi</span>
                </button>
              </div>
            </form>
          </section>

          {/* Section 03: Ubah Kata Sandi Brankas Rahasia (AES-256) */}
          <section
            id="brankas"
            className="bg-surface-container-lowest rounded-2xl p-6 border border-outline-variant/30 shadow-xs scroll-mt-20"
          >
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-outline-variant/20">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono uppercase tracking-widest text-primary font-bold">
                  Bagian 03
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
                <h2 className="font-editorial text-xl text-on-surface font-semibold flex items-center gap-2">
                  <Lock className="w-4 h-4 text-primary" />
                  <span>Kata Sandi Master Brankas Rahasia</span>
                </h2>
              </div>
              <Link
                to="/admin/vault"
                className="text-xs font-semibold text-primary hover:underline flex items-center gap-1"
                title="Buka Halaman Brankas"
              >
                <span>Buka Brankas</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </Link>
            </div>

            <p className="text-xs text-secondary leading-relaxed mb-4">
              Brankas rahasia Syahrul Gunawan dilindungi dengan enkripsi sisi-klien tingkat militer (
              <strong>AES-GCM 256-bit + PBKDF2 100.000 iterasi</strong>). Mengubah kata sandi di sini akan
              otomatis mendekripsi dan mengenkripsi ulang{' '}
              <strong className="text-on-surface">{vaultItemsCount} item kredensial</strong> yang tersimpan dengan kunci baru.
            </p>

            {vaultSuccessMsg && (
              <div className="p-3.5 mb-4 bg-primary/10 border border-primary/30 text-primary text-xs rounded-xl flex items-center gap-2">
                <Check className="w-4 h-4 shrink-0" />
                <span>{vaultSuccessMsg}</span>
              </div>
            )}

            {vaultErrorMsg && (
              <div className="p-3.5 mb-4 bg-error-container/60 border border-error/30 text-error text-xs rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{vaultErrorMsg}</span>
              </div>
            )}

            <form onSubmit={handleVaultPassphraseSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-secondary uppercase tracking-wider mb-1">
                  Kata Sandi Master Brankas Saat Ini (Lama) *
                </label>
                <div className="relative">
                  <input
                    type={showOldVaultPw ? 'text' : 'password'}
                    required
                    value={oldVaultPassphrase}
                    onChange={(e) => setOldVaultPassphrase(e.target.value)}
                    placeholder="Ketik kata sandi brankas lama untuk verifikasi"
                    className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary pr-10 font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowOldVaultPw(!showOldVaultPw)}
                    className="absolute right-3 top-2.5 text-secondary hover:text-on-surface"
                  >
                    {showOldVaultPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-secondary uppercase tracking-wider mb-1">
                  Kata Sandi Master Brankas Baru *
                </label>
                <div className="relative">
                  <input
                    type={showNewVaultPw ? 'text' : 'password'}
                    required
                    value={newVaultPassphrase}
                    onChange={(e) => setNewVaultPassphrase(e.target.value)}
                    placeholder="Ketik kata sandi master baru (minimal 6 karakter)"
                    className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary pr-10 font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewVaultPw(!showNewVaultPw)}
                    className="absolute right-3 top-2.5 text-secondary hover:text-on-surface"
                  >
                    {showNewVaultPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                {newVaultPassphrase && (
                  <div className="mt-2 space-y-1">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-secondary font-medium">Kekuatan Kunci Brankas:</span>
                      <span
                        className={`font-semibold ${
                          vaultStrength.level <= 1
                            ? 'text-error'
                            : vaultStrength.level === 2
                            ? 'text-amber-700'
                            : 'text-primary'
                        }`}
                      >
                        {vaultStrength.label}
                      </span>
                    </div>
                    <div className="w-full bg-surface-container-high h-1.5 rounded-full overflow-hidden flex gap-1">
                      {[1, 2, 3, 4].map((step) => (
                        <div
                          key={step}
                          className={`h-full flex-1 transition-all rounded-full ${
                            step <= vaultStrength.level
                              ? vaultStrength.level <= 1
                                ? 'bg-error'
                                : vaultStrength.level === 2
                                ? 'bg-amber-600'
                                : 'bg-primary'
                              : 'bg-outline-variant/30'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-secondary uppercase tracking-wider mb-1">
                  Konfirmasi Kata Sandi Master Brankas Baru *
                </label>
                <input
                  type={showNewVaultPw ? 'text' : 'password'}
                  required
                  value={confirmVaultPassphrase}
                  onChange={(e) => setConfirmVaultPassphrase(e.target.value)}
                  placeholder="Ketik ulang kata sandi master baru"
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary font-mono"
                />
              </div>

              <div className="p-3 bg-surface-container-low rounded-xl flex items-center justify-between text-xs text-secondary">
                <span>Total Item Rahasia Terdaftar:</span>
                <span className="font-mono font-bold text-on-surface">{vaultItemsCount} Item</span>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <span className="text-[11px] text-secondary">
                  * Kunci enkripsi diperbarui secara lokal sebelum disimpan ke database.
                </span>
                <button
                  type="submit"
                  disabled={isUpdatingVault}
                  className="px-5 py-2 bg-primary text-on-primary hover:bg-primary-container rounded-lg text-xs font-semibold flex items-center justify-center gap-2 shadow-xs transition-colors disabled:opacity-50 cursor-pointer shrink-0"
                >
                  {isUpdatingVault ? (
                    <>
                      <span className="w-4 h-4 border-2 border-on-primary border-t-transparent rounded-full animate-spin"></span>
                      <span>Mengenkrpsi Ulang...</span>
                    </>
                  ) : (
                    <>
                      <KeyRound className="w-4 h-4" />
                      <span>Simpan Sandi Brankas Baru</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </section>
        </div>

        {/* Right Column: Sessions & Critical Action Zone (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Section 04: Sesi & Perangkat Aktif */}
          <section className="bg-surface-container-lowest rounded-2xl p-6 border border-outline-variant/30 shadow-xs">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-outline-variant/20">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono uppercase tracking-widest text-secondary font-semibold">
                  Bagian 04
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
                <h2 className="font-editorial text-xl text-on-surface font-semibold">
                  Sesi &amp; Perangkat
                </h2>
              </div>
              <span className="text-xs text-secondary font-mono">{sessions.length} Perangkat</span>
            </div>

            <div className="space-y-3">
              {sessions.map((s, idx) => (
                <div
                  key={`${s.id || 'sess'}-${idx}`}
                  className={`p-3.5 rounded-xl border flex items-start justify-between gap-3 ${
                    s.is_current
                      ? 'bg-surface-container-low border-primary/30'
                      : 'bg-surface-container-lowest border-outline-variant/30'
                  }`}
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-lg bg-surface-container flex items-center justify-center text-primary shrink-0 mt-0.5">
                      {s.device_name.includes('Mac') || s.device_name.includes('Desktop') ? (
                        <Laptop className="w-4 h-4" />
                      ) : (
                        <Smartphone className="w-4 h-4" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-semibold text-on-surface">{s.device_name}</span>
                        {s.is_current && (
                          <span className="bg-primary-fixed text-on-primary-fixed-variant px-1.5 py-0.2 rounded-full text-[9px] font-bold">
                            Sesi Ini
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-secondary truncate mt-0.5">{s.browser}</p>
                      <p className="text-[10px] font-mono text-outline mt-0.5">
                        IP: {s.ip_address} • {s.last_active}
                      </p>
                    </div>
                  </div>

                  {!s.is_current && (
                    <button
                      onClick={() => handleDisconnectSession(s.id)}
                      className="text-xs text-error hover:bg-error-container px-2 py-1 rounded transition-colors whitespace-nowrap shrink-0"
                    >
                      Putuskan
                    </button>
                  )}
                </div>
              ))}
            </div>
          </section>

          {/* Section 04: Zona Tindakan Kritis */}
          <section className="bg-surface-container-lowest rounded-2xl p-6 border border-outline-variant/30 shadow-xs">
            <div className="flex items-center gap-2 pb-3 mb-4 border-b border-outline-variant/20 text-error">
              <ShieldAlert className="w-4 h-4" />
              <h2 className="font-editorial text-xl font-semibold">
                Zona Tindakan Kritis
              </h2>
            </div>

            <p className="text-xs text-on-surface-variant leading-relaxed mb-4">
              Tindakan di bawah ini akan secara instan membatalkan token otentikasi peramban dan menutup gerbang pengelolaan data editorial situs.
            </p>

            <div className="space-y-2">
              <button
                onClick={handleDisconnectAllOthers}
                className="w-full flex items-center justify-between px-3.5 py-2.5 bg-surface-container-low hover:bg-surface-container text-on-surface rounded-lg text-xs font-semibold transition-colors text-left"
              >
                <span>Keluar dari Semua Sesi Lainnya</span>
                <span className="text-[11px] text-secondary">Batalkan Sesi</span>
              </button>

              <button
                onClick={handleLogoutCurrent}
                className="w-full flex items-center justify-between px-3.5 py-2.5 bg-error-container/60 hover:bg-error-container text-error rounded-lg text-xs font-semibold transition-colors text-left"
              >
                <span>Keluar dari Perangkat Ini</span>
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
