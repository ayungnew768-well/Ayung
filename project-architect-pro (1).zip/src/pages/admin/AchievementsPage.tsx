import React, { useState, useEffect } from 'react';
import { dataService } from '../../services/dataService';
import { Achievement } from '../../types';
import {
  Trophy,
  Plus,
  Search,
  Filter,
  Edit2,
  Trash2,
  CheckCircle,
  Eye,
  EyeOff,
  Calendar,
  Building,
  Upload,
  ArrowUpDown,
  AlertCircle,
  FileText
} from 'lucide-react';

export const AchievementsPage: React.FC = () => {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('Semua');
  const [sortOrder, setSortOrder] = useState<'terbaru' | 'terlama'>('terbaru');

  // Modal State
  const [showFormModal, setShowFormModal] = useState<boolean>(false);
  const [editingItem, setEditingItem] = useState<Partial<Achievement> | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [uploadingImage, setUploadingImage] = useState<boolean>(false);
  const [formError, setFormError] = useState<string>('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const data = await dataService.getAchievements(false);
      setAchievements(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpenAdd = () => {
    setEditingItem({
      title: '',
      description: '',
      category: 'Penghargaan',
      institution: '',
      achievement_date: new Date().toISOString().split('T')[0],
      is_published: true,
      display_order: achievements.length + 1
    });
    setShowFormModal(true);
  };

  const handleOpenEdit = (item: Achievement) => {
    setEditingItem({ ...item });
    setShowFormModal(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem || !editingItem.title) return;

    setIsSubmitting(true);
    try {
      await dataService.saveAchievement(editingItem);
      await loadData();
      setShowFormModal(false);
      setEditingItem(null);
    } catch (err: any) {
      setFormError(err?.message || 'Gagal menyimpan prestasi.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteConfirmId) return;
    try {
      await dataService.deleteAchievement(deleteConfirmId);
      setAchievements((prev) => prev.filter((a) => a.id !== deleteConfirmId));
      setDeleteConfirmId(null);
    } catch (err: any) {
      console.error('Delete achievement error:', err);
      setDeleteConfirmId(null);
    }
  };

  const handleTogglePublish = async (item: Achievement) => {
    try {
      const updated = await dataService.saveAchievement({
        ...item,
        is_published: !item.is_published
      });
      setAchievements((prev) => prev.map((a) => (a.id === item.id ? updated : a)));
    } catch (e) {
      console.error(e);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !editingItem) return;

    setUploadingImage(true);
    setFormError('');
    try {
      const { url } = await dataService.uploadMedia(file, 'achievement-media');
      setEditingItem({
        ...editingItem,
        image_path: url
      });
    } catch (err: any) {
      setFormError(err.message || 'Gagal mengunggah gambar');
    } finally {
      setUploadingImage(false);
    }
  };

  // Filter & Search
  const categories = ['Semua', 'Penghargaan', 'Pembicara', 'Proyek', 'Karier'];

  const filtered = achievements
    .filter((item) => {
      const matchesSearch =
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.institution.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory =
        categoryFilter === 'Semua' || item.category === categoryFilter;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      const dateA = new Date(a.achievement_date || '1970-01-01').getTime();
      const dateB = new Date(b.achievement_date || '1970-01-01').getTime();
      return sortOrder === 'terbaru' ? dateB - dateA : dateA - dateB;
    });

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-outline-variant/30">
        <div>
          <h1 className="font-editorial text-3xl text-on-surface">
            Kelola Prestasi &amp; Rekam Jejak
          </h1>
          <p className="text-xs text-secondary mt-1">
            Tambah, sunting, arsipkan, dan publikasikan tonggak pencapaian profesional Syahrul Gunawan.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2 bg-primary text-on-primary hover:bg-primary-container rounded-lg text-xs font-semibold flex items-center gap-2 shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Tambah Prestasi</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-surface-container-lowest p-4 rounded-xl border border-outline-variant/30 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-secondary absolute left-3 top-2.5 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari judul, lembaga, kata kunci..."
            className="w-full pl-9 pr-4 py-2 bg-surface-container-low text-xs rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
          />
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto justify-end">
          <div className="flex items-center gap-1.5 bg-surface-container-low p-1 rounded-lg">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={`px-3 py-1 text-xs rounded-md transition-colors ${
                  categoryFilter === cat
                    ? 'bg-surface-container-lowest text-primary font-semibold shadow-xs'
                    : 'text-secondary hover:text-on-surface'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <button
            onClick={() => setSortOrder(sortOrder === 'terbaru' ? 'terlama' : 'terbaru')}
            className="px-3 py-1.5 bg-surface-container hover:bg-surface-container-high rounded-lg text-xs font-medium text-secondary flex items-center gap-1.5 transition-colors"
            title="Ubah Urutan Tanggal"
          >
            <ArrowUpDown className="w-3.5 h-3.5" />
            <span className="capitalize">{sortOrder}</span>
          </button>
        </div>
      </div>

      {/* Achievements List */}
      {isLoading ? (
        <div className="py-16 text-center text-secondary text-xs">Memuat daftar prestasi...</div>
      ) : filtered.length === 0 ? (
        <div className="py-16 text-center bg-surface-container-low/40 rounded-2xl border border-outline-variant/30 p-8">
          <Trophy className="w-10 h-10 text-outline mx-auto mb-2 opacity-50" />
          <p className="font-editorial text-lg text-on-surface">Tidak ada prestasi yang ditemukan</p>
          <p className="text-xs text-secondary mt-1">
            Gunakan tombol "Tambah Prestasi" di atas untuk menambahkan rekam jejak baru.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((item, idx) => (
            <div
              key={`${item.id}-${idx}`}
              className={`p-5 rounded-xl border transition-all bg-surface-container-lowest flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                item.is_published
                  ? 'border-outline-variant/30 hover:border-primary/40'
                  : 'border-dashed border-outline/40 opacity-70'
              }`}
            >
              <div className="flex items-start gap-4 min-w-0 flex-1">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary shrink-0 mt-0.5">
                  <Trophy className="w-5 h-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="font-mono text-xs font-semibold text-primary">
                      {item.achievement_date ? item.achievement_date.substring(0, 4) : '—'}
                    </span>
                    <span className="px-2 py-0.5 rounded-full bg-secondary-container text-on-secondary-container text-[10px] font-bold uppercase">
                      {item.category}
                    </span>
                    <span className="text-xs text-secondary font-medium">
                      • {item.institution}
                    </span>
                    {!item.is_published && (
                      <span className="px-2 py-0.5 rounded-full bg-error-container text-on-error-container text-[10px] font-bold">
                        Draf (Tidak Terbit)
                      </span>
                    )}
                  </div>
                  <h3 className="font-editorial text-lg text-on-surface font-medium truncate">
                    {item.title}
                  </h3>
                  <p className="text-xs text-on-surface-variant line-clamp-2 mt-0.5 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-1.5 self-end sm:self-center shrink-0">
                <button
                  onClick={() => handleTogglePublish(item)}
                  className={`p-1.5 rounded-lg transition-colors ${
                    item.is_published
                      ? 'text-primary hover:bg-primary/10'
                      : 'text-outline hover:bg-surface-container'
                  }`}
                  title={item.is_published ? 'Sembunyikan dari Publik' : 'Terbitkan ke Publik'}
                >
                  {item.is_published ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                </button>
                <button
                  onClick={() => handleOpenEdit(item)}
                  className="p-1.5 rounded-lg text-secondary hover:text-on-surface hover:bg-surface-container transition-colors"
                  title="Sunting"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setDeleteConfirmId(item.id)}
                  className="p-1.5 rounded-lg text-error hover:bg-error-container transition-colors"
                  title="Hapus"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Unified Add/Edit Form Modal */}
      {showFormModal && editingItem && (
        <div className="fixed inset-0 z-50 bg-on-surface/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-surface-container-lowest max-w-xl w-full rounded-2xl p-6 shadow-xl border border-outline-variant/40 max-h-[90vh] overflow-y-auto">
            <h3 className="font-editorial text-2xl text-on-surface font-semibold mb-4">
              {editingItem.id ? 'Sunting Entri Prestasi' : 'Tambah Prestasi Baru'}
            </h3>

            <form onSubmit={handleSave} className="space-y-4">
              {formError && (
                <div className="p-3 bg-error-container/60 border border-error/30 text-error text-xs rounded-xl flex items-center gap-2">
                  <span>{formError}</span>
                </div>
              )}
              <div>
                <label className="block text-xs font-semibold text-secondary mb-1">
                  Judul Pencapaian / Penghargaan *
                </label>
                <input
                  type="text"
                  required
                  value={editingItem.title || ''}
                  onChange={(e) => setEditingItem({ ...editingItem, title: e.target.value })}
                  placeholder="Misal: Best Digital Experience Award — Indonesia Design Biennale"
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-secondary mb-1">
                    Lembaga / Penyelenggara *
                  </label>
                  <input
                    type="text"
                    required
                    value={editingItem.institution || ''}
                    onChange={(e) => setEditingItem({ ...editingItem, institution: e.target.value })}
                    placeholder="Misal: Kemenparekraf RI"
                    className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-secondary mb-1">
                    Kategori
                  </label>
                  <select
                    value={editingItem.category || 'Penghargaan'}
                    onChange={(e) => setEditingItem({ ...editingItem, category: e.target.value })}
                    className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                  >
                    <option value="Penghargaan">Penghargaan</option>
                    <option value="Pembicara">Pembicara &amp; Mentor</option>
                    <option value="Proyek">Proyek Terpilih</option>
                    <option value="Karier">Karier &amp; Organisasi</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-secondary mb-1">
                    Tanggal / Tahun Capaian
                  </label>
                  <input
                    type="date"
                    value={editingItem.achievement_date || ''}
                    onChange={(e) =>
                      setEditingItem({ ...editingItem, achievement_date: e.target.value })
                    }
                    className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-secondary mb-1">
                    Status Publikasi
                  </label>
                  <label className="flex items-center gap-2 mt-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingItem.is_published ?? true}
                      onChange={(e) =>
                        setEditingItem({ ...editingItem, is_published: e.target.checked })
                      }
                      className="w-4 h-4 rounded text-primary focus:ring-primary accent-primary"
                    />
                    <span className="text-xs text-on-surface">Terbitkan langsung ke situs publik</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-secondary mb-1">
                  Deskripsi &amp; Konteks Pencapaian *
                </label>
                <textarea
                  rows={4}
                  required
                  value={editingItem.description || ''}
                  onChange={(e) =>
                    setEditingItem({ ...editingItem, description: e.target.value })
                  }
                  placeholder="Uraikan rincian capaian, dampak nyata, dan peran yang Anda jalankan..."
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary leading-relaxed"
                />
              </div>

              {/* Upload Certificate / Image */}
              <div>
                <label className="block text-xs font-semibold text-secondary mb-1">
                  Foto / Piagam Pendukung (Opsional)
                </label>
                <div className="flex items-center gap-3">
                  <label className="cursor-pointer px-3.5 py-2 bg-surface-container-high hover:bg-surface-container text-on-surface rounded-lg text-xs font-semibold inline-flex items-center gap-2 transition-colors">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{uploadingImage ? 'Mengunggah...' : 'Pilih Berkas'}</span>
                    <input
                      type="file"
                      accept="image/*,.pdf"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                  {editingItem.image_path && (
                    <span className="text-xs text-primary font-mono truncate max-w-xs">
                      {editingItem.image_path.substring(0, 30)}...
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-outline-variant/20">
                <button
                  type="button"
                  onClick={() => setShowFormModal(false)}
                  className="px-4 py-2 text-xs text-secondary hover:text-on-surface"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-primary text-on-primary rounded-lg text-xs font-semibold hover:bg-primary-container disabled:opacity-50"
                >
                  {isSubmitting ? 'Menyimpan...' : 'Simpan Entri'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 bg-on-surface/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-surface-container-lowest max-w-sm w-full rounded-2xl p-6 shadow-xl border border-outline-variant/40">
            <h3 className="font-editorial text-xl text-on-surface font-semibold mb-2">
              Konfirmasi Hapus Prestasi
            </h3>
            <p className="text-xs text-secondary leading-relaxed mb-4">
              Apakah Anda yakin ingin menghapus entri ini secara permanen dari database? Tindakan ini tidak dapat dibatalkan.
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 text-xs text-secondary hover:text-on-surface"
              >
                Batal
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-error text-on-error rounded-lg text-xs font-semibold hover:opacity-90"
              >
                Hapus Permanen
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
