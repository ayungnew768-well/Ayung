import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { dataService } from '../../services/dataService';
import { VaultItem } from '../../types';
import { encryptSecret, decryptSecret, generateStrongPassword } from '../../lib/crypto';
import {
  Lock,
  Unlock,
  KeyRound,
  Eye,
  EyeOff,
  Copy,
  Check,
  Plus,
  Trash2,
  Edit2,
  Search,
  ShieldCheck,
  Clock,
  Sparkles,
  AlertTriangle,
  RefreshCw,
  Globe,
  Share2,
  Smartphone,
  Gamepad2,
  ShieldAlert
} from 'lucide-react';

const INACTIVITY_TIMEOUT_SECONDS = 300; // 5 minutes

export const VaultPage: React.FC = () => {
  const [vaultItems, setVaultItems] = useState<VaultItem[]>([]);
  const [isUnlocked, setIsUnlocked] = useState<boolean>(false);
  const [masterPassphrase, setMasterPassphrase] = useState<string>('SyahrulMasterKey2026!');
  const [passphraseInput, setPassphraseInput] = useState<string>('SyahrulMasterKey2026!');
  const [passphraseError, setPassphraseError] = useState<string>('');

  // 5-minute inactivity countdown
  const [remainingSeconds, setRemainingSeconds] = useState<number>(INACTIVITY_TIMEOUT_SECONDS);
  const inactivityTimerRef = useRef<any>(null);
  const lastActivityRef = useRef<number>(Date.now());

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeCategory, setActiveCategory] = useState<string>('All');

  // Revealed items cache (id -> plain secret)
  const [revealedSecrets, setRevealedSecrets] = useState<{ [id: string]: string }>({});
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Add / Edit Modal
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editingItem, setEditingItem] = useState<{
    id?: string;
    title: string;
    category: string;
    identity_type: string;
    identity_value: string;
    credential_type: string;
    secret_value: string;
    notes: string;
  } | null>(null);

  // Password Generator Modal
  const [showGenModal, setShowGenModal] = useState<boolean>(false);
  const [generatedPass, setGeneratedPass] = useState<string>('');
  const [genLength, setGenLength] = useState<number>(20);
  const [genSymbols, setGenSymbols] = useState<boolean>(true);
  const [genNumbers, setGenNumbers] = useState<boolean>(true);

  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [vaultNotice, setVaultNotice] = useState<string>('');
  const [genCopied, setGenCopied] = useState<boolean>(false);

  const categories = ['All', 'Web', 'Sosmed', 'Aplikasi', 'Game'];

  useEffect(() => {
    loadVault();
  }, []);

  const loadVault = async () => {
    try {
      const items = await dataService.getVaultItems();
      setVaultItems(items);
    } catch (e) {
      console.error(e);
    }
  };

  // Inactivity auto-lock listener
  const handleLock = useCallback(() => {
    setIsUnlocked(false);
    setRevealedSecrets({});
    setPassphraseInput('');
    setRemainingSeconds(INACTIVITY_TIMEOUT_SECONDS);
  }, []);

  const resetInactivity = useCallback(() => {
    lastActivityRef.current = Date.now();
    setRemainingSeconds(INACTIVITY_TIMEOUT_SECONDS);
  }, []);

  useEffect(() => {
    if (!isUnlocked) {
      if (inactivityTimerRef.current) clearInterval(inactivityTimerRef.current);
      return;
    }

    // Set countdown interval
    inactivityTimerRef.current = setInterval(() => {
      const elapsed = Math.floor((Date.now() - lastActivityRef.current) / 1000);
      const remaining = Math.max(0, INACTIVITY_TIMEOUT_SECONDS - elapsed);
      setRemainingSeconds(remaining);

      if (remaining <= 0) {
        handleLock();
      }
    }, 1000);

    // Event listeners to detect activity
    const activityEvents = ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll'];
    const handleUserActivity = () => resetInactivity();

    activityEvents.forEach((ev) => window.addEventListener(ev, handleUserActivity));

    return () => {
      if (inactivityTimerRef.current) clearInterval(inactivityTimerRef.current);
      activityEvents.forEach((ev) => window.removeEventListener(ev, handleUserActivity));
    };
  }, [isUnlocked, handleLock, resetInactivity]);

  const handleUnlock = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassphraseError('');

    if (!passphraseInput || passphraseInput.length < 6) {
      setPassphraseError('Kata sandi master minimal 6 karakter.');
      return;
    }

    setMasterPassphrase(passphraseInput);
    setIsUnlocked(true);
    resetInactivity();

    // Pre-decrypt initial items that have payload
    const decryptedMap: { [id: string]: string } = {};
    for (const item of vaultItems) {
      if (item.secret_value) {
        decryptedMap[item.id] = item.secret_value;
      } else if (item.encrypted_payload) {
        try {
          const dec = await decryptSecret(item.encrypted_payload, passphraseInput);
          decryptedMap[item.id] = dec;
        } catch {
          // If decryption fails for one item, gracefully keep masked
        }
      }
    }
    setRevealedSecrets(decryptedMap);
  };

  const toggleReveal = async (item: VaultItem) => {
    resetInactivity();
    if (revealedSecrets[item.id]) {
      // Hide
      setRevealedSecrets((prev) => {
        const next = { ...prev };
        delete next[item.id];
        return next;
      });
    } else {
      // Reveal
      if (item.secret_value) {
        setRevealedSecrets((prev) => ({ ...prev, [item.id]: item.secret_value! }));
      } else if (item.encrypted_payload) {
        try {
          const plain = await decryptSecret(item.encrypted_payload, masterPassphrase);
          setRevealedSecrets((prev) => ({ ...prev, [item.id]: plain }));
        } catch (err: any) {
          setVaultNotice('Gagal mendekripsi: Kata sandi master brankas tidak cocok.');
        }
      }
    }
  };

  const handleCopy = (text: string, key: string) => {
    resetInactivity();
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleCopySecret = async (item: VaultItem) => {
    resetInactivity();
    let secret = revealedSecrets[item.id] || item.secret_value;
    if (!secret && item.encrypted_payload) {
      try {
        secret = await decryptSecret(item.encrypted_payload, masterPassphrase);
      } catch (err) {
        setVaultNotice('Gagal mendekripsi: Kata sandi master tidak sesuai.');
        return;
      }
    }

    if (secret) {
      handleCopy(secret, `sec-${item.id}`);
    }
  };

  const handleOpenAdd = () => {
    resetInactivity();
    setEditingItem({
      title: '',
      category: activeCategory !== 'All' ? activeCategory : 'Aplikasi',
      identity_type: 'Email',
      identity_value: '',
      credential_type: 'Password',
      secret_value: '',
      notes: ''
    });
    setShowModal(true);
  };

  const handleOpenEdit = async (item: VaultItem) => {
    resetInactivity();
    let secret = revealedSecrets[item.id] || item.secret_value;
    if (!secret && item.encrypted_payload) {
      try {
        secret = await decryptSecret(item.encrypted_payload, masterPassphrase);
      } catch (e) {}
    }

    setEditingItem({
      id: item.id,
      title: item.title,
      category: item.category || 'Aplikasi',
      identity_type: item.identity_type || 'Email',
      identity_value: item.identity_value || '',
      credential_type: item.credential_type || 'Password',
      secret_value: secret || '',
      notes: item.notes || ''
    });
    setShowModal(true);
  };

  const handleSaveItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem || !editingItem.title.trim() || !editingItem.secret_value.trim()) return;

    try {
      // Encrypt with Web Crypto API AES-GCM
      const encryptedPayload = await encryptSecret(editingItem.secret_value, masterPassphrase);

      const saved = await dataService.saveVaultItem({
        id: editingItem.id,
        title: editingItem.title,
        category: editingItem.category,
        identity_type: editingItem.identity_type,
        identity_value: editingItem.identity_value,
        credential_type: editingItem.credential_type,
        encrypted_payload: encryptedPayload,
        encryption_version: 'AES-GCM-PBKDF2-v1',
        secret_value: editingItem.secret_value,
        notes: editingItem.notes
      });

      // Update in-memory map
      setRevealedSecrets((prev) => ({
        ...prev,
        [saved.id]: editingItem.secret_value
      }));

      await loadVault();
      setShowModal(false);
      setEditingItem(null);
      resetInactivity();
    } catch (err: any) {
      setVaultNotice('Gagal mengenkripsi/menyimpan item: ' + (err?.message || 'Kesalahan sistem'));
    }
  };

  const handleDeleteItem = async () => {
    if (!deleteConfirmId) return;
    await dataService.deleteVaultItem(deleteConfirmId);
    setVaultItems((prev) => prev.filter((v) => v.id !== deleteConfirmId));
    setDeleteConfirmId(null);
    resetInactivity();
  };

  const handleGeneratePassword = () => {
    const pw = generateStrongPassword(genLength, {
      symbols: genSymbols,
      numbers: genNumbers,
      uppercase: true
    });
    setGeneratedPass(pw);
  };

  const formatCountdown = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const getCategoryIcon = (cat: string) => {
    switch (cat.toLowerCase()) {
      case 'web':
        return <Globe className="w-3.5 h-3.5 text-primary" />;
      case 'sosmed':
        return <Share2 className="w-3.5 h-3.5 text-primary" />;
      case 'aplikasi':
        return <Smartphone className="w-3.5 h-3.5 text-primary" />;
      case 'game':
        return <Gamepad2 className="w-3.5 h-3.5 text-primary" />;
      default:
        return <KeyRound className="w-3.5 h-3.5 text-primary" />;
    }
  };

  const filteredItems = vaultItems.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.identity_value || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.notes || '').toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCat =
      activeCategory === 'All' ||
      (item.category || '').toLowerCase() === activeCategory.toLowerCase();

    return matchesSearch && matchesCat;
  });

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-outline-variant/30">
        <div>
          <h1 className="font-editorial text-3xl text-on-surface flex items-center gap-2">
            <span>Brankas Kredensial Rahasia (AES-256)</span>
            {isUnlocked ? (
              <span className="text-xs font-mono font-bold text-primary bg-primary/10 px-2.5 py-0.5 rounded-full">
                Terbuka
              </span>
            ) : (
              <span className="text-xs font-mono font-bold text-error bg-error-container text-on-error-container px-2.5 py-0.5 rounded-full">
                Terkunci
              </span>
            )}
          </h1>
          <p className="text-xs text-secondary mt-1">
            Enkripsi tingkat tinggi untuk akun privat, kunci API, dan kredensial rahasia.
          </p>
        </div>

        {isUnlocked && (
          <div className="flex flex-wrap items-center gap-2">
            <Link
              to="/admin/security#brankas"
              className="px-3 py-2 bg-surface-container hover:bg-surface-container-high rounded-lg text-xs font-semibold text-on-surface flex items-center gap-1.5 transition-colors border border-outline-variant/30"
              title="Ubah Kata Sandi Master Brankas di Pengaturan"
            >
              <KeyRound className="w-3.5 h-3.5 text-primary" />
              <span>Ubah Sandi Master</span>
            </Link>
            <button
              onClick={() => {
                handleGeneratePassword();
                setShowGenModal(true);
              }}
              className="px-3.5 py-2 bg-surface-container hover:bg-surface-container-high rounded-lg text-xs font-semibold text-on-surface flex items-center gap-1.5 transition-colors"
              title="Pembuat Sandi Kuat"
            >
              <Sparkles className="w-3.5 h-3.5 text-primary" />
              <span>Buat Sandi Acak</span>
            </button>
            <button
              onClick={handleOpenAdd}
              className="px-4 py-2 bg-primary text-on-primary hover:bg-primary-container rounded-lg text-xs font-semibold flex items-center gap-2 shadow-xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Item</span>
            </button>
            <button
              onClick={handleLock}
              className="px-3.5 py-2 bg-error text-on-error rounded-lg text-xs font-semibold hover:opacity-90 flex items-center gap-1.5 transition-colors"
              title="Kunci Brankas Seketika"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Kunci Brankas</span>
            </button>
          </div>
        )}
      </div>

      {vaultNotice && (
        <div className="p-3.5 bg-error-container/60 border border-error/30 text-error text-xs rounded-xl flex items-center justify-between gap-2">
          <span>{vaultNotice}</span>
          <button onClick={() => setVaultNotice('')} className="text-error font-semibold hover:underline text-xs shrink-0 cursor-pointer">
            Tutup
          </button>
        </div>
      )}

      {/* Vault Inactivity & Security Status Banner when Unlocked */}
      {isUnlocked && (
        <div className="p-3.5 rounded-xl bg-primary/10 border border-primary/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-primary font-semibold">
            <ShieldCheck className="w-4 h-4 shrink-0" />
            <span>🔒 Brankas Terbuka • Enkripsi AES-256 Aktif</span>
          </div>
          <div className="flex items-center gap-2 text-secondary font-mono">
            <Clock className="w-3.5 h-3.5 text-outline" />
            <span>
              ⏱ Kunci otomatis setelah 5 menit tanpa aktivitas:
            </span>
            <span className="font-bold text-on-surface bg-surface px-2 py-0.5 rounded shadow-2xs">
              {formatCountdown(remainingSeconds)}
            </span>
          </div>
        </div>
      )}

      {/* Vault Locked Viewport (Passphrase Challenge) */}
      {!isUnlocked ? (
        <div className="max-w-md mx-auto my-12 p-8 bg-surface-container-lowest rounded-2xl border border-outline-variant/40 shadow-sm text-center">
          <div className="w-14 h-14 rounded-2xl bg-primary/10 text-primary mx-auto mb-4 flex items-center justify-center">
            <Lock className="w-7 h-7" />
          </div>

          <h2 className="font-editorial text-2xl text-on-surface mb-2 font-semibold">
            Buka Kunci Brankas Rahasia
          </h2>
          <p className="text-xs text-secondary mb-6 leading-relaxed">
            Masukkan Kata Sandi Master Anda untuk mendekripsi kredensial akun, token API, dan data rahasia di memori aman peramban Anda.
          </p>

          {passphraseError && (
            <div className="mb-4 p-3 bg-error-container/60 border border-error/30 text-error text-xs rounded-xl flex items-center gap-2 text-left">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{passphraseError}</span>
            </div>
          )}

          <form onSubmit={handleUnlock} className="space-y-4">
            <div>
              <input
                type="password"
                value={passphraseInput}
                onChange={(e) => setPassphraseInput(e.target.value)}
                placeholder="Kata sandi master brankas..."
                required
                className="w-full px-4 py-2.5 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary text-center font-mono"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-primary text-on-primary rounded-lg text-xs font-semibold hover:bg-primary-container flex items-center justify-center gap-2 shadow-xs transition-all"
            >
              <Unlock className="w-4 h-4" />
              <span>Buka Brankas Terenkripsi</span>
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-outline-variant/20 text-[11px] text-secondary flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left">
            <p>
              Kunci default master: <strong className="font-mono text-on-surface">SyahrulMasterKey2026!</strong>
            </p>
            <Link
              to="/admin/security#brankas"
              className="text-primary hover:underline font-semibold flex items-center gap-1 shrink-0"
              title="Ubah Kata Sandi Brankas di Pengaturan"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>Ubah di Pengaturan</span>
            </Link>
          </div>
        </div>
      ) : (
        /* Vault Unlocked Viewport (Items List, Search, Cards) */
        <div className="space-y-4 animate-in fade-in duration-200">
          {/* Search & Category Filter Bar */}
          <div className="bg-surface-container-lowest p-4 rounded-xl border border-outline-variant/30 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-secondary absolute left-3 top-2.5 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  resetInactivity();
                }}
                placeholder="Cari judul atau identitas kredensial..."
                className="w-full pl-9 pr-4 py-2 bg-surface-container-low text-xs rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary text-on-surface"
              />
            </div>

            <div className="flex flex-wrap items-center gap-1.5">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => {
                    setActiveCategory(cat);
                    resetInactivity();
                  }}
                  className={`px-3.5 py-1.5 text-xs rounded-lg font-medium transition-colors ${
                    activeCategory === cat
                      ? 'bg-primary text-on-primary font-semibold shadow-xs'
                      : 'bg-surface-container-low text-secondary hover:text-on-surface hover:bg-surface-container'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Items Cards Grid matching Screenshot 4 */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredItems.length === 0 ? (
              <div className="col-span-full py-12 text-center bg-surface-container-low/40 rounded-xl border border-outline-variant/30 text-xs text-secondary">
                Tidak ada kredensial brankas pada kategori ini.
              </div>
            ) : (
              filteredItems.map((item, index) => {
                const isRevealed = !!revealedSecrets[item.id];
                const displaySecret = isRevealed
                  ? revealedSecrets[item.id]
                  : '••••••••••••••••••••';

                return (
                  <div
                    key={`${item.id}-${index}`}
                    className="p-5 rounded-xl bg-surface-container-lowest border border-outline-variant/30 shadow-xs flex flex-col justify-between gap-4 hover:border-primary/40 transition-all"
                  >
                    <div>
                      {/* Card Header: Category Badge + Edit/Delete */}
                      <div className="flex items-center justify-between mb-2">
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-surface-container-low text-[11px] font-semibold text-secondary uppercase tracking-wider">
                          {getCategoryIcon(item.category || 'Aplikasi')}
                          <span>{item.category || 'APLIKASI'}</span>
                        </span>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleOpenEdit(item)}
                            className="p-1.5 rounded-lg text-secondary hover:text-on-surface hover:bg-surface-container transition-colors"
                            title="Sunting Kredensial"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              resetInactivity();
                              setDeleteConfirmId(item.id);
                            }}
                            className="p-1.5 rounded-lg text-error hover:bg-error-container transition-colors"
                            title="Hapus Kredensial"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Title */}
                      <h3 className="font-semibold text-sm text-on-surface mb-3">
                        {item.title}
                      </h3>

                      {/* Row 1: Identity info (Email / Username) */}
                      {item.identity_value && (
                        <div className="flex items-center justify-between gap-2 p-2.5 rounded-lg bg-surface-container-low/60 border border-outline-variant/20 mb-2">
                          <div className="flex items-center gap-2 min-w-0">
                            <span className="text-[11px] font-semibold text-secondary shrink-0">
                              {item.identity_type || 'Email'}:
                            </span>
                            <span className="font-mono text-xs text-on-surface truncate">
                              {item.identity_value}
                            </span>
                          </div>
                          <button
                            onClick={() => handleCopy(item.identity_value, `id-${item.id}`)}
                            className="p-1 text-secondary hover:text-primary transition-colors shrink-0"
                            title="Salin Identitas"
                          >
                            {copiedKey === `id-${item.id}` ? (
                              <Check className="w-3.5 h-3.5 text-primary" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      )}

                      {/* Row 2: Credential info (Password / Token) */}
                      <div className="flex items-center justify-between gap-2 p-2.5 rounded-lg bg-surface-container-low/60 border border-outline-variant/20">
                        <div className="flex items-center gap-2 min-w-0 flex-1">
                          <span className="text-[11px] font-semibold text-secondary shrink-0">
                            {item.credential_type || 'Password'}:
                          </span>
                          <span className="font-mono text-xs text-on-surface tracking-wider truncate">
                            {displaySecret}
                          </span>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            onClick={() => toggleReveal(item)}
                            className="p-1 text-secondary hover:text-primary transition-colors"
                            title={isRevealed ? 'Sembunyikan' : 'Buka Rahasia'}
                          >
                            {isRevealed ? (
                              <EyeOff className="w-3.5 h-3.5" />
                            ) : (
                              <Eye className="w-3.5 h-3.5" />
                            )}
                          </button>
                          <button
                            onClick={() => handleCopySecret(item)}
                            className="p-1 text-secondary hover:text-primary transition-colors"
                            title="Salin Nilai Rahasia"
                          >
                            {copiedKey === `sec-${item.id}` ? (
                              <Check className="w-3.5 h-3.5 text-primary" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      </div>

                      {/* Optional Notes */}
                      {item.notes && (
                        <p className="text-[11px] text-secondary mt-2.5 leading-relaxed italic">
                          {item.notes}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Add / Edit Vault Item Modal matching Screenshot 5 */}
      {showModal && editingItem && (
        <div className="fixed inset-0 z-50 bg-on-surface/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-surface-container-lowest max-w-lg w-full rounded-2xl p-6 shadow-xl border border-outline-variant/40 max-h-[90vh] overflow-y-auto">
            <h3 className="font-editorial text-2xl text-on-surface font-semibold mb-4">
              {editingItem.id ? 'Sunting Kredensial' : 'Tambah Kredensial Baru'}
            </h3>

            <form onSubmit={handleSaveItem} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-secondary mb-1">
                  Judul Akun / Layanan *
                </label>
                <input
                  type="text"
                  required
                  value={editingItem.title || ''}
                  onChange={(e) => setEditingItem({ ...editingItem, title: e.target.value })}
                  placeholder="Misal: Akun Google, Saweria API, Tabungan"
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-secondary mb-1">
                    Kategori
                  </label>
                  <select
                    value={editingItem.category || 'Web'}
                    onChange={(e) => setEditingItem({ ...editingItem, category: e.target.value })}
                    className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                  >
                    <option value="Web">Web</option>
                    <option value="Sosmed">Sosmed</option>
                    <option value="Aplikasi">Aplikasi</option>
                    <option value="Game">Game</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-secondary mb-1">
                    Tipe Identitas
                  </label>
                  <select
                    value={editingItem.identity_type || 'Email'}
                    onChange={(e) => setEditingItem({ ...editingItem, identity_type: e.target.value })}
                    className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                  >
                    <option value="Email">Email</option>
                    <option value="Username">Username</option>
                    <option value="Gmail">Gmail</option>
                    <option value="No. HP">No. HP</option>
                    <option value="Token API">Token API</option>
                    <option value="Lainnya">Lainnya</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-secondary mb-1">
                  Nilai Identitas (Email / Username)
                </label>
                <input
                  type="text"
                  value={editingItem.identity_value || ''}
                  onChange={(e) => setEditingItem({ ...editingItem, identity_value: e.target.value })}
                  placeholder="Misal: ayungnew768@gmail.com atau syahrul_admin"
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-secondary mb-1">
                  Tipe Kredensial
                </label>
                <select
                  value={editingItem.credential_type || 'Password'}
                  onChange={(e) => setEditingItem({ ...editingItem, credential_type: e.target.value })}
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                >
                  <option value="Password">Password</option>
                  <option value="PIN">PIN</option>
                  <option value="Token API">Token API</option>
                  <option value="Kunci Rahasia">Kunci Rahasia</option>
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-secondary">
                    Nilai Rahasia *
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      const gen = generateStrongPassword(20);
                      setEditingItem({ ...editingItem, secret_value: gen });
                    }}
                    className="text-[11px] text-primary hover:underline font-semibold"
                  >
                    + Buat Sandi Acak
                  </button>
                </div>
                <input
                  type="text"
                  required
                  value={editingItem.secret_value || ''}
                  onChange={(e) =>
                    setEditingItem({ ...editingItem, secret_value: e.target.value })
                  }
                  placeholder="Ketik nilai rahasia, password, atau token..."
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm font-mono rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-secondary mb-1">
                  Catatan Tambahan (Opsional)
                </label>
                <textarea
                  rows={2}
                  value={editingItem.notes || ''}
                  onChange={(e) => setEditingItem({ ...editingItem, notes: e.target.value })}
                  placeholder="Keterangan kegunaan akun atau catatan pengingat..."
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary leading-relaxed"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-outline-variant/20">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-xs text-secondary hover:text-on-surface"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-primary text-on-primary rounded-lg text-xs font-semibold hover:bg-primary-container shadow-xs"
                >
                  Simpan Terenkripsi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Password Generator Modal */}
      {showGenModal && (
        <div className="fixed inset-0 z-50 bg-on-surface/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-surface-container-lowest max-w-sm w-full rounded-2xl p-6 shadow-xl border border-outline-variant/40">
            <h3 className="font-editorial text-xl text-on-surface font-semibold mb-3">
              Generator Sandi Acak Kuat
            </h3>

            <div className="p-3 bg-surface-container-low rounded-xl mb-4 flex items-center justify-between gap-2 border border-outline-variant/30">
              <span className="font-mono text-xs text-on-surface font-bold break-all">
                {generatedPass}
              </span>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(generatedPass);
                  setGenCopied(true);
                  setTimeout(() => setGenCopied(false), 2000);
                }}
                className="p-1 text-primary hover:bg-surface-container rounded shrink-0 flex items-center gap-1 text-xs"
                title="Salin"
              >
                {genCopied ? <Check className="w-4 h-4 text-primary" /> : <Copy className="w-4 h-4" />}
                <span className="text-[11px] font-semibold">{genCopied ? 'Tersalin' : 'Salin'}</span>
              </button>
            </div>

            <div className="space-y-3 mb-5">
              <div>
                <div className="flex justify-between text-xs text-secondary mb-1">
                  <span>Panjang Karakter:</span>
                  <span className="font-mono font-bold text-on-surface">{genLength}</span>
                </div>
                <input
                  type="range"
                  min="12"
                  max="36"
                  value={genLength}
                  onChange={(e) => {
                    setGenLength(parseInt(e.target.value));
                    handleGeneratePassword();
                  }}
                  className="w-full accent-primary"
                />
              </div>

              <label className="flex items-center gap-2 text-xs text-on-surface cursor-pointer">
                <input
                  type="checkbox"
                  checked={genSymbols}
                  onChange={(e) => {
                    setGenSymbols(e.target.checked);
                    handleGeneratePassword();
                  }}
                  className="accent-primary"
                />
                <span>Gunakan Simbol (!@#$%^&*)</span>
              </label>

              <label className="flex items-center gap-2 text-xs text-on-surface cursor-pointer">
                <input
                  type="checkbox"
                  checked={genNumbers}
                  onChange={(e) => {
                    setGenNumbers(e.target.checked);
                    handleGeneratePassword();
                  }}
                  className="accent-primary"
                />
                <span>Gunakan Angka (0-9)</span>
              </label>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-outline-variant/20">
              <button
                onClick={handleGeneratePassword}
                className="px-3 py-1.5 bg-surface-container hover:bg-surface-container-high rounded text-xs font-medium flex items-center gap-1"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Acak Ulang</span>
              </button>
              <button
                onClick={() => setShowGenModal(false)}
                className="px-4 py-1.5 bg-primary text-on-primary rounded text-xs font-semibold"
              >
                Selesai
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirm Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 bg-on-surface/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-surface-container-lowest max-w-sm w-full rounded-2xl p-6 shadow-xl border border-outline-variant/40">
            <h3 className="font-editorial text-xl text-on-surface font-semibold mb-2">
              Hapus Item Brankas
            </h3>
            <p className="text-xs text-secondary leading-relaxed mb-4">
              Apakah Anda yakin ingin menghapus data kredensial ini secara permanen dari brankas?
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 text-xs text-secondary hover:text-on-surface"
              >
                Batal
              </button>
              <button
                onClick={handleDeleteItem}
                className="px-4 py-2 bg-error text-on-error rounded-lg text-xs font-semibold hover:opacity-90"
              >
                Hapus Permanen
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
