import React, { useState, useEffect } from 'react';
import { dataService } from '../../services/dataService';
import { SocialLink } from '../../types';
import {
  Link2,
  Plus,
  ExternalLink,
  Copy,
  Check,
  Edit2,
  Trash2,
  Search,
  Globe,
  Share2,
  Smartphone,
  Gamepad2,
  Eye,
  EyeOff,
  AlertCircle
} from 'lucide-react';

export const LinksPage: React.FC = () => {
  const [links, setLinks] = useState<SocialLink[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeCategory, setActiveCategory] = useState<string>('All');

  // Modal states
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editingLink, setEditingLink] = useState<Partial<SocialLink> | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [urlError, setUrlError] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const categories = ['All', 'Web', 'Sosmed', 'Aplikasi', 'Game'];

  useEffect(() => {
    loadLinks();
  }, []);

  const loadLinks = async () => {
    setIsLoading(true);
    try {
      const data = await dataService.getSocialLinks(false);
      setLinks(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpenAdd = () => {
    setEditingLink({
      title: '',
      label: '',
      url: 'https://',
      category: activeCategory !== 'All' ? activeCategory : 'Web',
      platform: 'website',
      description: '',
      is_published: true,
      display_order: links.length + 1
    });
    setUrlError('');
    setShowModal(true);
  };

  const handleOpenEdit = (link: SocialLink) => {
    setEditingLink({ ...link });
    setUrlError('');
    setShowModal(true);
  };

  const validateUrl = (urlStr: string): boolean => {
    try {
      const parsed = new URL(urlStr);
      return parsed.protocol === 'https:' || parsed.protocol === 'http:';
    } catch {
      return false;
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingLink || !editingLink.title?.trim() || !editingLink.url?.trim()) return;

    if (!validateUrl(editingLink.url)) {
      setUrlError('URL harus berupa alamat tautan yang valid dan diawali https:// atau http://');
      return;
    }

    setIsSubmitting(true);
    try {
      await dataService.saveSocialLink({
        ...editingLink,
        label: editingLink.title, // Keep synchronized
        category: editingLink.category || 'Web'
      });
      await loadLinks();
      setShowModal(false);
      setEditingLink(null);
    } catch (err: any) {
      setUrlError(err?.message || 'Gagal menyimpan tautan ke database.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteConfirmId) return;
    try {
      await dataService.deleteSocialLink(deleteConfirmId);
      setLinks((prev) => prev.filter((l) => l.id !== deleteConfirmId));
      setDeleteConfirmId(null);
    } catch (err: any) {
      console.error('Delete link error:', err);
      setDeleteConfirmId(null);
    }
  };

  const handleTogglePublish = async (link: SocialLink) => {
    try {
      const updated = await dataService.saveSocialLink({
        ...link,
        is_published: !link.is_published
      });
      setLinks((prev) => prev.map((l) => (l.id === link.id ? updated : l)));
    } catch (e) {
      console.error(e);
    }
  };

  const handleCopyUrl = (link: SocialLink) => {
    navigator.clipboard.writeText(link.url);
    setCopiedId(link.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getCategoryIcon = (cat: string) => {
    switch (cat.toLowerCase()) {
      case 'web':
        return <Globe className="w-3.5 h-3.5 text-primary" />;
      case 'sosmed':
        return <Share2 className="w-3.5 h-3.5 text-primary" />;
      case 'aplikasi':
        return <Smartphone className="w-3.5 h-3.5 text-primary" />;
      case 'game':
        return <Gamepad2 className="w-3.5 h-3.5 text-primary" />;
      default:
        return <Link2 className="w-3.5 h-3.5 text-primary" />;
    }
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '22/10/2026';
    try {
      const d = new Date(dateStr);
      return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
    } catch {
      return '22/10/2026';
    }
  };

  const filteredLinks = links.filter((link) => {
    const matchesSearch =
      (link.title || link.label || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      link.url.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (link.description || '').toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory =
      activeCategory === 'All' ||
      (link.category || '').toLowerCase() === activeCategory.toLowerCase();

    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-outline-variant/30">
        <div>
          <h1 className="font-editorial text-3xl text-on-surface">
            Koleksi Tautan &amp; Jejaring Sosial
          </h1>
          <p className="text-xs text-secondary mt-1">
            Kelola tautan resmi Instagram, TikTok, LinkedIn, GitHub, dan saluran komunikasi publik Syahrul Gunawan.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2 bg-primary text-on-primary hover:bg-primary-container rounded-lg text-xs font-semibold flex items-center gap-2 shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Tambah Tautan</span>
        </button>
      </div>

      {/* Filter Category Pills & Search Bar */}
      <div className="bg-surface-container-lowest p-4 rounded-xl border border-outline-variant/30 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-secondary absolute left-3 top-2.5 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari tautan, url, atau deskripsi..."
            className="w-full pl-9 pr-4 py-2 bg-surface-container-low text-xs rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary text-on-surface"
          />
        </div>

        {/* Category Filter Pills (All, Web, Sosmed, Aplikasi, Game) */}
        <div className="flex flex-wrap items-center gap-1.5">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3.5 py-1.5 text-xs rounded-lg font-medium transition-colors ${
                activeCategory === cat
                  ? 'bg-primary text-on-primary font-semibold shadow-xs'
                  : 'bg-surface-container-low text-secondary hover:text-on-surface hover:bg-surface-container'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Links List Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {isLoading ? (
          <div className="col-span-full py-12 text-center text-xs text-secondary">
            Memuat daftar tautan...
          </div>
        ) : filteredLinks.length === 0 ? (
          <div className="col-span-full py-12 text-center bg-surface-container-low/40 rounded-xl border border-outline-variant/30 text-xs text-secondary">
            Tidak ada tautan pada kategori ini.
          </div>
        ) : (
          filteredLinks.map((link, idx) => (
            <div
              key={`${link.id}-${idx}`}
              className={`p-5 rounded-xl border transition-all flex flex-col justify-between gap-3 bg-surface-container-lowest ${
                link.is_published
                  ? 'border-outline-variant/30 hover:border-primary/40 shadow-xs'
                  : 'border-dashed border-outline/40 opacity-70'
              }`}
            >
              {/* Card Top: Category Badge + Date */}
              <div className="flex items-center justify-between">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-surface-container-low text-[11px] font-medium text-secondary">
                  {getCategoryIcon(link.category || 'Web')}
                  <span>{link.category || 'Web'}</span>
                </span>
                <span className="text-[11px] font-mono text-outline">
                  {formatDate(link.created_at)}
                </span>
              </div>

              {/* Title & URL */}
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-sm text-on-surface">
                    {link.title || link.label}
                  </h3>
                  {!link.is_published && (
                    <span className="px-2 py-0.5 rounded bg-error-container text-on-error-container text-[10px] font-semibold">
                      Disembunyikan
                    </span>
                  )}
                </div>

                <a
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-mono text-primary hover:underline truncate block"
                >
                  {link.url}
                </a>

                {link.description && (
                  <p className="text-xs text-secondary line-clamp-2 mt-1 leading-relaxed">
                    {link.description}
                  </p>
                )}
              </div>

              {/* Card Bottom: Action Buttons */}
              <div className="pt-3 border-t border-outline-variant/20 flex items-center justify-between gap-2 mt-1">
                <div className="flex items-center gap-2">
                  <a
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-2.5 py-1.5 rounded-lg bg-surface-container hover:bg-surface-container-high text-on-surface text-xs font-medium flex items-center gap-1.5 transition-colors"
                    title="Uji Buka Tautan"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Uji Tautan</span>
                  </a>

                  <button
                    onClick={() => handleCopyUrl(link)}
                    className="px-2.5 py-1.5 rounded-lg bg-surface-container hover:bg-surface-container-high text-on-surface text-xs font-medium flex items-center gap-1.5 transition-colors"
                    title="Salin Alamat Tautan"
                  >
                    {copiedId === link.id ? (
                      <Check className="w-3.5 h-3.5 text-primary" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span>{copiedId === link.id ? 'Tersalin!' : 'Salin'}</span>
                  </button>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleTogglePublish(link)}
                    className="p-1.5 rounded-lg text-secondary hover:text-on-surface hover:bg-surface-container transition-colors"
                    title={link.is_published ? 'Sembunyikan dari Publik' : 'Tampilkan di Publik'}
                  >
                    {link.is_published ? (
                      <Eye className="w-4 h-4 text-primary" />
                    ) : (
                      <EyeOff className="w-4 h-4" />
                    )}
                  </button>

                  <button
                    onClick={() => handleOpenEdit(link)}
                    className="p-1.5 rounded-lg text-secondary hover:text-on-surface hover:bg-surface-container transition-colors"
                    title="Sunting Tautan"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => setDeleteConfirmId(link.id)}
                    className="p-1.5 rounded-lg text-error hover:bg-error-container transition-colors"
                    title="Hapus Tautan"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add / Edit Form Modal */}
      {showModal && editingLink && (
        <div className="fixed inset-0 z-50 bg-on-surface/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-surface-container-lowest max-w-md w-full rounded-2xl p-6 shadow-xl border border-outline-variant/40">
            <h3 className="font-editorial text-2xl text-on-surface font-semibold mb-4">
              {editingLink.id ? 'Sunting Tautan' : 'Tambah Tautan Baru'}
            </h3>

            {urlError && (
              <div className="mb-4 p-3 bg-error-container/60 border border-error/30 text-error text-xs rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{urlError}</span>
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-secondary mb-1">
                  Judul Tautan *
                </label>
                <input
                  type="text"
                  required
                  value={editingLink.title || ''}
                  onChange={(e) => setEditingLink({ ...editingLink, title: e.target.value })}
                  placeholder="Misal: Nabung, Nonton ilegal, Instagram Resmi"
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-secondary mb-1">
                  Alamat URL (Harus diawali https://) *
                </label>
                <input
                  type="url"
                  required
                  value={editingLink.url || ''}
                  onChange={(e) => {
                    setEditingLink({ ...editingLink, url: e.target.value });
                    setUrlError('');
                  }}
                  placeholder="https://ayungwell.ai.studio/"
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm font-mono rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-secondary mb-1">
                  Kategori
                </label>
                <select
                  value={editingLink.category || 'Web'}
                  onChange={(e) =>
                    setEditingLink({
                      ...editingLink,
                      category: e.target.value as any
                    })
                  }
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                >
                  <option value="Web">Web</option>
                  <option value="Sosmed">Sosmed</option>
                  <option value="Aplikasi">Aplikasi</option>
                  <option value="Game">Game</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-secondary mb-1">
                  Deskripsi (Opsional)
                </label>
                <textarea
                  rows={2}
                  value={editingLink.description || ''}
                  onChange={(e) =>
                    setEditingLink({ ...editingLink, description: e.target.value })
                  }
                  placeholder="Catatan ringkas atau keterangan kegunaan tautan..."
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary leading-relaxed"
                />
              </div>

              <div>
                <label className="flex items-center gap-2 cursor-pointer mt-1">
                  <input
                    type="checkbox"
                    checked={editingLink.is_published ?? true}
                    onChange={(e) =>
                      setEditingLink({ ...editingLink, is_published: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-primary focus:ring-primary accent-primary"
                  />
                  <span className="text-xs text-on-surface">Tampilkan di halaman publik</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-outline-variant/20">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-xs text-secondary hover:text-on-surface"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-primary text-on-primary rounded-lg text-xs font-semibold hover:bg-primary-container disabled:opacity-50"
                >
                  {isSubmitting ? 'Menyimpan...' : 'Simpan Tautan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 bg-on-surface/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-surface-container-lowest max-w-sm w-full rounded-2xl p-6 shadow-xl border border-outline-variant/40">
            <h3 className="font-editorial text-xl text-on-surface font-semibold mb-2">
              Hapus Tautan
            </h3>
            <p className="text-xs text-secondary leading-relaxed mb-4">
              Apakah Anda yakin ingin menghapus tautan ini dari daftar koleksi dan publik?
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 text-xs text-secondary hover:text-on-surface"
              >
                Batal
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-error text-on-error rounded-lg text-xs font-semibold hover:opacity-90"
              >
                Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
