import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, Lock, ArrowRight, ShieldCheck, Clock, Sparkles } from 'lucide-react';

export const NotesVaultHub: React.FC = () => {
  return (
    <div className="space-y-8 max-w-4xl mx-auto py-4">
      {/* Page Header */}
      <div className="text-center space-y-2 pb-6 border-b border-outline-variant/30">
        <h1 className="font-editorial text-4xl text-on-surface font-normal">
          Catatan &amp; Brankas Rahasia
        </h1>
        <p className="text-sm text-secondary max-w-xl mx-auto leading-relaxed">
          Pusat pengelolaan dokumen privat, arsip pemikiran kreatif, serta brankas terenkripsi tingkat tinggi untuk Syahrul Gunawan.
        </p>
      </div>

      {/* 2 Main Choice Cards matching Screenshot 2 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Card 1: Catatan Ide */}
        <div className="p-8 rounded-2xl bg-surface-container-lowest border border-outline-variant/30 hover:border-primary/40 shadow-xs transition-all flex flex-col justify-between group">
          <div className="space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-primary/10 text-primary flex items-center justify-center group-hover:bg-primary group-hover:text-on-primary transition-colors">
              <FileText className="w-7 h-7" />
            </div>

            <div>
              <span className="text-[11px] font-mono font-semibold text-secondary uppercase tracking-wider">
                Dokumentasi &amp; Jurnal
              </span>
              <h2 className="font-editorial text-2xl font-semibold text-on-surface mt-1">
                Catatan Ide Harian
              </h2>
            </div>

            <p className="text-xs text-secondary leading-relaxed">
              Ruang pencatatan ide harian, arsip rapat, dan rencana penting. Dilengkapi fitur autosave otomatis, pratinjau markdown, dan ekspor instan.
            </p>

            <div className="flex items-center gap-2 text-[11px] text-primary font-mono pt-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Autosave otomatis • Tersimpan privat</span>
            </div>
          </div>

          <div className="pt-6 mt-6 border-t border-outline-variant/20">
            <Link
              to="/admin/notes"
              className="w-full py-2.5 px-4 rounded-xl bg-surface-container hover:bg-surface-container-high text-on-surface text-xs font-semibold flex items-center justify-center gap-2 transition-colors group-hover:bg-primary group-hover:text-on-primary"
            >
              <span>Buka Catatan Ide</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>

        {/* Card 2: Brankas Kredensial */}
        <div className="p-8 rounded-2xl bg-surface-container-lowest border border-outline-variant/30 hover:border-primary/40 shadow-xs transition-all flex flex-col justify-between group">
          <div className="space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-primary/10 text-primary flex items-center justify-center group-hover:bg-primary group-hover:text-on-primary transition-colors">
              <Lock className="w-7 h-7" />
            </div>

            <div>
              <span className="text-[11px] font-mono font-semibold text-secondary uppercase tracking-wider">
                Kriptografi AES-256
              </span>
              <h2 className="font-editorial text-2xl font-semibold text-on-surface mt-1">
                Brankas Kredensial
              </h2>
            </div>

            <p className="text-xs text-secondary leading-relaxed">
              Enkripsi tingkat tinggi untuk akun privat, kunci API, dan kredensial rahasia. Terproteksi Web Crypto API dengan kunci otomatis setelah 5 menit.
            </p>

            <div className="flex items-center gap-2 text-[11px] text-primary font-mono pt-2">
              <Clock className="w-3.5 h-3.5" />
              <span>Kunci otomatis 5 menit • Enkripsi AES-GCM</span>
            </div>
          </div>

          <div className="pt-6 mt-6 border-t border-outline-variant/20">
            <Link
              to="/admin/vault"
              className="w-full py-2.5 px-4 rounded-xl bg-surface-container hover:bg-surface-container-high text-on-surface text-xs font-semibold flex items-center justify-center gap-2 transition-colors group-hover:bg-primary group-hover:text-on-primary"
            >
              <span>Akses Brankas Kredensial</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
