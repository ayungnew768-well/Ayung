import React, { useState, useEffect } from 'react';
import { dataService } from '../../services/dataService';
import { DonationSettings } from '../../types';
import {
  Heart,
  Save,
  QrCode,
  Link as LinkIcon,
  Upload,
  Check,
  AlertCircle,
  RotateCcw,
  ShieldAlert
} from 'lucide-react';

export const DonationPage: React.FC = () => {
  const [donation, setDonation] = useState<DonationSettings | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [uploadingQris, setUploadingQris] = useState<boolean>(false);

  useEffect(() => {
    loadDonation();
  }, []);

  const loadDonation = async () => {
    setIsLoading(true);
    try {
      const data = await dataService.getDonationSettings();
      setDonation(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!donation) return;

    setIsSaving(true);
    setErrorMsg('');
    try {
      await dataService.updateDonationSettings(donation);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err: any) {
      setErrorMsg('Gagal menyimpan pengaturan donasi.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleQrisUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !donation) return;

    setUploadingQris(true);
    try {
      const { url } = await dataService.uploadMedia(file, 'donation-media');
      setDonation({
        ...donation,
        qris_image_path: url
      });
    } catch (err: any) {
      setErrorMsg(err.message || 'Gagal mengunggah kode QRIS.');
    } finally {
      setUploadingQris(false);
    }
  };

  const handleReset = async () => {
    if (!window.confirm('Pulihkan pengaturan donasi ke setelan default?')) return;
    try {
      const reset = await dataService.updateDonationSettings({
        enabled: true,
        title: 'Dukung Saya',
        description: 'Jika kamu menikmati karya, tulisan, atau proyek ini, kamu dapat memberikan apresiasi langsung secara digital.',
        donation_url: 'https://saweria.co/syahrulgunawan',
        qris_image_path: '/assets/qris_syahrul_official.png'
      });
      setDonation(reset);
    } catch (err) {
      setErrorMsg('Gagal memulihkan pengaturan.');
    }
  };

  if (!donation) return null;

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-outline-variant/30">
        <div>
          <h1 className="font-editorial text-3xl text-on-surface">
            Pengaturan Gerbang Donasi &amp; Apresiasi
          </h1>
          <p className="text-xs text-secondary mt-1">
            Konfigurasikan kode QRIS statis dan tautan Saweria/Trakteer untuk dukungan sukarela penikmat karya.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {saveSuccess && (
            <span className="text-xs text-primary font-semibold flex items-center gap-1 animate-in fade-in">
              <Check className="w-4 h-4" />
              <span>Pengaturan Tersimpan!</span>
            </span>
          )}

          <button
            onClick={handleReset}
            className="px-3.5 py-2 bg-surface-container hover:bg-surface-container-high text-on-surface rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
            title="Pulihkan Default"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>

          <button
            onClick={handleSave}
            disabled={isSaving}
            className="px-5 py-2 bg-primary text-on-primary hover:bg-primary-container rounded-lg text-xs font-semibold flex items-center gap-2 shadow-xs transition-colors disabled:opacity-50"
          >
            {isSaving ? (
              <span className="w-4 h-4 border-2 border-on-primary border-t-transparent rounded-full animate-spin"></span>
            ) : (
              <Save className="w-4 h-4" />
            )}
            <span>Simpan Konfigurasi</span>
          </button>
        </div>
      </div>

      {errorMsg && (
        <div className="p-3.5 bg-error-container/60 border border-error/30 text-error text-xs rounded-xl flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Main Form Body */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form (8 cols) */}
        <div className="lg:col-span-8 bg-surface-container-lowest p-6 rounded-2xl border border-outline-variant/30 shadow-xs space-y-6">
          {/* Master Enable Toggle */}
          <div className="flex items-center justify-between p-4 bg-surface-container-low rounded-xl border border-outline-variant/30">
            <div>
              <h3 className="text-xs font-bold text-on-surface uppercase tracking-wider">
                Status Gerbang Donasi Publik
              </h3>
              <p className="text-xs text-secondary mt-0.5">
                Aktifkan jika Anda ingin menampilkan tombol donasi dan kartu apresiasi pada beranda publik.
              </p>
            </div>

            <label className="relative inline-flex items-center cursor-pointer select-none">
              <input
                type="checkbox"
                checked={donation.enabled}
                onChange={(e) => setDonation({ ...donation, enabled: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-surface-container-high peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
            </label>
          </div>

          {/* Form Fields */}
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-secondary uppercase tracking-wider mb-1">
                Judul Modul Apresiasi
              </label>
              <input
                type="text"
                value={donation.title || ''}
                onChange={(e) => setDonation({ ...donation, title: e.target.value })}
                className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-secondary uppercase tracking-wider mb-1">
                Deskripsi Ajakan Donasi
              </label>
              <textarea
                rows={3}
                value={donation.description || ''}
                onChange={(e) => setDonation({ ...donation, description: e.target.value })}
                className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary leading-relaxed"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-secondary uppercase tracking-wider mb-1">
                Tautan Donasi Digital (Saweria / Trakteer)
              </label>
              <div className="relative">
                <LinkIcon className="w-4 h-4 text-secondary absolute left-3 top-2.5 pointer-events-none" />
                <input
                  type="url"
                  value={donation.donation_url || ''}
                  onChange={(e) => setDonation({ ...donation, donation_url: e.target.value })}
                  placeholder="https://saweria.co/syahrulgunawan"
                  className="w-full pl-9 pr-4 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                />
              </div>
            </div>

            {/* QRIS Asset Section */}
            <div className="p-4 bg-surface-container-low rounded-xl border border-outline-variant/30 space-y-3">
              <span className="text-xs font-bold text-on-surface uppercase tracking-wider block">
                Berkas Kode QRIS Resmi
              </span>

              <div className="flex flex-col sm:flex-row items-center gap-4">
                <div className="w-28 h-28 bg-white rounded-xl p-2 flex items-center justify-center shrink-0 border border-outline-variant/30 overflow-hidden shadow-xs">
                  <img
                    src={donation.qris_image_path || '/assets/qris_syahrul_official.png'}
                    alt="QRIS Preview"
                    className="w-full h-full object-contain"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '/assets/qris_syahrul_official.png';
                    }}
                  />
                </div>

                <div className="flex-1 text-center sm:text-left">
                  <p className="text-xs font-semibold text-on-surface">qris_syahrul_official.png</p>
                  <p className="text-[11px] text-secondary mt-0.5">
                    Standar QRIS Nasional (NMID valid). Terbaca oleh semua bank dan e-wallet.
                  </p>

                  <div className="flex items-center justify-center sm:justify-start gap-2 mt-3">
                    <label className="cursor-pointer px-3 py-1.5 bg-surface-container-high hover:bg-surface-container text-on-surface rounded text-xs font-semibold inline-flex items-center gap-1.5 transition-colors">
                      <Upload className="w-3.5 h-3.5" />
                      <span>{uploadingQris ? 'Mengunggah...' : 'Ganti Gambar QRIS'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleQrisUpload}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Compliance Banner */}
            <div className="p-4 bg-surface-container rounded-xl flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 text-primary shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-bold text-on-surface block">
                  Kepatuhan Transaksi &amp; Keamanan
                </span>
                <p className="text-xs text-on-surface-variant leading-relaxed mt-0.5">
                  Sistem tidak memproses transaksi pembayaran palsu. Pengunjung akan diarahkan ke gateway resmi penyedia atau memindai kode QRIS valid langsung melalui aplikasi perbankan pengguna.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Preview Card (4 cols) */}
        <div className="lg:col-span-4 bg-surface-container-lowest p-6 rounded-2xl border border-outline-variant/30 shadow-xs flex flex-col justify-between">
          <div>
            <span className="text-[11px] font-mono uppercase tracking-widest text-secondary font-semibold block mb-3">
              Pratinjau Tampilan Beranda
            </span>

            <div className="p-5 rounded-2xl bg-surface-container-low/70 border border-outline-variant/40 flex flex-col items-center text-center">
              <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center mb-3">
                <Heart className="w-5 h-5" />
              </div>

              <span className="text-[10px] font-mono text-primary uppercase font-bold tracking-widest mb-1">
                Apresiasi Karya
              </span>

              <h4 className="font-editorial text-xl text-on-surface font-semibold mb-1">
                {donation.title || 'Dukung Saya'}
              </h4>

              <p className="text-xs text-on-surface-variant leading-relaxed line-clamp-3 mb-4">
                {donation.description || 'Dukungan sukarela penikmat karya...'}
              </p>

              <button className="bg-primary text-on-primary text-xs font-semibold px-5 py-2.5 rounded-xl shadow-xs pointer-events-none">
                Kirim Donasi
              </button>
            </div>
          </div>

          <div className="pt-4 mt-4 border-t border-outline-variant/20 text-center">
            <span className="text-[11px] text-secondary">
              {donation.enabled
                ? '✓ Modul aktif dan dapat diakses publik'
                : '✕ Modul saat ini disembunyikan dari publik'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
