import React, { useState, useEffect } from 'react';
import { dataService } from '../../services/dataService';
import { Profile, ProfileDetail, Hobby } from '../../types';
import {
  Save,
  Upload,
  UserCheck,
  Check,
  AlertCircle,
  Eye,
  RotateCcw,
  Sparkles,
  Camera,
  Coffee,
  Bike,
  Plus,
  Trash2,
  Edit2
} from 'lucide-react';

export const ProfileEditorPage: React.FC = () => {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [details, setDetails] = useState<ProfileDetail[]>([]);
  const [hobbies, setHobbies] = useState<Hobby[]>([]);
  const [activeTab, setActiveTab] = useState<'identitas' | 'narasi' | 'hobi'>('identitas');

  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [uploadingAvatar, setUploadingAvatar] = useState<boolean>(false);

  // Hobby modal
  const [showHobbyModal, setShowHobbyModal] = useState<boolean>(false);
  const [editingHobby, setEditingHobby] = useState<Partial<Hobby> | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [prof, dets, hobs] = await Promise.all([
        dataService.getProfile(),
        dataService.getProfileDetails(),
        dataService.getHobbies(false)
      ]);
      setProfile(prof);
      setDetails(dets);
      setHobbies(hobs);
    } catch (err: any) {
      setErrorMsg('Gagal memuat data profil.');
    }
  };

  const handleProfileChange = (field: keyof Profile, value: string) => {
    if (!profile) return;
    setProfile({
      ...profile,
      [field]: value
    });
  };

  const handleDetailChange = (id: string, newContent: string) => {
    setDetails((prev) =>
      prev.map((item) => (item.id === id ? { ...item, content: newContent } : item))
    );
  };

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !profile) return;

    setUploadingAvatar(true);
    try {
      const { url } = await dataService.uploadMedia(file, 'profile-media');
      setProfile({
        ...profile,
        profile_photo_path: url
      });
    } catch (err: any) {
      setErrorMsg(err.message || 'Gagal mengunggah foto profil.');
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleSaveAll = async () => {
    if (!profile) return;
    setIsSaving(true);
    setErrorMsg('');
    setSaveSuccess(false);

    try {
      await Promise.all([
        dataService.updateProfile(profile),
        dataService.updateProfileDetails(details)
      ]);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err: any) {
      setErrorMsg('Gagal menyimpan perubahan ke database.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveHobby = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingHobby || !editingHobby.name) return;
    try {
      await dataService.saveHobby(editingHobby);
      const updatedHobs = await dataService.getHobbies(false);
      setHobbies(updatedHobs);
      setShowHobbyModal(false);
      setEditingHobby(null);
    } catch (err) {
      setErrorMsg('Gagal menyimpan hobi.');
    }
  };

  const handleDeleteHobby = async (id: string) => {
    if (!window.confirm('Yakin ingin menghapus hobi ini?')) return;
    try {
      await dataService.deleteHobby(id);
      setHobbies((prev) => prev.filter((h) => h.id !== id));
    } catch (err) {
      setErrorMsg('Gagal menghapus hobi.');
    }
  };

  if (!profile) return null;

  return (
    <div className="space-y-6">
      {/* Page Title & Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-outline-variant/30">
        <div>
          <h1 className="font-editorial text-3xl text-on-surface">
            Edit Profil &amp; Biodata Diri
          </h1>
          <p className="text-xs text-secondary mt-1">
            Kelola identitas resmi, latar belakang, dan deskripsi personal yang ditampilkan kepada publik.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {saveSuccess && (
            <span className="text-xs text-primary font-semibold flex items-center gap-1 animate-in fade-in">
              <Check className="w-4 h-4" />
              <span>Perubahan Disimpan &amp; Terbit!</span>
            </span>
          )}

          <button
            onClick={handleSaveAll}
            disabled={isSaving}
            className="px-5 py-2.5 bg-primary text-on-primary hover:bg-primary-container rounded-lg text-xs font-semibold flex items-center gap-2 shadow-xs transition-all disabled:opacity-50"
          >
            {isSaving ? (
              <span className="w-4 h-4 border-2 border-on-primary border-t-transparent rounded-full animate-spin"></span>
            ) : (
              <Save className="w-4 h-4" />
            )}
            <span>Simpan &amp; Terbitkan</span>
          </button>
        </div>
      </div>

      {errorMsg && (
        <div className="p-3.5 bg-error-container/60 border border-error/30 text-error text-xs rounded-xl flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-outline-variant/30">
        <button
          onClick={() => setActiveTab('identitas')}
          className={`pb-3 px-3 text-xs font-semibold tracking-wide border-b-2 transition-all ${
            activeTab === 'identitas'
              ? 'border-primary text-primary'
              : 'border-transparent text-secondary hover:text-on-surface'
          }`}
        >
          Identitas &amp; Latar Belakang
        </button>
        <button
          onClick={() => setActiveTab('narasi')}
          className={`pb-3 px-3 text-xs font-semibold tracking-wide border-b-2 transition-all ${
            activeTab === 'narasi'
              ? 'border-primary text-primary'
              : 'border-transparent text-secondary hover:text-on-surface'
          }`}
        >
          Deskripsi &amp; Narasi Diri
        </button>
        <button
          onClick={() => setActiveTab('hobi')}
          className={`pb-3 px-3 text-xs font-semibold tracking-wide border-b-2 transition-all ${
            activeTab === 'hobi'
              ? 'border-primary text-primary'
              : 'border-transparent text-secondary hover:text-on-surface'
          }`}
        >
          Hobi &amp; Minat ({hobbies.length})
        </button>
      </div>

      {/* Tab 1: Identitas & Latar Belakang */}
      {activeTab === 'identitas' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Avatar Card */}
          <div className="bg-surface-container-lowest p-6 rounded-2xl border border-outline-variant/30 shadow-xs flex flex-col items-center text-center">
            <span className="text-[11px] font-mono uppercase tracking-widest text-secondary mb-3 font-semibold">
              Foto Profil Resmi
            </span>

            <div className="relative w-40 h-40 rounded-full overflow-hidden bg-surface-container p-1 ring-1 ring-outline-variant/40 shadow-xs mb-4">
              <img
                src={profile.profile_photo_path || '/assets/syahrul_portrait.png'}
                alt={profile.display_name}
                className="w-full h-full object-cover rounded-full"
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80';
                }}
              />
              {uploadingAvatar && (
                <div className="absolute inset-0 bg-on-surface/50 flex items-center justify-center rounded-full">
                  <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}
            </div>

            <label className="cursor-pointer px-4 py-2 bg-surface-container-high hover:bg-surface-container text-on-surface rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 transition-colors">
              <Upload className="w-3.5 h-3.5" />
              <span>Ganti Foto Profil</span>
              <input
                type="file"
                accept="image/*"
                onChange={handleAvatarUpload}
                className="hidden"
              />
            </label>
            <p className="text-[11px] text-outline mt-2">
              PNG/JPG maksimal 5MB. Resolusi terbaik 1:1.
            </p>
          </div>

          {/* Form Fields */}
          <div className="lg:col-span-2 bg-surface-container-lowest p-6 rounded-2xl border border-outline-variant/30 shadow-xs space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-on-surface-variant uppercase tracking-wider mb-1">
                  Nama Tampilan
                </label>
                <input
                  type="text"
                  value={profile.display_name || ''}
                  onChange={(e) => handleProfileChange('display_name', e.target.value)}
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-on-surface-variant uppercase tracking-wider mb-1">
                  Username Publik
                </label>
                <input
                  type="text"
                  value={profile.username || ''}
                  onChange={(e) => handleProfileChange('username', e.target.value)}
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-on-surface-variant uppercase tracking-wider mb-1">
                Headline / Profesi Utama
              </label>
              <input
                type="text"
                value={profile.headline || ''}
                onChange={(e) => handleProfileChange('headline', e.target.value)}
                className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-on-surface-variant uppercase tracking-wider mb-1">
                  Domisili
                </label>
                <input
                  type="text"
                  value={profile.location || ''}
                  onChange={(e) => handleProfileChange('location', e.target.value)}
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-on-surface-variant uppercase tracking-wider mb-1">
                  Email Publik
                </label>
                <input
                  type="email"
                  value={profile.email_public || ''}
                  onChange={(e) => handleProfileChange('email_public', e.target.value)}
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                />
              </div>
            </div>

            {/* Structured Details Fields */}
            <div className="pt-3 border-t border-outline-variant/20 space-y-3">
              <span className="text-xs font-mono uppercase tracking-wider text-secondary font-semibold block">
                Detail Latar Belakang &amp; Kompetensi
              </span>
              {details.map((item, idx) => (
                <div key={`${item.id}-${idx}`}>
                  <label className="block text-xs font-medium text-secondary mb-1">
                    {item.title}
                  </label>
                  <input
                    type="text"
                    value={item.content || ''}
                    onChange={(e) => handleDetailChange(item.id, e.target.value)}
                    className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Narasi & Deskripsi Personal */}
      {activeTab === 'narasi' && (
        <div className="bg-surface-container-lowest p-6 rounded-2xl border border-outline-variant/30 shadow-xs space-y-4">
          <div>
            <label className="block text-xs font-semibold text-on-surface-variant uppercase tracking-wider mb-1">
              Narasi Pengenalan &amp; Filosofi (Tampil di Beranda)
            </label>
            <textarea
              rows={6}
              value={profile.biography || ''}
              onChange={(e) => handleProfileChange('biography', e.target.value)}
              className="w-full px-4 py-3 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary leading-relaxed"
              placeholder="Tuliskan narasi profesional tentang visi, fokus desain, dan perjalanan Anda..."
            />
          </div>

          <div className="p-4 bg-surface-container-low/70 rounded-xl border border-outline-variant/20">
            <span className="text-xs font-semibold text-secondary block mb-1">Pratinjau Tampilan:</span>
            <p className="font-editorial text-lg text-primary italic mb-2">
              "{profile.headline}"
            </p>
            <p className="font-sans text-sm text-on-surface-variant leading-relaxed">
              {profile.biography}
            </p>
          </div>
        </div>
      )}

      {/* Tab 3: Hobi & Minat */}
      {activeTab === 'hobi' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-xs text-secondary">
              Kelola daftar hobi dan minat yang memberi kesan humanis pada halaman publik.
            </p>
            <button
              onClick={() => {
                setEditingHobby({
                  name: '',
                  description: '',
                  icon: 'photo_camera',
                  is_published: true
                });
                setShowHobbyModal(true);
              }}
              className="px-3.5 py-2 bg-primary text-on-primary rounded-lg text-xs font-semibold hover:bg-primary-container flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Hobi Baru</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {hobbies.map((h, idx) => (
              <div
                key={`${h.id}-${idx}`}
                className="p-5 rounded-xl bg-surface-container-lowest border border-outline-variant/30 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="font-mono text-xs text-outline">0{idx + 1}</span>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => {
                          setEditingHobby(h);
                          setShowHobbyModal(true);
                        }}
                        className="p-1 text-secondary hover:text-on-surface rounded"
                        title="Edit Hobi"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteHobby(h.id)}
                        className="p-1 text-error hover:bg-error-container rounded"
                        title="Hapus Hobi"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  <h4 className="font-editorial text-base text-on-surface font-semibold mb-1">
                    {h.name}
                  </h4>
                  <p className="text-xs text-secondary leading-relaxed">
                    {h.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Hobby Modal */}
      {showHobbyModal && editingHobby && (
        <div className="fixed inset-0 z-50 bg-on-surface/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-surface-container-lowest max-w-md w-full rounded-2xl p-6 shadow-xl border border-outline-variant/40">
            <h3 className="font-editorial text-xl text-on-surface font-semibold mb-4">
              {editingHobby.id ? 'Edit Hobi & Minat' : 'Tambah Hobi Baru'}
            </h3>

            <form onSubmit={handleSaveHobby} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-secondary mb-1">
                  Nama Aktivitas / Hobi
                </label>
                <input
                  type="text"
                  required
                  value={editingHobby.name || ''}
                  onChange={(e) => setEditingHobby({ ...editingHobby, name: e.target.value })}
                  placeholder="Misal: Fotografi Analog & Street"
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-secondary mb-1">
                  Deskripsi Singkat
                </label>
                <textarea
                  rows={3}
                  required
                  value={editingHobby.description || ''}
                  onChange={(e) =>
                    setEditingHobby({ ...editingHobby, description: e.target.value })
                  }
                  placeholder="Ceritakan mengapa aktivitas ini bermakna bagi proses kreatif Anda..."
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-secondary mb-1">
                  Pilihan Ikon
                </label>
                <select
                  value={editingHobby.icon || 'photo_camera'}
                  onChange={(e) => setEditingHobby({ ...editingHobby, icon: e.target.value })}
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                >
                  <option value="photo_camera">Kamera (Fotografi)</option>
                  <option value="local_cafe">Cangkir Kopi (Seduh Manual)</option>
                  <option value="directions_bike">Sepeda (Gowes / Olahraga)</option>
                  <option value="menu_book">Buku (Membaca)</option>
                  <option value="brush">Kuas (Melukis / Seni)</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-outline-variant/20">
                <button
                  type="button"
                  onClick={() => setShowHobbyModal(false)}
                  className="px-4 py-2 text-xs text-secondary hover:text-on-surface"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-primary text-on-primary rounded-lg text-xs font-semibold hover:bg-primary-container"
                >
                  Simpan Hobi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
