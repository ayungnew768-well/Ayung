import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { dataService } from '../../services/dataService';
import {
  Profile,
  Achievement,
  MusicTrack,
  SocialLink,
  PrivateNote,
  VaultItem,
  DonationSettings,
  ConnectionStatus
} from '../../types';
import {
  UserCheck,
  Trophy,
  Headphones,
  Heart,
  Share2,
  FileText,
  Lock,
  ArrowUpRight,
  CheckCircle,
  Clock,
  Sparkles,
  Database,
  Flame,
  Copy,
  Check,
  ChevronRight,
  ShieldCheck,
  HelpCircle,
  RefreshCw,
  Disc,
  Trash2,
  AlertTriangle,
  X
} from 'lucide-react';

export const DashboardPage: React.FC = () => {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [music, setMusic] = useState<MusicTrack[]>([]);
  const [links, setLinks] = useState<SocialLink[]>([]);
  const [notes, setNotes] = useState<PrivateNote[]>([]);
  const [vaultItems, setVaultItems] = useState<VaultItem[]>([]);
  const [donation, setDonation] = useState<DonationSettings | null>(null);
  const [status, setStatus] = useState<ConnectionStatus | null>(null);

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [copiedSql, setCopiedSql] = useState<boolean>(false);
  const [showSqlModal, setShowSqlModal] = useState<boolean>(false);
  const [showClearModal, setShowClearModal] = useState<boolean>(false);
  const [isClearing, setIsClearing] = useState<boolean>(false);

  const loadAll = async () => {
    setIsLoading(true);
    try {
      const [p, a, m, l, n, v, d, s] = await Promise.all([
        dataService.getProfile(),
        dataService.getAchievements(false),
        dataService.getMusicTracks(false),
        dataService.getSocialLinks(false),
        dataService.getPrivateNotes(),
        dataService.getVaultItems(),
        dataService.getDonationSettings(),
        dataService.getConnectionStatus()
      ]);
      setProfile(p);
      setAchievements(a);
      setMusic(m);
      setLinks(l);
      setNotes(n);
      setVaultItems(v);
      setDonation(d);
      setStatus(s);
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearAllData = async () => {
    setIsClearing(true);
    try {
      await dataService.clearAllData();
      await loadAll();
      setShowClearModal(false);
    } catch (err) {
      console.error('Failed to clear data:', err);
    } finally {
      setIsClearing(false);
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  const handleCopySql = () => {
    const sqlScript = `-- Supabase migration file located at: supabase/migrations/001_initial_schema.sql
-- Run this in your Supabase project SQL Editor to provision all tables:
-- profiles, profile_details, achievements, hobbies, music_tracks, social_links, private_notes, vault_items, donations, app_settings`;
    navigator.clipboard.writeText(sqlScript);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2000);
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-24">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mb-3"></div>
        <p className="text-xs text-secondary font-mono">Sinkronisasi status ekosistem...</p>
      </div>
    );
  }

  const activeTrack = music.length > 0 ? music[0] : null;

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Top Editorial Header & Operational Overview */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-2">
        <div className="max-w-2xl">
          <div className="flex items-center gap-1.5 text-secondary mb-2">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
            <span className="text-xs font-mono tracking-widest uppercase text-surface-tint">
              Status Publikasi: Langsung (v4.8.2)
            </span>
          </div>
          <h1 className="font-editorial text-3xl md:text-4xl text-on-surface tracking-tight font-normal">
            Selamat Datang Kembali, {profile?.display_name?.split(' ')[0] || 'Syahrul'}
          </h1>
          <p className="font-sans text-sm text-on-surface-variant mt-1.5 leading-relaxed">
            Profil publik Anda tersinkronisasi real-time. Seluruh kurasi portofolio, arsip audio, catatan privat, dan brankas keamanan aktif secara optimal.
          </p>
        </div>

        {/* Profile Completion Card */}
        <div className="bg-surface-container-lowest p-4 rounded-xl shadow-xs border border-outline-variant/30 flex items-center gap-4 lg:min-w-[320px]">
          <div className="relative w-12 h-12 flex items-center justify-center shrink-0">
            <svg className="w-12 h-12 -rotate-90" viewBox="0 0 36 36">
              <path
                className="text-surface-container-high"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="currentColor"
                strokeWidth="3"
              />
              <path
                className="text-primary"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="currentColor"
                strokeDasharray="95, 100"
                strokeLinecap="round"
                strokeWidth="3"
              />
            </svg>
            <span className="absolute font-sans font-bold text-xs text-on-surface">95%</span>
          </div>
          <div className="flex flex-col min-w-0">
            <span className="font-sans font-semibold text-xs text-on-surface truncate">
              Siap Ditampilkan
            </span>
            <p className="text-[11px] text-secondary truncate mt-0.5">
              10 Modul Terintegrasi &amp; Teruji
            </p>
            <Link
              to="/admin/profile"
              className="text-xs text-primary font-semibold hover:underline inline-flex items-center gap-1 mt-1"
            >
              <span>Periksa Profil Publik</span>
              <ChevronRight className="w-3 h-3" />
            </Link>
          </div>
        </div>
      </div>

      {/* Quick Editorial Triggers / Aksi Cepat Editor */}
      <div className="bg-surface-container-low rounded-xl p-4 border border-outline-variant/30">
        <div className="flex items-center justify-between mb-3 px-1">
          <span className="text-[11px] font-mono uppercase tracking-wider text-secondary font-semibold">
            Aksi Cepat Editor
          </span>
          <span className="text-xs text-on-surface-variant font-sans">
            Semua Modul Aktif
          </span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <Link
            to="/admin/profile"
            className="bg-surface-container-lowest p-3.5 rounded-lg border border-outline-variant/30 hover:border-primary/40 hover:shadow-xs transition-all flex items-center gap-3 group"
          >
            <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-on-primary transition-colors">
              <UserCheck className="w-4 h-4" />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-xs font-semibold text-on-surface group-hover:text-primary transition-colors truncate">
                Biodata Diri
              </span>
              <span className="text-[11px] text-secondary truncate">Sunting identitas</span>
            </div>
          </Link>

          <Link
            to="/admin/achievements"
            className="bg-surface-container-lowest p-3.5 rounded-lg border border-outline-variant/30 hover:border-primary/40 hover:shadow-xs transition-all flex items-center gap-3 group"
          >
            <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-on-primary transition-colors">
              <Trophy className="w-4 h-4" />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-xs font-semibold text-on-surface group-hover:text-primary transition-colors truncate">
                Kelola Prestasi
              </span>
              <span className="text-[11px] text-secondary truncate">
                {achievements.length} Penghargaan
              </span>
            </div>
          </Link>

          <Link
            to="/admin/music"
            className="bg-surface-container-lowest p-3.5 rounded-lg border border-outline-variant/30 hover:border-primary/40 hover:shadow-xs transition-all flex items-center gap-3 group"
          >
            <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-on-primary transition-colors">
              <Headphones className="w-4 h-4" />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-xs font-semibold text-on-surface group-hover:text-primary transition-colors truncate">
                Musik Latar
              </span>
              <span className="text-[11px] text-secondary truncate">
                {music.length} Trek terkurasi
              </span>
            </div>
          </Link>

          <Link
            to="/admin/donations"
            className="bg-surface-container-lowest p-3.5 rounded-lg border border-outline-variant/30 hover:border-primary/40 hover:shadow-xs transition-all flex items-center gap-3 group"
          >
            <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-on-primary transition-colors">
              <Heart className="w-4 h-4" />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-xs font-semibold text-on-surface group-hover:text-primary transition-colors truncate">
                Donasi Publik
              </span>
              <span className="text-[11px] text-secondary truncate">
                {donation?.enabled ? 'QRIS & Link aktif' : 'Nonaktif'}
              </span>
            </div>
          </Link>
        </div>
      </div>

      {/* Bento Grid: Real Database Metrics */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-editorial text-2xl text-on-surface">
              Status Aktual &amp; Kendali Ekosistem
            </h2>
            <p className="text-xs text-secondary mt-0.5">
              Statistik dihitung secara riil dari database konten Syahrul Gunawan.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowClearModal(true)}
              className="text-xs text-error hover:bg-error/10 border border-error/30 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
              title="Kosongkan seluruh data website ke status bersih awal"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Kosongkan Seluruh Konten</span>
            </button>
            <button
              onClick={loadAll}
              className="text-xs text-secondary hover:text-primary inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-outline-variant/30 hover:bg-surface-container-low transition-colors cursor-pointer"
              title="Muat Ulang Data"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Segarkan</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Card 1: Prestasi & Pencapaian */}
          <div className="bg-surface-container-lowest p-5 rounded-xl border border-outline-variant/30 shadow-xs flex flex-col justify-between hover:shadow-sm transition-all">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 text-primary">
                  <Trophy className="w-4 h-4" />
                  <span className="text-xs font-mono uppercase tracking-wider text-secondary font-semibold">
                    Pencapaian &amp; Karier
                  </span>
                </div>
                <span className="bg-primary-fixed text-on-primary-fixed-variant px-2 py-0.5 rounded-full text-[10px] font-bold">
                  {achievements.filter((a) => a.is_published).length} Terbit
                </span>
              </div>

              <div className="flex items-baseline gap-2 my-2">
                <span className="font-editorial text-4xl text-on-surface leading-none">
                  {achievements.length}
                </span>
                <span className="text-xs text-secondary">Total Rekam Jejak</span>
              </div>

              <div className="space-y-1.5 mt-3">
                {achievements.slice(0, 3).map((a, idx) => (
                  <div key={`${a.id || 'ach'}-${idx}`} className="p-2 rounded bg-surface-container-low flex items-start gap-2">
                    <CheckCircle className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
                    <div className="min-w-0">
                      <p className="text-xs font-medium text-on-surface truncate">{a.title}</p>
                      <p className="text-[11px] text-secondary truncate">{a.institution}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 mt-3 border-t border-outline-variant/20 flex justify-end">
              <Link
                to="/admin/achievements"
                className="text-xs text-primary font-semibold hover:underline inline-flex items-center gap-1"
              >
                <span>Kelola Prestasi</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>

          {/* Card 2: Audio Player Latar */}
          <div className="bg-surface-container-lowest p-5 rounded-xl border border-outline-variant/30 shadow-xs flex flex-col justify-between hover:shadow-sm transition-all">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 text-primary">
                  <Headphones className="w-4 h-4" />
                  <span className="text-xs font-mono uppercase tracking-wider text-secondary font-semibold">
                    Audio Player Latar
                  </span>
                </div>
                <span className="bg-primary-container text-on-primary-container px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-on-primary-container animate-pulse"></span>
                  {activeTrack ? 'Siap Berputar' : 'Belum Ada Trek'}
                </span>
              </div>

              <div className="my-2 bg-surface-container-low p-3 rounded-lg flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-surface-variant flex items-center justify-center text-primary shrink-0">
                  <Disc className="w-5 h-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <span className="text-[10px] font-mono text-secondary uppercase tracking-wider block">
                    Trek Utama Beranda
                  </span>
                  <h3 className="text-xs font-semibold text-on-surface truncate">
                    {activeTrack?.title || 'Sore Santai di Senayan'}
                  </h3>
                  <p className="text-[11px] text-secondary truncate">
                    {activeTrack?.artist || 'Mocca — Akustik'}
                  </p>
                </div>
              </div>

              {/* Harmonic waveform simulation */}
              <div className="flex items-end gap-1 h-8 px-2 py-1 bg-surface-container-low/50 rounded-lg justify-between">
                {[12, 24, 32, 20, 28, 16, 36, 20, 28, 12, 32, 24].map((h, i) => (
                  <div
                    key={i}
                    className="w-1 bg-primary/70 rounded-full"
                    style={{ height: `${h}px` }}
                  ></div>
                ))}
              </div>
            </div>

            <div className="pt-4 mt-3 border-t border-outline-variant/20 flex items-center justify-between">
              <span className="text-[11px] text-secondary font-mono">
                {music.length} Lagu Terdaftar
              </span>
              <Link
                to="/admin/music"
                className="text-xs text-primary font-semibold hover:underline inline-flex items-center gap-1"
              >
                <span>Kelola Musik</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>

          {/* Card 3: Kanal Sosial Resmi */}
          <div className="bg-surface-container-lowest p-5 rounded-xl border border-outline-variant/30 shadow-xs flex flex-col justify-between hover:shadow-sm transition-all">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 text-primary">
                  <Share2 className="w-4 h-4" />
                  <span className="text-xs font-mono uppercase tracking-wider text-secondary font-semibold">
                    Kanal Sosial Resmi
                  </span>
                </div>
                <span className="bg-primary-fixed text-on-primary-fixed-variant px-2 py-0.5 rounded-full text-[10px] font-bold">
                  {links.filter((l) => l.is_published).length} Terbit
                </span>
              </div>

              <div className="space-y-2 my-2">
                {links.slice(0, 2).map((l, idx) => (
                  <div key={`${l.id || 'link'}-${idx}`} className="flex items-center justify-between p-2.5 rounded-lg bg-surface-container-low">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-7 h-7 rounded-full bg-surface-container-high flex items-center justify-center text-on-surface">
                        <Share2 className="w-3.5 h-3.5" />
                      </div>
                      <div className="truncate">
                        <span className="text-xs font-semibold text-on-surface block truncate">
                          {l.label}
                        </span>
                        <span className="text-[11px] text-secondary truncate block">
                          {l.url}
                        </span>
                      </div>
                    </div>
                    <CheckCircle className="w-4 h-4 text-primary shrink-0" />
                  </div>
                ))}
              </div>

              <div className="p-2 rounded bg-surface-container-low/60 flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-primary shrink-0" />
                <span className="text-[11px] text-secondary">Semua tautan divalidasi HTTPS aman</span>
              </div>
            </div>

            <div className="pt-4 mt-3 border-t border-outline-variant/20 flex justify-end">
              <Link
                to="/admin/links"
                className="text-xs text-primary font-semibold hover:underline inline-flex items-center gap-1"
              >
                <span>Kelola Tautan</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>

          {/* Card 4: Donasi Publik */}
          <div className="bg-surface-container-lowest p-5 rounded-xl border border-outline-variant/30 shadow-xs flex flex-col justify-between hover:shadow-sm transition-all">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 text-primary">
                  <Heart className="w-4 h-4" />
                  <span className="text-xs font-mono uppercase tracking-wider text-secondary font-semibold">
                    Gerbang Donasi
                  </span>
                </div>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    donation?.enabled
                      ? 'bg-primary-fixed text-on-primary-fixed-variant'
                      : 'bg-surface-container-high text-secondary'
                  }`}
                >
                  {donation?.enabled ? 'Gerbang Aktif' : 'Nonaktif'}
                </span>
              </div>

              <div className="p-3 rounded-lg bg-surface-container-low my-2">
                <p className="text-xs font-semibold text-on-surface">{donation?.title || 'Dukung Saya'}</p>
                <p className="text-[11px] text-secondary mt-0.5 truncate">
                  Tautan: {donation?.donation_url || 'https://saweria.co/syahrulgunawan'}
                </p>
              </div>

              <p className="text-xs text-on-surface-variant leading-relaxed">
                Pengunjung situs publik dapat memberikan apresiasi secara langsung melalui scan QRIS statis atau gateway Saweria.
              </p>
            </div>

            <div className="pt-4 mt-3 border-t border-outline-variant/20 flex justify-end">
              <Link
                to="/admin/donations"
                className="text-xs text-primary font-semibold hover:underline inline-flex items-center gap-1"
              >
                <span>Konfigurasi Donasi</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>

          {/* Card 5: Catatan Privat */}
          <div className="bg-surface-container-lowest p-5 rounded-xl border border-outline-variant/30 shadow-xs flex flex-col justify-between hover:shadow-sm transition-all">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 text-primary">
                  <FileText className="w-4 h-4" />
                  <span className="text-xs font-mono uppercase tracking-wider text-secondary font-semibold">
                    Catatan Pribadi
                  </span>
                </div>
                <span className="bg-secondary-container text-on-secondary-container px-2 py-0.5 rounded-full text-[10px] font-bold">
                  Khusus Admin
                </span>
              </div>

              <div className="flex items-baseline gap-2 my-2">
                <span className="font-editorial text-4xl text-on-surface leading-none">
                  {notes.length}
                </span>
                <span className="text-xs text-secondary">Arsip Catatan Terkunci</span>
              </div>

              <p className="text-xs text-on-surface-variant leading-relaxed">
                Catatan internal dan filosofi desain tersimpan secara rahasia dan tidak pernah tampil pada halaman publik.
              </p>
            </div>

            <div className="pt-4 mt-3 border-t border-outline-variant/20 flex justify-end">
              <Link
                to="/admin/notes"
                className="text-xs text-primary font-semibold hover:underline inline-flex items-center gap-1"
              >
                <span>Buka Catatan</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>

          {/* Card 6: Brankas Rahasia (AES-GCM) */}
          <div className="bg-surface-container-lowest p-5 rounded-xl border border-outline-variant/30 shadow-xs flex flex-col justify-between hover:shadow-sm transition-all">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 text-primary">
                  <Lock className="w-4 h-4" />
                  <span className="text-xs font-mono uppercase tracking-wider text-secondary font-semibold">
                    Brankas Rahasia
                  </span>
                </div>
                <span className="bg-primary/10 text-primary px-2 py-0.5 rounded-full text-[10px] font-bold">
                  AES-256 GCM
                </span>
              </div>

              <div className="flex items-baseline gap-2 my-2">
                <span className="font-editorial text-4xl text-on-surface leading-none">
                  {vaultItems.length}
                </span>
                <span className="text-xs text-secondary">Kredensial Terenkripsi</span>
              </div>

              <p className="text-xs text-on-surface-variant leading-relaxed">
                Kunci API dan dokumen pribadi dienkripsi di sisi peramban menggunakan Web Crypto API dengan kunci turunan PBKDF2.
              </p>
            </div>

            <div className="pt-4 mt-3 border-t border-outline-variant/20 flex justify-end">
              <Link
                to="/admin/vault"
                className="text-xs text-primary font-semibold hover:underline inline-flex items-center gap-1"
              >
                <span>Buka Brankas</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Database & Cloud Connection Status Card */}
      <div className="bg-surface-container-lowest p-6 rounded-2xl border border-outline-variant/40 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-outline-variant/20">
          <div>
            <h3 className="font-editorial text-xl text-on-surface font-semibold flex items-center gap-2">
              <Database className="w-5 h-5 text-primary" />
              <span>Integrasi Supabase &amp; Firebase</span>
            </h3>
            <p className="text-xs text-secondary mt-1">
              Status koneksi aktual layanan cloud backend dan penyimpanan data.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowSqlModal(true)}
              className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-surface-container-high hover:bg-surface-container text-on-surface flex items-center gap-1.5 transition-colors"
            >
              <span>Lihat SQL Schema</span>
              <HelpCircle className="w-3.5 h-3.5 text-secondary" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          {/* Supabase Status */}
          <div className="p-4 rounded-xl bg-surface-container-low border border-outline-variant/30 flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary shrink-0 mt-0.5">
              <Database className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-on-surface">Supabase PostgreSQL &amp; Storage</span>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    status?.supabaseConfigured
                      ? 'bg-primary-fixed text-on-primary-fixed-variant'
                      : 'bg-secondary-container text-on-secondary-container'
                  }`}
                >
                  {status?.supabaseConfigured ? 'Terkoneksi' : 'Siap Dikonfigurasi'}
                </span>
              </div>
              <p className="text-xs text-on-surface-variant mt-1 leading-relaxed">
                {status?.supabaseConfigured
                  ? 'Menyimpan profil, prestasi, kurasi musik, dan metadata brankas.'
                  : 'Gunakan VITE_SUPABASE_URL dan VITE_SUPABASE_ANON_KEY di .env untuk menghubungkan proyek nyata.'}
              </p>
            </div>
          </div>

          {/* Firebase Status */}
          <div className="p-4 rounded-xl bg-surface-container-low border border-outline-variant/30 flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary shrink-0 mt-0.5">
              <Flame className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-on-surface">Firebase Auth &amp; Firestore</span>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    status?.firebaseConfigured
                      ? 'bg-primary-fixed text-on-primary-fixed-variant'
                      : 'bg-secondary-container text-on-secondary-container'
                  }`}
                >
                  {status?.firebaseConfigured ? 'Terkoneksi' : 'Siap Dikonfigurasi'}
                </span>
              </div>
              <p className="text-xs text-on-surface-variant mt-1 leading-relaxed">
                {status?.firebaseConfigured
                  ? 'Menangani otentikasi sesi admin dan sinkronisasi status real-time.'
                  : 'Gunakan kredensial VITE_FIREBASE_* di .env untuk menghubungkan proyek Firebase nyata.'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* SQL Migration Modal */}
      {showSqlModal && (
        <div className="fixed inset-0 z-50 bg-on-surface/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-surface-container-lowest max-w-2xl w-full rounded-2xl p-6 shadow-xl border border-outline-variant/40 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-outline-variant/20 mb-3">
              <div>
                <h3 className="font-editorial text-xl text-on-surface font-semibold">
                  Skema Database Supabase PostgreSQL
                </h3>
                <p className="text-xs text-secondary mt-0.5">
                  File tersimpan di: <code>supabase/migrations/001_initial_schema.sql</code>
                </p>
              </div>
              <button
                onClick={() => setShowSqlModal(false)}
                className="text-secondary hover:text-on-surface p-1 rounded"
              >
                Tutup
              </button>
            </div>

            <div className="flex-1 overflow-y-auto bg-surface-container-low p-4 rounded-xl font-mono text-xs text-on-surface-variant leading-relaxed">
              <pre className="whitespace-pre-wrap">
{`-- 1. PROFILES TABLE
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    firebase_uid TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL DEFAULT 'Syahrul Gunawan',
    username TEXT UNIQUE NOT NULL DEFAULT 'syahrulgunawan',
    headline TEXT NOT NULL,
    biography TEXT NOT NULL,
    location TEXT,
    profile_photo_path TEXT,
    email_public TEXT,
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- 2. ACHIEVEMENTS TABLE
CREATE TABLE IF NOT EXISTS public.achievements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    profile_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL,
    institution TEXT NOT NULL,
    achievement_date DATE,
    is_published BOOLEAN DEFAULT true
);

-- 3. PRIVATE NOTES & VAULT (CLIENT ENCRYPTED)
CREATE TABLE IF NOT EXISTS public.private_notes (...);
CREATE TABLE IF NOT EXISTS public.vault_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_uid TEXT NOT NULL,
    title TEXT NOT NULL,
    encrypted_payload TEXT NOT NULL
);`}
              </pre>
            </div>

            <div className="flex items-center justify-between pt-4 mt-3 border-t border-outline-variant/20">
              <span className="text-xs text-secondary">
                Jalankan script ini di SQL Editor dashboard Supabase Anda.
              </span>
              <button
                onClick={handleCopySql}
                className="px-4 py-2 bg-primary text-on-primary rounded-lg text-xs font-semibold hover:bg-primary-container flex items-center gap-1.5 cursor-pointer"
              >
                {copiedSql ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedSql ? 'Tersalin!' : 'Salin Lokasi File'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clear All Data Confirmation Modal */}
      {showClearModal && (
        <div className="fixed inset-0 z-50 bg-on-surface/40 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-surface-container-lowest border border-outline-variant/40 rounded-2xl p-6 shadow-2xl">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-error/10 text-error flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h3 className="font-editorial text-xl text-on-surface font-semibold">
                  Kosongkan Seluruh Konten Website?
                </h3>
                <p className="text-xs text-secondary mt-1.5 leading-relaxed">
                  Tindakan ini akan mengosongkan seluruh entri catatan, brankas, daftar putar musik, penghargaan, hobi, tautan sosial, dan rincian profil ke kondisi bersih awal (0 item).
                </p>
              </div>
              <button
                onClick={() => setShowClearModal(false)}
                className="p-1 rounded-lg text-secondary hover:text-on-surface transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center justify-end gap-3 mt-6 pt-4 border-t border-outline-variant/20">
              <button
                type="button"
                onClick={() => setShowClearModal(false)}
                className="px-4 py-2 rounded-lg border border-outline-variant/50 hover:bg-surface-container text-xs font-medium text-secondary hover:text-on-surface transition-colors cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleClearAllData}
                disabled={isClearing}
                className="px-4 py-2 rounded-lg bg-error hover:bg-error/90 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{isClearing ? 'Mengosongkan...' : 'Ya, Kosongkan Semua'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
