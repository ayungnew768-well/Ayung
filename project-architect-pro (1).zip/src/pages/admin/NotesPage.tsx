import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { dataService, deduplicateById } from '../../services/dataService';
import { PrivateNote } from '../../types';
import {
  FileText,
  Plus,
  Search,
  Trash2,
  Edit3,
  Download,
  Printer,
  Check,
  Clock,
  Eye,
  FileCode,
  Lock,
  ArrowRight,
  Save,
  AlertTriangle,
  X
} from 'lucide-react';

export const NotesPage: React.FC = () => {
  const [notes, setNotes] = useState<PrivateNote[]>([]);
  const [selectedNote, setSelectedNote] = useState<PrivateNote | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeCategory, setActiveCategory] = useState<string>('All');

  // Editor states
  const [editTitle, setEditTitle] = useState<string>('');
  const [editCategory, setEditCategory] = useState<string>('Web');
  const [editContent, setEditContent] = useState<string>('');
  const [isPreviewMode, setIsPreviewMode] = useState<boolean>(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  const [isSavingManual, setIsSavingManual] = useState<boolean>(false);

  // Delete modal state
  const [deleteTarget, setDeleteTarget] = useState<PrivateNote | null>(null);

  const saveTimerRef = useRef<any>(null);

  const categories = ['All', 'Web', 'Sosmed', 'Aplikasi', 'Game', 'Ide Desain', 'Studio'];

  useEffect(() => {
    loadNotes();
    return () => {
      if (saveTimerRef.current) clearTimeout(saveTimerRef.current);
    };
  }, []);

  const loadNotes = async () => {
    setIsLoading(true);
    try {
      const data = await dataService.getPrivateNotes();
      const cleanData = deduplicateById(data);
      setNotes(cleanData);
      if (cleanData.length > 0) {
        selectNote(cleanData[0]);
      } else {
        setSelectedNote(null);
      }
    } catch (e) {
      console.error('Error loading notes:', e);
    } finally {
      setIsLoading(false);
    }
  };

  const selectNote = (note: PrivateNote) => {
    setSelectedNote(note);
    setEditTitle(note.title);
    setEditCategory(note.category || 'Web');
    setEditContent(note.content);
    setSaveStatus('saved');
  };

  // Debounced auto-save
  const triggerAutoSave = (newTitle: string, newCat: string, newCont: string) => {
    setSaveStatus('saving');
    clearTimeout(saveTimerRef.current);
    saveTimerRef.current = setTimeout(async () => {
      if (!selectedNote) return;
      try {
        const updated = await dataService.savePrivateNote({
          ...selectedNote,
          title: newTitle,
          category: newCat,
          content: newCont
        });
        setSelectedNote(updated);
        setNotes((prev) => {
          const map = new Map<string, PrivateNote>();
          prev.forEach((n) => map.set(n.id, n));
          map.set(updated.id, updated);
          return Array.from(map.values());
        });
        setSaveStatus('saved');
      } catch (err) {
        console.error('Autosave error:', err);
        setSaveStatus('idle');
      }
    }, 700);
  };

  // Manual save button handler
  const handleManualSave = async () => {
    if (!selectedNote) return;
    setIsSavingManual(true);
    setSaveStatus('saving');
    clearTimeout(saveTimerRef.current);

    try {
      const updated = await dataService.savePrivateNote({
        ...selectedNote,
        title: editTitle.trim() || 'Catatan Tanpa Judul',
        category: editCategory,
        content: editContent
      });
      setSelectedNote(updated);
      setNotes((prev) => {
        const map = new Map<string, PrivateNote>();
        prev.forEach((n) => map.set(n.id, n));
        map.set(updated.id, updated);
        return Array.from(map.values());
      });
      setSaveStatus('saved');
    } catch (err) {
      console.error('Manual save error:', err);
      setSaveStatus('idle');
    } finally {
      setIsSavingManual(false);
    }
  };

  const handleCreateNew = async () => {
    try {
      const newNote = await dataService.savePrivateNote({
        title: 'Catatan Baru',
        category: activeCategory !== 'All' ? activeCategory : 'Ide Desain',
        content: '# Catatan Baru\n\nTuliskan pemikiran, konsep, atau catatan penting di sini...'
      });
      setNotes((prev) => {
        const map = new Map<string, PrivateNote>();
        map.set(newNote.id, newNote);
        prev.forEach((n) => {
          if (n.id !== newNote.id) map.set(n.id, n);
        });
        return Array.from(map.values());
      });
      selectNote(newNote);
      setIsPreviewMode(false);
    } catch (err) {
      console.error('Error creating new note:', err);
    }
  };

  const confirmDeleteNote = async () => {
    if (!deleteTarget) return;
    const targetId = deleteTarget.id;
    try {
      await dataService.deletePrivateNote(targetId);
      const remaining = notes.filter((n) => n.id !== targetId);
      const cleanRemaining = deduplicateById(remaining);
      setNotes(cleanRemaining);

      if (selectedNote?.id === targetId) {
        if (cleanRemaining.length > 0) {
          selectNote(cleanRemaining[0]);
        } else {
          setSelectedNote(null);
          setEditTitle('');
          setEditContent('');
        }
      }
    } catch (err) {
      console.error('Error deleting note:', err);
    } finally {
      setDeleteTarget(null);
    }
  };

  const handleExportMarkdown = () => {
    if (!selectedNote) return;
    const blob = new Blob([editContent], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${editTitle.replace(/\s+/g, '_').toLowerCase()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportTxt = () => {
    if (!selectedNote) return;
    const blob = new Blob([`${editTitle}\n\n${editContent}`], { type: 'text/plain;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${editTitle.replace(/\s+/g, '_').toLowerCase()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredNotes = notes.filter((n) => {
    const matchesSearch =
      n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      n.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat =
      activeCategory === 'All' ||
      (n.category || '').toLowerCase() === activeCategory.toLowerCase();
    return matchesSearch && matchesCat;
  });

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-outline-variant/30">
        <div>
          <h1 className="font-editorial text-3xl text-on-surface">
            Catatan Pribadi &amp; Jurnal Studio
          </h1>
          <p className="text-xs text-secondary mt-1">
            Autosave otomatis • Ruang pencatatan ide harian dan rencana penting
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-surface-container text-xs font-mono">
            {saveStatus === 'saving' ? (
              <span className="text-secondary flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 animate-spin text-primary" />
                <span>Menyimpan...</span>
              </span>
            ) : (
              <span className="text-primary flex items-center gap-1 font-semibold">
                <Check className="w-3.5 h-3.5" />
                <span>✓ Tersimpan</span>
              </span>
            )}
          </div>

          <button
            onClick={handleCreateNew}
            className="px-4 py-2 bg-primary text-on-primary hover:bg-primary-container rounded-lg text-xs font-semibold flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Catatan Baru</span>
          </button>
        </div>
      </div>

      {/* Quick Nav Hub Banner: Notes & Vault */}
      <div className="p-4 rounded-xl bg-surface-container-low border border-outline-variant/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
            <Lock className="w-4 h-4" />
          </div>
          <div>
            <span className="font-semibold text-on-surface block">
              Membutuhkan brankas untuk kata sandi, token API, atau akun privat?
            </span>
            <span className="text-secondary">
              Gunakan Brankas Kredensial dengan enkripsi AES-256 dan kunci otomatis 5 menit.
            </span>
          </div>
        </div>

        <Link
          to="/admin/vault"
          className="px-3.5 py-1.5 rounded-lg bg-surface hover:bg-surface-container-high text-primary font-semibold flex items-center gap-1.5 transition-colors shrink-0 shadow-2xs"
        >
          <span>Akses Brankas Kredensial</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>

      {/* Filter Category Pills & Search Bar */}
      <div className="bg-surface-container-lowest p-4 rounded-xl border border-outline-variant/30 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-secondary absolute left-3 top-2.5 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari dalam catatan..."
            className="w-full pl-9 pr-4 py-2 bg-surface-container-low text-xs rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary text-on-surface"
          />
        </div>

        {/* Categories */}
        <div className="flex flex-wrap items-center gap-1.5">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3.5 py-1.5 text-xs rounded-lg font-medium transition-colors cursor-pointer ${
                activeCategory === cat
                  ? 'bg-primary text-on-primary font-semibold shadow-xs'
                  : 'bg-surface-container-low text-secondary hover:text-on-surface hover:bg-surface-container'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Main 2-Column Notes App Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-[580px]">
        {/* Left Column: Note List (4 cols) */}
        <div className="lg:col-span-4 bg-surface-container-lowest rounded-2xl border border-outline-variant/30 p-4 shadow-xs flex flex-col justify-between">
          <div className="space-y-2.5 max-h-[520px] overflow-y-auto pr-1">
            {isLoading ? (
              <div className="p-8 text-center text-xs text-secondary">
                <Clock className="w-5 h-5 animate-spin mx-auto mb-2 text-primary opacity-60" />
                Memuat catatan...
              </div>
            ) : filteredNotes.length === 0 ? (
              <div className="p-8 text-center bg-surface-container-low/40 rounded-xl border border-outline-variant/20">
                <FileText className="w-8 h-8 mx-auto text-outline/50 mb-2" />
                <p className="text-xs font-semibold text-on-surface">Tidak ada catatan</p>
                <p className="text-[11px] text-secondary mt-1">
                  {notes.length === 0
                    ? 'Belum ada catatan tersimpan.'
                    : 'Tidak ada catatan yang cocok dengan filter pencarian.'}
                </p>
                <button
                  onClick={handleCreateNew}
                  className="mt-3 px-3 py-1.5 bg-primary text-on-primary rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 hover:bg-primary-container transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Catatan Pertama</span>
                </button>
              </div>
            ) : (
              filteredNotes.map((note) => {
                const isSelected = selectedNote?.id === note.id;
                return (
                  <div
                    key={note.id}
                    onClick={() => selectNote(note)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer text-left group ${
                      isSelected
                        ? 'bg-primary/5 border-primary shadow-xs'
                        : 'bg-surface-container-low/40 border-outline-variant/30 hover:border-primary/40 hover:bg-surface-container-low/80'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="px-2 py-0.5 rounded-md bg-surface-container text-secondary text-[10px] font-semibold uppercase">
                        {note.category || 'Web'}
                      </span>
                      <span className="text-[10px] font-mono text-outline">
                        {note.updated_at
                          ? new Date(note.updated_at).toLocaleDateString('id-ID', {
                              day: 'numeric',
                              month: 'short'
                            })
                          : 'Baru'}
                      </span>
                    </div>

                    <h4 className="text-xs font-semibold text-on-surface truncate group-hover:text-primary transition-colors">
                      {note.title || 'Catatan Tanpa Judul'}
                    </h4>

                    <p className="text-[11px] text-secondary line-clamp-2 mt-1 leading-normal">
                      {note.content ? note.content.replace(/[#*`_]/g, '') : 'Catatan kosong...'}
                    </p>

                    {/* Explicit Action Buttons: Edit and Delete */}
                    <div className="mt-3 pt-2.5 border-t border-outline-variant/20 flex items-center justify-between gap-2">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          selectNote(note);
                          setIsPreviewMode(false);
                        }}
                        className="px-2.5 py-1 rounded-md text-[11px] font-medium bg-surface-container hover:bg-primary hover:text-on-primary text-on-surface transition-colors flex items-center gap-1.5 shadow-2xs"
                        title="Sunting catatan ini"
                      >
                        <Edit3 className="w-3 h-3 text-primary group-hover:text-inherit" />
                        <span>Sunting</span>
                      </button>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setDeleteTarget(note);
                        }}
                        className="px-2.5 py-1 rounded-md text-[11px] font-medium bg-surface-container hover:bg-error hover:text-white text-error transition-colors flex items-center gap-1.5 shadow-2xs"
                        title="Hapus catatan ini"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Hapus</span>
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <div className="pt-3 mt-2 border-t border-outline-variant/20 flex items-center justify-between text-[11px] text-secondary">
            <span>{notes.length} Catatan tersimpan</span>
            <span className="flex items-center gap-1 text-primary font-medium">
              <Check className="w-3 h-3" />
              <span>Privat &amp; Terlindungi</span>
            </span>
          </div>
        </div>

        {/* Right Column: Note Editor & Markdown Preview (8 cols) */}
        <div className="lg:col-span-8 bg-surface-container-lowest rounded-2xl border border-outline-variant/30 p-6 shadow-xs flex flex-col justify-between">
          {selectedNote ? (
            <div className="flex-1 flex flex-col">
              {/* Note Header & Actions */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-outline-variant/20 mb-4">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-md bg-primary/10 text-primary text-xs font-semibold">
                    {editCategory}
                  </span>
                  <div className="flex items-center gap-1 text-xs text-secondary font-mono">
                    <Clock className="w-3 h-3" />
                    <span>
                      {saveStatus === 'saving' ? 'Menyimpan...' : 'Tersimpan otomatis'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {/* Explicit Manual Save Button */}
                  <button
                    type="button"
                    onClick={handleManualSave}
                    disabled={isSavingManual}
                    className="px-3.5 py-1.5 rounded-lg bg-primary text-on-primary hover:bg-primary-container text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                    title="Simpan perubahan sekarang"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{isSavingManual ? 'Menyimpan...' : 'Simpan'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsPreviewMode(!isPreviewMode)}
                    className="px-2.5 py-1.5 rounded-lg border border-outline-variant/40 hover:bg-surface-container text-xs text-on-surface flex items-center gap-1 transition-colors cursor-pointer"
                    title={isPreviewMode ? 'Mode Editor' : 'Pratinjau Markdown'}
                  >
                    {isPreviewMode ? <Edit3 className="w-3.5 h-3.5 text-primary" /> : <Eye className="w-3.5 h-3.5" />}
                    <span>{isPreviewMode ? 'Edit' : 'Pratinjau'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleExportMarkdown}
                    className="p-1.5 rounded-lg text-secondary hover:text-on-surface hover:bg-surface-container transition-colors cursor-pointer"
                    title="Ekspor ke Markdown (.md)"
                  >
                    <Download className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={handleExportTxt}
                    className="p-1.5 rounded-lg text-secondary hover:text-on-surface hover:bg-surface-container transition-colors cursor-pointer"
                    title="Ekspor ke Teks (.txt)"
                  >
                    <FileCode className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => window.print()}
                    className="p-1.5 rounded-lg text-secondary hover:text-on-surface hover:bg-surface-container transition-colors cursor-pointer"
                    title="Cetak Catatan (Print/PDF)"
                  >
                    <Printer className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => setDeleteTarget(selectedNote)}
                    className="p-1.5 rounded-lg text-error hover:bg-error-container transition-colors cursor-pointer"
                    title="Hapus Catatan Ini"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Title & Category Selector */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
                <div className="sm:col-span-2">
                  <input
                    type="text"
                    value={editTitle || ''}
                    onChange={(e) => {
                      setEditTitle(e.target.value);
                      triggerAutoSave(e.target.value, editCategory, editContent);
                    }}
                    placeholder="Judul Catatan..."
                    className="w-full text-lg sm:text-xl font-editorial font-semibold text-on-surface bg-transparent border-b border-outline-variant/40 pb-1 focus:outline-none focus:border-primary"
                  />
                </div>
                <div>
                  <select
                    value={editCategory || 'Ide Desain'}
                    onChange={(e) => {
                      setEditCategory(e.target.value);
                      triggerAutoSave(editTitle, e.target.value, editContent);
                    }}
                    className="w-full px-2.5 py-1.5 bg-surface-container-low text-xs rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary text-on-surface"
                  >
                    <option value="Web">Web</option>
                    <option value="Sosmed">Sosmed</option>
                    <option value="Aplikasi">Aplikasi</option>
                    <option value="Game">Game</option>
                    <option value="Ide Desain">Ide Desain</option>
                    <option value="Studio">Filosofi Studio</option>
                  </select>
                </div>
              </div>

              {/* Editor / Markdown Preview Viewport */}
              <div className="flex-1 min-h-[360px]">
                {isPreviewMode ? (
                  <div className="p-4 rounded-xl bg-surface-container-low/50 min-h-[360px] max-w-none text-on-surface leading-relaxed overflow-y-auto font-sans whitespace-pre-wrap text-sm border border-outline-variant/20">
                    {editContent ? (
                      editContent
                    ) : (
                      <span className="text-secondary italic">Catatan masih kosong...</span>
                    )}
                  </div>
                ) : (
                  <textarea
                    rows={14}
                    value={editContent || ''}
                    onChange={(e) => {
                      setEditContent(e.target.value);
                      triggerAutoSave(editTitle, editCategory, e.target.value);
                    }}
                    placeholder="Tuliskan isi catatan harian, rencana, atau draft pemikiran Anda di sini..."
                    className="w-full h-full min-h-[360px] p-4 bg-surface-container-low/40 rounded-xl text-sm font-mono text-on-surface leading-relaxed border border-outline-variant/30 focus:outline-none focus:border-primary resize-y"
                  />
                )}
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-secondary">
              <FileText className="w-12 h-12 text-outline mb-2 opacity-50" />
              <p className="font-editorial text-lg text-on-surface">Pilih atau buat catatan baru</p>
              <p className="text-xs text-secondary mt-1 max-w-sm">
                Catatan Anda tersimpan aman dan terenkripsi secara privat di browser dan database cloud.
              </p>
              <button
                onClick={handleCreateNew}
                className="mt-4 px-4 py-2 bg-primary text-on-primary rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 hover:bg-primary-container transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ Buat Catatan Baru</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Delete Confirmation Modal (In-App, No window.confirm) */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 bg-on-surface/40 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-surface-container-lowest border border-outline-variant/40 rounded-2xl p-6 shadow-2xl">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-error/10 text-error flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h3 className="font-editorial text-xl text-on-surface font-semibold">
                  Hapus Catatan?
                </h3>
                <p className="text-xs text-secondary mt-1.5 leading-relaxed">
                  Apakah Anda yakin ingin menghapus catatan{' '}
                  <strong className="text-on-surface font-semibold">
                    "{deleteTarget.title}"
                  </strong>
                  ? Catatan ini akan dihapus secara permanen dari penyimpanan.
                </p>
              </div>
              <button
                onClick={() => setDeleteTarget(null)}
                className="p-1 rounded-lg text-secondary hover:text-on-surface transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center justify-end gap-3 mt-6 pt-4 border-t border-outline-variant/20">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 rounded-lg border border-outline-variant/50 hover:bg-surface-container text-xs font-medium text-secondary hover:text-on-surface transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={confirmDeleteNote}
                className="px-4 py-2 rounded-lg bg-error hover:bg-error/90 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Hapus Permanen</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
