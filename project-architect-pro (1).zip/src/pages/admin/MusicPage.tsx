import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { dataService } from '../../services/dataService';
import { MusicTrack } from '../../types';
import { useAudioPlayer } from '../../context/AudioPlayerContext';
import {
  Headphones,
  Plus,
  Play,
  Pause,
  Edit2,
  Trash2,
  Disc,
  ExternalLink,
  Eye,
  EyeOff,
  Radio,
  Video,
  Music,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { extractYouTubeId, getYouTubeThumbnail } from '../../lib/youtube';

export const MusicPage: React.FC = () => {
  const [tracks, setTracks] = useState<MusicTrack[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editingTrack, setEditingTrack] = useState<Partial<MusicTrack> | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [formError, setFormError] = useState<string>('');

  const { playTrack, currentTrack, isPlaying, togglePlay, reloadTracks } = useAudioPlayer();

  useEffect(() => {
    loadTracks();
  }, []);

  const loadTracks = async () => {
    setIsLoading(true);
    try {
      const data = await dataService.getMusicTracks(false);
      setTracks(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpenAdd = () => {
    setEditingTrack({
      title: '',
      artist: 'Syahrul Gunawan',
      audio_source_type: 'youtube',
      duration: '03:45',
      youtube_url: '',
      cover_path: '',
      is_published: true,
      display_order: tracks.length + 1
    });
    setShowModal(true);
  };

  const handleOpenEdit = (t: MusicTrack) => {
    setEditingTrack({ ...t });
    setShowModal(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTrack || !editingTrack.title?.trim()) return;

    setIsSubmitting(true);
    try {
      // Auto-compute thumbnail from youtube_url if empty
      const computedCover =
        editingTrack.cover_path ||
        (editingTrack.youtube_url ? getYouTubeThumbnail(editingTrack.youtube_url) : '');

      await dataService.saveMusicTrack({
        ...editingTrack,
        cover_path: computedCover
      });
      await loadTracks();
      await reloadTracks();
      setShowModal(false);
      setEditingTrack(null);
    } catch (err: any) {
      setFormError(err?.message || 'Gagal menyimpan trek musik ke database.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteConfirmId) return;
    try {
      await dataService.deleteMusicTrack(deleteConfirmId);
      setTracks((prev) => prev.filter((t) => t.id !== deleteConfirmId));
      await reloadTracks();
      setDeleteConfirmId(null);
    } catch (err: any) {
      console.error('Delete track error:', err);
      setDeleteConfirmId(null);
    }
  };

  const handleTogglePublish = async (track: MusicTrack) => {
    try {
      const updated = await dataService.saveMusicTrack({
        ...track,
        is_published: !track.is_published
      });
      setTracks((prev) => prev.map((t) => (t.id === track.id ? updated : t)));
      await reloadTracks();
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-outline-variant/30">
        <div>
          <h1 className="font-editorial text-2xl sm:text-3xl text-on-surface">
            Kurasi Musik &amp; Audio Latar
          </h1>
          <p className="text-xs text-secondary mt-1">
            Atur daftar lagu, sumber audio latar, dan uji coba pemutar audio interaktif situs Syahrul Gunawan.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <Link
            to="/music"
            target="_blank"
            className="px-3.5 py-2 rounded-lg border border-outline-variant/60 hover:bg-surface-container text-xs font-semibold text-primary flex items-center gap-1.5 transition-colors shadow-2xs"
          >
            <Headphones className="w-3.5 h-3.5" />
            <span>Pratinjau Pemutar</span>
          </Link>

          <button
            onClick={handleOpenAdd}
            className="px-4 py-2 bg-primary text-on-primary hover:bg-primary-container rounded-lg text-xs font-semibold flex items-center gap-2 shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah Lagu Baru</span>
          </button>
        </div>
      </div>

      {/* Main Track Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Track List Column */}
        <div className="lg:col-span-2 space-y-3">
          {tracks.map((track, idx) => {
            const isCurrent = currentTrack?.id === track.id;
            const isCurrentPlaying = isCurrent && isPlaying;
            const isYouTube =
              track.audio_source_type === 'youtube' ||
              Boolean(track.youtube_url && extractYouTubeId(track.youtube_url));
            const thumbnail =
              track.cover_path ||
              (isYouTube && track.youtube_url ? getYouTubeThumbnail(track.youtube_url) : '');

            return (
              <div
                key={`${track.id}-${idx}`}
                className={`p-4 rounded-xl border transition-all bg-surface-container-lowest flex items-center justify-between gap-4 ${
                  isCurrent
                    ? 'border-primary ring-1 ring-primary/30 shadow-xs'
                    : 'border-outline-variant/30 hover:border-primary/40'
                } ${!track.is_published ? 'opacity-60 border-dashed' : ''}`}
              >
                <div className="flex items-center gap-3.5 min-w-0 flex-1">
                  {/* Play Button & Thumbnail */}
                  <div className="relative w-12 h-12 rounded-xl bg-surface-container overflow-hidden shrink-0 border border-outline-variant/30 flex items-center justify-center group shadow-2xs">
                    {thumbnail ? (
                      <img
                        src={thumbnail}
                        alt={track.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                    ) : isYouTube ? (
                      <Video className="w-6 h-6 text-rose-500" />
                    ) : (
                      <Disc
                        className={`w-6 h-6 text-primary ${
                          isCurrentPlaying ? 'animate-spin' : ''
                        }`}
                      />
                    )}

                    <button
                      onClick={() => {
                        if (isCurrent) {
                          togglePlay();
                        } else {
                          playTrack(track);
                        }
                      }}
                      className="absolute inset-0 bg-black/40 hover:bg-black/60 flex items-center justify-center text-white transition-opacity active:scale-95"
                      title={isCurrentPlaying ? 'Jeda' : 'Putar'}
                    >
                      {isCurrentPlaying ? (
                        <Pause className="w-5 h-5 fill-white" />
                      ) : (
                        <Play className="w-5 h-5 fill-white ml-0.5" />
                      )}
                    </button>
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="font-mono text-xs text-outline">#{idx + 1}</span>
                      {isYouTube ? (
                        <span className="px-2 py-0.2 rounded-full bg-rose-50 text-rose-700 text-[10px] font-mono font-bold uppercase border border-rose-200">
                          YOUTUBE
                        </span>
                      ) : (
                        <span className="px-2 py-0.2 rounded-full bg-emerald-50 text-emerald-800 text-[10px] font-mono font-bold uppercase border border-emerald-200">
                          {track.audio_source_type}
                        </span>
                      )}
                      {!track.is_published && (
                        <span className="px-2 py-0.2 rounded bg-error-container text-on-error-container text-[10px] font-semibold">
                          Draf
                        </span>
                      )}
                    </div>
                    <h3 className="font-editorial text-base text-on-surface font-medium truncate">
                      {track.title}
                    </h3>
                    <p className="text-xs text-secondary truncate">{track.artist}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-xs font-mono text-secondary hidden sm:inline-block">
                    {track.duration}
                  </span>
                  <button
                    onClick={() => handleTogglePublish(track)}
                    className="p-1.5 rounded-lg text-secondary hover:text-on-surface hover:bg-surface-container transition-colors"
                    title={track.is_published ? 'Sembunyikan' : 'Publikasikan'}
                  >
                    {track.is_published ? <Eye className="w-4 h-4 text-primary" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => handleOpenEdit(track)}
                    className="p-1.5 rounded-lg text-secondary hover:text-on-surface hover:bg-surface-container transition-colors"
                    title="Edit"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setDeleteConfirmId(track.id)}
                    className="p-1.5 rounded-lg text-error hover:bg-error-container transition-colors"
                    title="Hapus"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Live Audio Test Player Panel */}
        <div className="bg-surface-container-lowest p-6 rounded-2xl border border-outline-variant/30 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-[11px] font-mono uppercase tracking-widest text-secondary font-semibold">
                Uji Coba Suara Nyata
              </span>
              <span className="flex items-center gap-1 text-[11px] text-primary font-semibold">
                <Radio className="w-3.5 h-3.5" />
                <span>Pemutar Aktif</span>
              </span>
            </div>

            <div className="w-full aspect-video rounded-xl bg-surface-container flex flex-col items-center justify-center border border-outline-variant/30 mb-4 text-center p-4 overflow-hidden relative shadow-inner">
              {currentTrack?.cover_path ? (
                <img
                  src={currentTrack.cover_path}
                  alt={currentTrack.title}
                  className="w-full h-full object-cover rounded-lg"
                />
              ) : (
                <>
                  <Disc
                    className={`w-12 h-12 text-primary mb-2 ${
                      isPlaying ? 'animate-spin' : ''
                    }`}
                    style={{ animationDuration: '4s' }}
                  />
                  <p className="font-editorial text-lg text-on-surface font-semibold truncate w-full">
                    {currentTrack?.title || 'Belum Ada Lagu Dipilih'}
                  </p>
                  <p className="text-xs text-secondary truncate w-full">
                    {currentTrack?.artist || 'Pilih lagu untuk menguji'}
                  </p>
                </>
              )}
            </div>

            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-surface-container-low text-xs text-secondary leading-relaxed">
                <span className="font-semibold text-on-surface block mb-1">
                  Karakteristik Audio &amp; Video:
                </span>
                Trek dengan sumber YouTube memutar video resmi secara otomatis di halaman publik, sedangkan sumber ambient memainkan osilator harmonik meditasi.
              </div>

              {currentTrack?.youtube_url && (
                <a
                  href={currentTrack.youtube_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2 px-3 rounded-lg border border-outline-variant/40 text-xs text-secondary hover:text-primary flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span>Buka Video Resmi di YouTube</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
            </div>
          </div>

          <div className="pt-4 mt-4 border-t border-outline-variant/20">
            <button
              onClick={togglePlay}
              className="w-full py-2.5 bg-primary text-on-primary rounded-lg text-xs font-semibold hover:bg-primary-container flex items-center justify-center gap-2 shadow-xs transition-all"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isPlaying ? 'Jeda Pemutar' : 'Putar Audio'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Add / Edit Modal */}
      {showModal && editingTrack && (
        <div className="fixed inset-0 z-50 bg-on-surface/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-surface-container-lowest max-w-md w-full rounded-2xl p-6 shadow-xl border border-outline-variant/40 max-h-[90vh] overflow-y-auto">
            <h3 className="font-editorial text-2xl text-on-surface font-semibold mb-4">
              {editingTrack.id ? 'Sunting Trek Musik' : 'Tambah Trek Musik Baru'}
            </h3>

            <form onSubmit={handleSave} className="space-y-4">
              {formError && (
                <div className="p-3 bg-error-container/60 border border-error/30 text-error text-xs rounded-xl flex items-center gap-2">
                  <span>{formError}</span>
                </div>
              )}
              <div>
                <label className="block text-xs font-semibold text-secondary mb-1">
                  Judul Lagu *
                </label>
                <input
                  type="text"
                  required
                  value={editingTrack.title || ''}
                  onChange={(e) => setEditingTrack({ ...editingTrack, title: e.target.value })}
                  placeholder="Misal: TEH HIJAU, Sore Santai di Senayan"
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-secondary mb-1">
                  Nama Artis &amp; Keterangan *
                </label>
                <input
                  type="text"
                  required
                  value={editingTrack.artist || ''}
                  onChange={(e) => setEditingTrack({ ...editingTrack, artist: e.target.value })}
                  placeholder="Misal: TULUS • YouTube Video"
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-secondary mb-1">
                    Sumber Audio
                  </label>
                  <select
                    value={editingTrack.audio_source_type || 'youtube'}
                    onChange={(e) =>
                      setEditingTrack({
                        ...editingTrack,
                        audio_source_type: e.target.value as any
                      })
                    }
                    className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary"
                  >
                    <option value="youtube">Tautan YouTube Video</option>
                    <option value="ambient">Ambient Synthesizer</option>
                    <option value="url">Direct Audio URL</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-secondary mb-1">
                    Durasi (MM:SS)
                  </label>
                  <input
                    type="text"
                    value={editingTrack.duration || '03:45'}
                    onChange={(e) => setEditingTrack({ ...editingTrack, duration: e.target.value })}
                    placeholder="03:45"
                    className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-secondary mb-1">
                  Tautan YouTube (Wajib jika sumber YouTube)
                </label>
                <input
                  type="url"
                  value={editingTrack.youtube_url || ''}
                  onChange={(e) => {
                    const url = e.target.value;
                    const thumb = getYouTubeThumbnail(url);
                    setEditingTrack({
                      ...editingTrack,
                      youtube_url: url,
                      cover_path: thumb || editingTrack.cover_path
                    });
                  }}
                  placeholder="https://www.youtube.com/watch?v=..."
                  className="w-full px-3.5 py-2 bg-surface-container-low text-on-surface text-sm rounded-lg border border-outline-variant/40 focus:outline-none focus:border-primary font-mono"
                />
                {editingTrack.youtube_url && extractYouTubeId(editingTrack.youtube_url) && (
                  <p className="text-[11px] text-primary mt-1 font-mono">
                    ✓ Video ID terdeteksi: {extractYouTubeId(editingTrack.youtube_url)}
                  </p>
                )}
              </div>

              <div className="pt-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingTrack.is_published ?? true}
                    onChange={(e) =>
                      setEditingTrack({ ...editingTrack, is_published: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-primary focus:ring-primary accent-primary"
                  />
                  <span className="text-xs text-on-surface">Aktifkan untuk pemutar publik</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-outline-variant/20">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-xs text-secondary hover:text-on-surface"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-primary text-on-primary rounded-lg text-xs font-semibold hover:bg-primary-container disabled:opacity-50"
                >
                  {isSubmitting ? 'Menyimpan...' : 'Simpan Trek'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 bg-on-surface/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-surface-container-lowest max-w-sm w-full rounded-2xl p-6 shadow-xl border border-outline-variant/40">
            <h3 className="font-editorial text-xl text-on-surface font-semibold mb-2">
              Hapus Trek Musik
            </h3>
            <p className="text-xs text-secondary leading-relaxed mb-4">
              Apakah Anda yakin ingin menghapus lagu ini dari kurasi audio?
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 text-xs text-secondary hover:text-on-surface"
              >
                Batal
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-error text-on-error rounded-lg text-xs font-semibold hover:opacity-90"
              >
                Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
