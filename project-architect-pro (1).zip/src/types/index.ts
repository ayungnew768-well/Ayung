export interface Profile {
  id: string;
  firebase_uid: string;
  display_name: string;
  username: string;
  headline: string;
  biography: string;
  birth_date?: string;
  location: string;
  profile_photo_path: string;
  email_public: string;
  created_at?: string;
  updated_at?: string;
}

export interface ProfileDetail {
  id: string;
  profile_id: string;
  section_type: 'personal' | 'education' | 'expertise' | 'status' | 'meta';
  title: string;
  content: string;
  display_order: number;
  is_published: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface Achievement {
  id: string;
  profile_id?: string;
  title: string;
  description: string;
  category: string;
  institution: string;
  achievement_date: string;
  image_path?: string;
  document_path?: string;
  is_published: boolean;
  display_order: number;
  created_at?: string;
  updated_at?: string;
}

export interface Hobby {
  id: string;
  profile_id?: string;
  name: string;
  description: string;
  icon: string;
  image_path?: string;
  display_order: number;
  is_published: boolean;
}

export interface MusicTrack {
  id: string;
  profile_id?: string;
  title: string;
  artist: string;
  audio_source_type: 'ambient' | 'upload' | 'youtube' | 'url';
  audio_url?: string;
  audio_storage_path?: string;
  cover_path?: string;
  youtube_url?: string;
  duration: string;
  display_order: number;
  is_published: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface SocialLink {
  id: string;
  profile_id?: string;
  title: string;
  label: string;
  url: string;
  category: 'Web' | 'Sosmed' | 'Aplikasi' | 'Game' | string;
  platform?: 'instagram' | 'tiktok' | 'youtube' | 'linkedin' | 'github' | 'website' | 'other' | string;
  description?: string;
  icon?: string;
  display_order: number;
  is_published: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface PrivateNote {
  id: string;
  owner_uid: string;
  title: string;
  content: string;
  category: string;
  is_private: boolean;
  is_archived: boolean;
  created_at: string;
  updated_at: string;
}

export interface VaultItem {
  id: string;
  owner_uid: string;
  title: string;
  category: 'Web' | 'Sosmed' | 'Aplikasi' | 'Game' | string;
  identity_type: 'Email' | 'Username' | 'Gmail' | 'No. HP' | 'Lainnya' | string;
  identity_value: string;
  credential_type: 'Password' | 'PIN' | 'Token API' | 'Kunci Rahasia' | string;
  encrypted_payload: string; // Base64 ciphertext with IV and Salt
  encryption_version: string;
  notes?: string;
  created_at: string;
  updated_at: string;
  // Decrypted values (in memory only when vault is unlocked)
  secret_value?: string;
}

export interface DonationSettings {
  id: string;
  profile_id?: string;
  enabled: boolean;
  title: string;
  description: string;
  qris_image_path?: string;
  donation_url: string;
  display_order: number;
  updated_at?: string;
}

export interface ActiveSession {
  id: string;
  device_name: string;
  browser: string;
  location: string;
  ip_address: string;
  last_active: string;
  is_current: boolean;
}

export interface ConnectionStatus {
  firebaseConfigured: boolean;
  firebaseConnected: boolean;
  supabaseConfigured: boolean;
  supabaseConnected: boolean;
  tablesMissing?: boolean;
  storageBucketsReady: boolean;
  lastChecked: string;
  message?: string;
}
