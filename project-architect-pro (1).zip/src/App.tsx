import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { AudioPlayerProvider } from './context/AudioPlayerContext';
import { FloatingAudioPlayer } from './components/FloatingAudioPlayer';

// Pages
import { HomePage } from './pages/public/HomePage';
import { MusicPlayerPage } from './pages/public/MusicPlayerPage';
import { AdminLogin } from './pages/admin/AdminLogin';
import { AdminLayout } from './layouts/AdminLayout';
import { DashboardPage } from './pages/admin/DashboardPage';
import { ProfileEditorPage } from './pages/admin/ProfileEditorPage';
import { AchievementsPage } from './pages/admin/AchievementsPage';
import { MusicPage } from './pages/admin/MusicPage';
import { LinksPage } from './pages/admin/LinksPage';
import { NotesPage } from './pages/admin/NotesPage';
import { VaultPage } from './pages/admin/VaultPage';
import { NotesVaultHub } from './pages/admin/NotesVaultHub';
import { DonationPage } from './pages/admin/DonationPage';
import { SecurityPage } from './pages/admin/SecurityPage';

export function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AudioPlayerProvider>
          {/* Top Floating Ambient Player */}
          <FloatingAudioPlayer />

          <Routes>
            {/* Area Publik */}
            <Route path="/" element={<HomePage />} />
            <Route path="/music" element={<MusicPlayerPage />} />
            <Route path="/login" element={<AdminLogin />} />

            {/* Area Admin Terproteksi */}
            <Route path="/admin" element={<AdminLayout />}>
              <Route index element={<DashboardPage />} />
              <Route path="profile" element={<ProfileEditorPage />} />
              <Route path="achievements" element={<AchievementsPage />} />
              <Route path="music" element={<MusicPage />} />
              <Route path="links" element={<LinksPage />} />
              <Route path="privacy-hub" element={<NotesVaultHub />} />
              <Route path="notes" element={<NotesPage />} />
              <Route path="vault" element={<VaultPage />} />
              <Route path="donations" element={<DonationPage />} />
              <Route path="security" element={<SecurityPage />} />
            </Route>

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </AudioPlayerProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
