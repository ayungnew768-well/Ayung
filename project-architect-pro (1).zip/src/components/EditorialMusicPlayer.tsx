import React, { useState } from 'react';
import { useAudioPlayer } from '../context/AudioPlayerContext';
import { MusicTrack } from '../types';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  ExternalLink,
  Video,
  Disc,
  Music,
  Radio,
  Volume2,
  VolumeX,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import {
  extractYouTubeId,
  getYouTubeThumbnail,
  getYouTubeEmbedUrl,
  formatSecondsToTime
} from '../lib/youtube';

interface EditorialMusicPlayerProps {
  className?: string;
}

export const EditorialMusicPlayer: React.FC<EditorialMusicPlayerProps> = ({ className = '' }) => {
  const {
    tracks,
    currentTrack,
    currentTrackIndex,
    isPlaying,
    currentTime,
    duration,
    volume,
    audioError,
    playTrack,
    togglePlay,
    playNext,
    playPrev,
    seekTo,
    setVolume,
    setIsPlayingState
  } = useAudioPlayer();

  const [activeTab, setActiveTab] = useState<'all' | 'youtube' | 'ambient'>('all');

  if (tracks.length === 0) {
    return (
      <div className="w-full p-8 rounded-2xl bg-surface-container-lowest border border-outline-variant/30 text-center text-secondary text-sm">
        Belum ada trek musik yang tersedia dalam daftar putar.
      </div>
    );
  }

  const track = currentTrack || tracks[0];
  const isYouTube =
    track.audio_source_type === 'youtube' ||
    Boolean(track.youtube_url && extractYouTubeId(track.youtube_url));
  const youtubeId = extractYouTubeId(track.youtube_url);
  const embedUrl = isYouTube ? getYouTubeEmbedUrl(track.youtube_url, isPlaying) : null;
  const thumbnail =
    track.cover_path ||
    (isYouTube && track.youtube_url ? getYouTubeThumbnail(track.youtube_url) : '');

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  const filteredPlaylist = tracks.filter((t) => {
    if (activeTab === 'youtube') {
      return t.audio_source_type === 'youtube' || Boolean(t.youtube_url && extractYouTubeId(t.youtube_url));
    }
    if (activeTab === 'ambient') {
      return t.audio_source_type === 'ambient';
    }
    return true;
  });

  return (
    <div className={`space-y-6 w-full ${className}`}>
      {/* =========================================================================
          CARD 1: PLAYER HERO CONTAINER (MATCHING GAMBAR PERTAMA)
         ========================================================================= */}
      <div className="w-full bg-surface-container-lowest border border-outline-variant/40 rounded-3xl p-4 sm:p-6 shadow-sm">
        {/* Media Screen Viewport (YouTube Video / Vinyl Disc) */}
        <div className="relative w-full aspect-video rounded-2xl overflow-hidden bg-black border border-outline-variant/30 shadow-inner group">
          {isYouTube && embedUrl ? (
            isPlaying ? (
              <iframe
                src={embedUrl}
                title={track.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="w-full h-full border-0"
              />
            ) : (
              /* High-Quality Thumbnail Screen with Big Red Play Button */
              <div
                onClick={() => setIsPlayingState(true)}
                className="relative w-full h-full cursor-pointer overflow-hidden flex items-center justify-center"
              >
                {thumbnail ? (
                  <img
                    src={thumbnail}
                    alt={track.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90"
                  />
                ) : (
                  <div className="w-full h-full bg-gradient-to-br from-neutral-900 to-neutral-800 flex items-center justify-center">
                    <Video className="w-16 h-16 text-neutral-600" />
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-black/40 flex flex-col justify-between p-4">
                  {/* Top Bar with Artist & Title Overlay */}
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-surface-container-high/60 backdrop-blur-md flex items-center justify-center overflow-hidden border border-white/20">
                      <img
                        src="/assets/syahrul_portrait.png"
                        alt="Syahrul Gunawan"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="text-left">
                      <p className="text-white text-xs font-semibold drop-shadow-md truncate">
                        {track.title}
                      </p>
                      <p className="text-white/80 text-[10px] drop-shadow-sm truncate">
                        {track.artist}
                      </p>
                    </div>
                  </div>

                  {/* Big YouTube Style Play Button in Center */}
                  <div className="self-center">
                    <div className="w-16 h-11 bg-red-600 hover:bg-red-700 text-white rounded-2xl flex items-center justify-center shadow-2xl transition-transform group-hover:scale-110">
                      <Play className="w-6 h-6 fill-white ml-0.5" />
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="font-mono text-[10px] text-white/90 bg-black/60 px-2 py-0.5 rounded backdrop-blur-xs">
                      {track.duration}
                    </span>
                  </div>
                </div>
              </div>
            )
          ) : (
            /* Ambient Synthesizer Screen */
            <div className="relative w-full h-full bg-gradient-to-br from-[#1C3623] via-[#254E31] to-[#122417] flex flex-col items-center justify-center p-6 text-center text-white">
              <div className="relative mb-3">
                <Disc
                  className={`w-16 h-16 text-emerald-300 ${isPlaying ? 'animate-spin' : ''}`}
                  style={{ animationDuration: '4s' }}
                />
                <span className="absolute inset-0 flex items-center justify-center">
                  <span className="w-3.5 h-3.5 rounded-full bg-emerald-950 border border-emerald-300"></span>
                </span>
              </div>
              <h4 className="font-editorial text-xl sm:text-2xl font-medium tracking-tight text-white mb-1">
                {track.title}
              </h4>
              <p className="text-emerald-200 text-xs font-sans">
                {track.artist}
              </p>
              <div className="mt-3 flex items-center gap-1.5 text-[10px] text-emerald-300 font-mono bg-white/10 px-3 py-1 rounded-full backdrop-blur-xs">
                <Sparkles className="w-3 h-3 text-emerald-200" />
                <span>Harmonic Ambient Synthesizer (Studio Karsa)</span>
              </div>
            </div>
          )}
        </div>

        {/* Error notification if audio failed */}
        {audioError && (
          <div className="mt-3 p-3 rounded-xl bg-error-container text-on-error-container text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{audioError}</span>
          </div>
        )}

        {/* Metadata Row: Badge + Track Counter + External Link */}
        <div className="flex items-center justify-between mt-4">
          <div className="flex items-center gap-3">
            {isYouTube ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-50 text-rose-700 border border-rose-200 text-xs font-semibold">
                <Video className="w-3.5 h-3.5" />
                <span>YouTube Video</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold">
                <Radio className="w-3.5 h-3.5" />
                <span>Audio Latar Ambient</span>
              </span>
            )}
            <span className="text-xs font-sans text-secondary">
              Track {currentTrackIndex + 1} dari {tracks.length}
            </span>
          </div>

          {track.youtube_url && (
            <a
              href={track.youtube_url}
              target="_blank"
              rel="noopener noreferrer"
              className="w-8 h-8 rounded-lg border border-outline-variant/50 hover:bg-surface-container flex items-center justify-center text-secondary hover:text-primary transition-colors"
              title="Buka Video Resmi"
            >
              <ExternalLink className="w-4 h-4" />
            </a>
          )}
        </div>

        {/* Track Title & Artist */}
        <div className="mt-3 text-left">
          <h3 className="font-sans font-bold text-xl sm:text-2xl text-on-surface uppercase tracking-tight">
            {track.title}
          </h3>
          <p className="text-xs text-secondary mt-0.5 font-medium">
            {track.artist}
          </p>
        </div>

        {/* Scrubber Progress Bar */}
        <div className="mt-4">
          <div
            onClick={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              const percent = (e.clientX - rect.left) / rect.width;
              seekTo(Math.max(0, Math.min(1, percent)));
            }}
            className="w-full bg-surface-container h-2 rounded-full overflow-hidden cursor-pointer relative"
          >
            <div
              className="bg-primary h-full rounded-full transition-all duration-150"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
          <div className="flex items-center justify-between mt-1.5 text-xs text-secondary font-mono">
            <span>{formatSecondsToTime(currentTime)}</span>
            <span>{formatSecondsToTime(duration)}</span>
          </div>
        </div>

        {/* Navigation Action Buttons Row (Sebelumnya, Play/Pause, Selanjutnya) */}
        <div className="flex items-center justify-between mt-5 pt-4 border-t border-outline-variant/20">
          <button
            onClick={playPrev}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-secondary hover:text-on-surface hover:bg-surface-container transition-colors"
          >
            <SkipBack className="w-4 h-4" />
            <span>Sebelumnya</span>
          </button>

          <button
            onClick={togglePlay}
            className="w-12 h-12 rounded-full bg-primary text-on-primary flex items-center justify-center hover:bg-primary-container shadow-sm transition-transform active:scale-95"
            aria-label={isPlaying ? 'Jeda' : 'Putar'}
          >
            {isPlaying ? (
              <Pause className="w-5 h-5" />
            ) : (
              <Play className="w-5 h-5 ml-0.5" />
            )}
          </button>

          <button
            onClick={playNext}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-secondary hover:text-on-surface hover:bg-surface-container transition-colors"
          >
            <span>Selanjutnya</span>
            <SkipForward className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* =========================================================================
          CARD 2: DAFTAR PUTAR (PLAYLIST) (MATCHING GAMBAR PERTAMA)
         ========================================================================= */}
      <div className="w-full bg-surface-container-lowest border border-outline-variant/40 rounded-3xl p-5 sm:p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-sans font-bold text-sm text-on-surface uppercase tracking-wider">
            DAFTAR PUTAR ({filteredPlaylist.length})
          </h3>

          <div className="flex items-center gap-1 bg-surface-container-low p-1 rounded-lg">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-2.5 py-1 text-[11px] rounded-md transition-colors ${
                activeTab === 'all'
                  ? 'bg-surface-container-lowest text-primary font-semibold shadow-2xs'
                  : 'text-secondary hover:text-on-surface'
              }`}
            >
              Semua
            </button>
            <button
              onClick={() => setActiveTab('youtube')}
              className={`px-2.5 py-1 text-[11px] rounded-md transition-colors ${
                activeTab === 'youtube'
                  ? 'bg-surface-container-lowest text-primary font-semibold shadow-2xs'
                  : 'text-secondary hover:text-on-surface'
              }`}
            >
              YouTube
            </button>
            <button
              onClick={() => setActiveTab('ambient')}
              className={`px-2.5 py-1 text-[11px] rounded-md transition-colors ${
                activeTab === 'ambient'
                  ? 'bg-surface-container-lowest text-primary font-semibold shadow-2xs'
                  : 'text-secondary hover:text-on-surface'
              }`}
            >
              Ambient
            </button>
          </div>
        </div>

        {/* Playlist Items */}
        <div className="space-y-2.5">
          {filteredPlaylist.map((t, idx) => {
            const isActive = track.id === t.id;
            const tIsYouTube =
              t.audio_source_type === 'youtube' ||
              Boolean(t.youtube_url && extractYouTubeId(t.youtube_url));
            const tThumb =
              t.cover_path ||
              (tIsYouTube && t.youtube_url ? getYouTubeThumbnail(t.youtube_url) : '');

            return (
              <div
                key={`${t.id}-${idx}`}
                onClick={() => playTrack(t)}
                className={`p-3 rounded-2xl flex items-center justify-between gap-3 cursor-pointer transition-all ${
                  isActive
                    ? 'bg-[#183421] text-white shadow-md border border-[#254E31]'
                    : 'bg-surface-container-low/50 hover:bg-surface-container-low text-on-surface border border-outline-variant/30 hover:border-primary/40'
                }`}
              >
                {/* Left: Square Thumbnail + Titles */}
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div
                    className={`relative w-12 h-12 rounded-xl overflow-hidden shrink-0 flex items-center justify-center shadow-2xs border ${
                      isActive ? 'border-emerald-500/40' : 'border-outline-variant/40'
                    }`}
                  >
                    {tThumb ? (
                      <img
                        src={tThumb}
                        alt={t.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                    ) : tIsYouTube ? (
                      <div className="w-full h-full bg-rose-900/60 flex items-center justify-center">
                        <Video className="w-6 h-6 text-rose-300" />
                      </div>
                    ) : (
                      <div className="w-full h-full bg-[#203D2A] flex items-center justify-center">
                        <Disc
                          className={`w-6 h-6 text-emerald-300 ${
                            isActive && isPlaying ? 'animate-spin' : ''
                          }`}
                        />
                      </div>
                    )}
                  </div>

                  <div className="min-w-0 flex-1 text-left">
                    <div className="flex items-center gap-2 mb-0.5">
                      <h4
                        className={`text-xs font-bold truncate ${
                          isActive ? 'text-white' : 'text-on-surface'
                        }`}
                      >
                        {t.title}
                      </h4>
                      {tIsYouTube ? (
                        <span className="px-1.5 py-0.2 rounded-full bg-rose-500/20 text-rose-300 text-[9px] font-bold shrink-0">
                          YT
                        </span>
                      ) : (
                        <span
                          className={`px-1.5 py-0.2 rounded-full text-[9px] font-bold shrink-0 ${
                            isActive
                              ? 'bg-emerald-500/30 text-emerald-200'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          AMBIENT
                        </span>
                      )}
                    </div>
                    <p
                      className={`text-[11px] truncate ${
                        isActive ? 'text-emerald-200/80' : 'text-secondary'
                      }`}
                    >
                      {t.artist}
                    </p>
                  </div>
                </div>

                {/* Right: Duration + Active Soundwave */}
                <div className="flex items-center gap-2 shrink-0">
                  {isActive && isPlaying && (
                    <span className="flex items-center gap-0.5 text-emerald-400">
                      <span className="w-0.5 h-3 bg-emerald-400 animate-pulse"></span>
                      <span className="w-0.5 h-4 bg-emerald-400 animate-pulse delay-75"></span>
                      <span className="w-0.5 h-2 bg-emerald-400 animate-pulse delay-150"></span>
                    </span>
                  )}
                  <span
                    className={`font-mono text-xs ${
                      isActive ? 'text-emerald-200 font-semibold' : 'text-secondary'
                    }`}
                  >
                    {t.duration}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
