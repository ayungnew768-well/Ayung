import React from 'react';
import { useAudioPlayer } from '../context/AudioPlayerContext';
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, X, Disc, Video, Music } from 'lucide-react';
import { formatSecondsToTime, extractYouTubeId, getYouTubeThumbnail } from '../lib/youtube';

export const FloatingAudioPlayer: React.FC = () => {
  const {
    currentTrack,
    isPlaying,
    isVisible,
    currentTime,
    duration,
    volume,
    togglePlay,
    playNext,
    playPrev,
    setVolume,
    seekTo,
    closePlayer
  } = useAudioPlayer();

  if (!isVisible || !currentTrack) return null;

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;
  const isYouTube =
    currentTrack.audio_source_type === 'youtube' ||
    Boolean(currentTrack.youtube_url && extractYouTubeId(currentTrack.youtube_url));

  const thumbnail =
    currentTrack.cover_path ||
    (isYouTube && currentTrack.youtube_url ? getYouTubeThumbnail(currentTrack.youtube_url) : '');

  return (
    <div
      role="region"
      aria-label="Pemutar Audio Mengambang"
      className="fixed bottom-4 sm:bottom-auto sm:top-4 left-1/2 -translate-x-1/2 z-50 w-[95%] max-w-xl bg-surface-container-lowest/95 backdrop-blur-xl border border-outline-variant/60 rounded-2xl shadow-xl p-3 transition-all duration-300 animate-in fade-in"
    >
      <div className="flex items-center justify-between gap-3">
        {/* Track Thumbnail & Info */}
        <div className="flex items-center gap-3 min-w-0 flex-1">
          <div className="relative w-10 h-10 rounded-xl bg-surface-container flex items-center justify-center shrink-0 border border-outline-variant/40 overflow-hidden shadow-2xs">
            {thumbnail ? (
              <img
                src={thumbnail}
                alt={currentTrack.title}
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            ) : isYouTube ? (
              <Video className="w-5 h-5 text-rose-600" />
            ) : (
              <Disc
                className={`w-5 h-5 text-primary ${isPlaying ? 'animate-spin' : ''}`}
                style={{ animationDuration: '4s' }}
              />
            )}
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <h4 className="font-sans font-semibold text-xs text-on-surface truncate">
                {currentTrack.title}
              </h4>
              {isYouTube && (
                <span className="px-1.5 py-0.2 rounded bg-rose-100 text-rose-700 text-[9px] font-bold shrink-0">
                  YT
                </span>
              )}
            </div>
            <p className="font-sans text-[11px] text-secondary truncate">
              {currentTrack.artist}
            </p>
          </div>
        </div>

        {/* Center Controls */}
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={playPrev}
            aria-label="Lagu sebelumnya"
            className="w-7 h-7 rounded-full flex items-center justify-center text-secondary hover:text-on-surface hover:bg-surface-container transition-colors"
          >
            <SkipBack className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={togglePlay}
            aria-label={isPlaying ? 'Jeda lagu' : 'Putar lagu'}
            className="w-8 h-8 rounded-full bg-primary text-on-primary flex items-center justify-center hover:bg-primary-container shadow-xs transition-transform active:scale-95"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
          </button>
          <button
            onClick={playNext}
            aria-label="Lagu selanjutnya"
            className="w-7 h-7 rounded-full flex items-center justify-center text-secondary hover:text-on-surface hover:bg-surface-container transition-colors"
          >
            <SkipForward className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Volume & Close */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="hidden sm:flex items-center gap-1 text-secondary">
            {volume === 0 ? (
              <VolumeX className="w-3.5 h-3.5" />
            ) : (
              <Volume2 className="w-3.5 h-3.5" />
            )}
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={volume}
              onChange={(e) => setVolume(parseFloat(e.target.value))}
              className="w-14 h-1 bg-surface-container rounded-lg appearance-none cursor-pointer accent-primary"
              aria-label="Kontrol Volume"
            />
          </div>
          <button
            onClick={closePlayer}
            aria-label="Tutup pemutar musik"
            className="w-7 h-7 rounded-full flex items-center justify-center text-secondary hover:text-on-surface hover:bg-surface-container transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Progress Bar & Scrubber */}
      <div className="mt-2 flex items-center gap-2">
        <span className="font-mono text-[10px] text-secondary shrink-0">
          {formatSecondsToTime(currentTime)}
        </span>
        <div
          onClick={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const clickPos = (e.clientX - rect.left) / rect.width;
            seekTo(Math.max(0, Math.min(1, clickPos)));
          }}
          className="flex-1 h-1.5 bg-surface-container-high rounded-full overflow-hidden cursor-pointer relative"
        >
          <div
            className="h-full bg-primary rounded-full transition-all duration-150"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
        <span className="font-mono text-[10px] text-secondary shrink-0">
          {formatSecondsToTime(duration)}
        </span>
      </div>
    </div>
  );
};
