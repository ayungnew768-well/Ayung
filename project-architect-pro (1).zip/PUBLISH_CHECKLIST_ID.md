# Checklist sebelum publish

## 1. Konfigurasi Netlify
Tambahkan environment variables `VITE_ADMIN_EMAIL`, `VITE_FIREBASE_API_KEY`, `VITE_FIREBASE_AUTH_DOMAIN`, `VITE_FIREBASE_PROJECT_ID`, `VITE_FIREBASE_APP_ID`, `VITE_SUPABASE_URL`, dan `VITE_SUPABASE_ANON_KEY`. Gunakan nilai dari proyek milik sendiri. Jangan pernah memakai `service_role` key.

## 2. Firebase
- Aktifkan Email/Password di Authentication.
- Buat akun admin yang emailnya sama dengan `VITE_ADMIN_EMAIL`.
- Tambahkan domain `*.netlify.app` yang tepat ke Authorized domains (gunakan domain situs yang benar).
- Deploy `firebase/firestore.rules` ke Firestore Rules.

## 3. Supabase
- Jalankan `supabase/migrations/001_initial_schema.sql` di SQL Editor.
- Buat akun admin dengan email yang sama dan password yang sama dengan akun Firebase.
- Jalankan `supabase/migrations/002_admin_access_hardening.sql` setelah akun admin dibuat.
- Periksa RLS dan policies, serta buat Storage buckets sesuai migrasi.

## 4. Verifikasi setelah deploy
- Pastikan tab Deploys menampilkan build berhasil.
- Login admin, ubah profil, lalu buka situs di browser/perangkat lain dan pastikan perubahan terbaca dari Supabase.
- Uji tambah/edit/hapus prestasi, tautan, musik, dan unggah media.
- Uji reset password dan logout.

Catatan: build berhasil tidak otomatis membuktikan layanan eksternal sudah benar. Fungsi yang memerlukan Firebase/Supabase harus diuji terhadap proyek aktual.
