-- ====================================================================
-- SUPABASE POSTGRESQL MIGRATION SCHEMA: SYAHRUL GUNAWAN PERSONAL PROFILE
-- Version: 001_initial_schema.sql
-- Description: Complete schema with RLS, triggers, indexes, and storage buckets.
-- ====================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. PROFILES TABLE
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    firebase_uid TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL DEFAULT 'Syahrul Gunawan',
    username TEXT UNIQUE NOT NULL DEFAULT 'syahrulgunawan',
    headline TEXT NOT NULL DEFAULT 'Creative Director & Tech Strategist based in Jakarta',
    biography TEXT NOT NULL DEFAULT 'Fokus pada persimpangan antara estetika fungsional, arsitektur informasi, dan pertumbuhan produk jangka panjang.',
    birth_date DATE DEFAULT '1995-08-14',
    location TEXT DEFAULT 'Jakarta Selatan, Indonesia',
    profile_photo_path TEXT DEFAULT '/assets/syahrul_portrait.png',
    email_public TEXT DEFAULT 'halo@syahrulgunawan.com',
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 2. PROFILE DETAILS TABLE
CREATE TABLE IF NOT EXISTS public.profile_details (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    profile_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    section_type TEXT NOT NULL, -- 'personal', 'education', 'expertise', 'status', 'meta'
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    display_order INT NOT NULL DEFAULT 0,
    is_published BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 3. ACHIEVEMENTS TABLE
CREATE TABLE IF NOT EXISTS public.achievements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    profile_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'Penghargaan', -- 'Penghargaan', 'Pembicara', 'Proyek', 'Karier'
    institution TEXT NOT NULL,
    achievement_date DATE,
    image_path TEXT,
    document_path TEXT,
    is_published BOOLEAN NOT NULL DEFAULT true,
    display_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 4. HOBBIES TABLE
CREATE TABLE IF NOT EXISTS public.hobbies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    profile_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    icon TEXT DEFAULT 'photo_camera',
    image_path TEXT,
    display_order INT NOT NULL DEFAULT 0,
    is_published BOOLEAN NOT NULL DEFAULT true
);

-- 5. MUSIC TRACKS TABLE
CREATE TABLE IF NOT EXISTS public.music_tracks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    profile_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    artist TEXT NOT NULL,
    audio_source_type TEXT NOT NULL DEFAULT 'ambient', -- 'ambient', 'upload', 'youtube', 'url'
    audio_url TEXT,
    audio_storage_path TEXT,
    cover_path TEXT,
    youtube_url TEXT,
    duration TEXT DEFAULT '03:48',
    display_order INT NOT NULL DEFAULT 0,
    is_published BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 6. SOCIAL LINKS / BOOKMARK LINKS TABLE
CREATE TABLE IF NOT EXISTS public.social_links (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    profile_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    label TEXT NOT NULL,
    url TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'Web', -- 'Web', 'Sosmed', 'Aplikasi', 'Game'
    platform TEXT DEFAULT 'website', -- 'instagram', 'tiktok', 'youtube', 'linkedin', 'github', 'website', 'other'
    description TEXT,
    icon TEXT DEFAULT 'link',
    display_order INT NOT NULL DEFAULT 0,
    is_published BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 7. PRIVATE NOTES TABLE (STRICTLY PRIVATE)
CREATE TABLE IF NOT EXISTS public.private_notes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_uid TEXT NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'All', -- 'Web', 'Sosmed', 'Aplikasi', 'Game', 'Ide Desain', 'Filosofi Studio', 'Arsip Rapat'
    is_private BOOLEAN NOT NULL DEFAULT true,
    is_archived BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 8. VAULT ITEMS TABLE (CLIENT-SIDE ENCRYPTED PAYLOAD)
CREATE TABLE IF NOT EXISTS public.vault_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_uid TEXT NOT NULL,
    title TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'Web', -- 'Web', 'Sosmed', 'Aplikasi', 'Game'
    identity_type TEXT NOT NULL DEFAULT 'Email', -- 'Email', 'Username', 'Gmail', 'No. HP', 'Lainnya'
    identity_value TEXT NOT NULL DEFAULT '',
    credential_type TEXT NOT NULL DEFAULT 'Password', -- 'Password', 'PIN', 'Token API', 'Kunci Rahasia'
    encrypted_payload TEXT NOT NULL, -- Encrypted ciphertext (AES-GCM 256)
    encryption_version TEXT NOT NULL DEFAULT 'AES-GCM-PBKDF2-v1',
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 9. DONATIONS TABLE
CREATE TABLE IF NOT EXISTS public.donations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    profile_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    enabled BOOLEAN NOT NULL DEFAULT true,
    title TEXT NOT NULL DEFAULT 'Dukung Saya',
    description TEXT NOT NULL DEFAULT 'Jika kamu menikmati karya, tulisan, atau proyek ini, kamu dapat memberikan apresiasi langsung secara digital.',
    qris_image_path TEXT DEFAULT '/assets/qris_syahrul_official.png',
    donation_url TEXT DEFAULT 'https://saweria.co/syahrulgunawan',
    display_order INT NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 10. APP SETTINGS TABLE
CREATE TABLE IF NOT EXISTS public.app_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_uid TEXT NOT NULL,
    setting_key TEXT UNIQUE NOT NULL,
    setting_value JSONB NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- ====================================================================
-- INDEXES FOR PERFORMANCE
-- ====================================================================
CREATE INDEX IF NOT EXISTS idx_profiles_firebase_uid ON public.profiles(firebase_uid);
CREATE INDEX IF NOT EXISTS idx_profile_details_profile_id ON public.profile_details(profile_id);
CREATE INDEX IF NOT EXISTS idx_achievements_profile_id ON public.achievements(profile_id);
CREATE INDEX IF NOT EXISTS idx_achievements_published ON public.achievements(is_published);
CREATE INDEX IF NOT EXISTS idx_music_tracks_published ON public.music_tracks(is_published);
CREATE INDEX IF NOT EXISTS idx_social_links_category ON public.social_links(category);
CREATE INDEX IF NOT EXISTS idx_social_links_published ON public.social_links(is_published);
CREATE INDEX IF NOT EXISTS idx_private_notes_owner ON public.private_notes(owner_uid);
CREATE INDEX IF NOT EXISTS idx_vault_items_owner ON public.vault_items(owner_uid);

-- ====================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ====================================================================
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profile_details ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.hobbies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.music_tracks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.social_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.private_notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vault_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.donations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

-- Public can read published profile content:
CREATE POLICY "Public read profiles" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Public read profile_details" ON public.profile_details FOR SELECT USING (is_published = true);
CREATE POLICY "Public read achievements" ON public.achievements FOR SELECT USING (is_published = true);
CREATE POLICY "Public read hobbies" ON public.hobbies FOR SELECT USING (is_published = true);
CREATE POLICY "Public read music_tracks" ON public.music_tracks FOR SELECT USING (is_published = true);
CREATE POLICY "Public read social_links" ON public.social_links FOR SELECT USING (is_published = true);
CREATE POLICY "Public read donations" ON public.donations FOR SELECT USING (enabled = true);

-- Private tables: Public has ZERO access. Only authenticated user matches owner_uid.
CREATE POLICY "Private notes owner only" ON public.private_notes
    FOR ALL USING (auth.uid()::text = owner_uid);

CREATE POLICY "Vault items owner only" ON public.vault_items
    FOR ALL USING (auth.uid()::text = owner_uid);

CREATE POLICY "App settings owner only" ON public.app_settings
    FOR ALL USING (auth.uid()::text = owner_uid);

-- ====================================================================
-- STORAGE BUCKETS CONFIGURATION (Supabase Storage)
-- ====================================================================
INSERT INTO storage.buckets (id, name, public)
VALUES 
    ('profile-media', 'profile-media', true),
    ('achievement-media', 'achievement-media', true),
    ('music-media', 'music-media', true),
    ('donation-media', 'donation-media', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: Public can read, authenticated can insert/update/delete:
CREATE POLICY "Public read profile-media" ON storage.objects FOR SELECT USING (bucket_id = 'profile-media');
CREATE POLICY "Public read achievement-media" ON storage.objects FOR SELECT USING (bucket_id = 'achievement-media');
CREATE POLICY "Public read music-media" ON storage.objects FOR SELECT USING (bucket_id = 'music-media');
CREATE POLICY "Public read donation-media" ON storage.objects FOR SELECT USING (bucket_id = 'donation-media');

CREATE POLICY "Admin upload profile-media" ON storage.objects FOR INSERT WITH CHECK (bucket_id IN ('profile-media', 'achievement-media', 'music-media', 'donation-media') AND auth.role() = 'authenticated');
CREATE POLICY "Admin update profile-media" ON storage.objects FOR UPDATE USING (bucket_id IN ('profile-media', 'achievement-media', 'music-media', 'donation-media') AND auth.role() = 'authenticated');
CREATE POLICY "Admin delete profile-media" ON storage.objects FOR DELETE USING (bucket_id IN ('profile-media', 'achievement-media', 'music-media', 'donation-media') AND auth.role() = 'authenticated');
