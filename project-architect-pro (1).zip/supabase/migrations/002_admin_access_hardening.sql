-- Run AFTER 001_initial_schema.sql in Supabase SQL Editor.
-- CMS writes are allowed only to a Supabase Auth user whose app_metadata.role is 'admin'.
-- Do NOT use user_metadata for authorization because users can edit their own user_metadata.

-- Grant admin role to the intended email if that user already exists in Supabase Auth.
-- If no row is updated, create the user first in Authentication > Users, then rerun this block.
UPDATE auth.users
SET raw_app_meta_data = COALESCE(raw_app_meta_data, '{}'::jsonb) || '{"role":"admin"}'::jsonb,
    updated_at = now()
WHERE lower(email) = lower('ayungnew768@gmail.com');

-- Allow only the designated Supabase Auth admin to create/update/delete CMS content.
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['profiles','profile_details','achievements','hobbies','music_tracks','social_links','donations'] LOOP
    EXECUTE format('DROP POLICY IF EXISTS "CMS admin write %s" ON public.%I', t, t);
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR ALL TO authenticated USING ((auth.jwt() -> ''app_metadata'' ->> ''role'') = ''admin'') WITH CHECK ((auth.jwt() -> ''app_metadata'' ->> ''role'') = ''admin'')',
      'CMS admin write ' || t, t
    );
  END LOOP;
END $$;

-- Private records can be managed by the designated admin only for this single-owner CMS.
DROP POLICY IF EXISTS "CMS admin private notes" ON public.private_notes;
CREATE POLICY "CMS admin private notes" ON public.private_notes
  FOR ALL TO authenticated
  USING ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
  WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

DROP POLICY IF EXISTS "CMS admin vault items" ON public.vault_items;
CREATE POLICY "CMS admin vault items" ON public.vault_items
  FOR ALL TO authenticated
  USING ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
  WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

DROP POLICY IF EXISTS "CMS admin app settings" ON public.app_settings;
CREATE POLICY "CMS admin app settings" ON public.app_settings
  FOR ALL TO authenticated
  USING ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
  WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Replace the too-broad policy that allowed every authenticated user to modify media.
DROP POLICY IF EXISTS "Admin upload profile-media" ON storage.objects;
DROP POLICY IF EXISTS "Admin update profile-media" ON storage.objects;
DROP POLICY IF EXISTS "Admin delete profile-media" ON storage.objects;

CREATE POLICY "CMS admin upload media" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id IN ('profile-media','achievement-media','music-media','donation-media')
    AND (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin'
  );
CREATE POLICY "CMS admin update media" ON storage.objects
  FOR UPDATE TO authenticated
  USING (
    bucket_id IN ('profile-media','achievement-media','music-media','donation-media')
    AND (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin'
  )
  WITH CHECK (
    bucket_id IN ('profile-media','achievement-media','music-media','donation-media')
    AND (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin'
  );
CREATE POLICY "CMS admin delete media" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id IN ('profile-media','achievement-media','music-media','donation-media')
    AND (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin'
  );
